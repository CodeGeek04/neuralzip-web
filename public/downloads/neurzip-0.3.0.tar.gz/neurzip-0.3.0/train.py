"""Train a small transformer from scratch until it can write a book back out exactly.

Usage:
    python train.py                                   # Alice, default 886K-parameter model
    python train.py --n-layer 4 --d-model 48 --n-head 2 --d-ff 144
    python train.py --init runs/alice-L4-d24-c252/model_fp32.pt --quant-bits 8 --track bits

Every check is printed here and also written to runs/<run>/log.jsonl. At the end,
runs/<run>/ holds the packages (weights + settings + fixes) and summary.json.
With --quant-bits, the weights are trained to survive rounding to 8 or 4 bits and
are stored as small integers with one bf16 scale per row.
"""
import argparse
import copy
import hashlib
import json
import math
import os
import time
from dataclasses import asdict
from pathlib import Path

import torch
import torch.nn.functional as F

import quant
from chunks import IGNORE, KEY_LEN, VOCAB_SIZE, build_sequences
from decode import check, compare_chunk, decode_book, fix_size, load, make_lossless, pack_fixes
from model import Config, Model, pick_device


def mmss(seconds):
    return f"{int(seconds) // 60}:{int(seconds) % 60:02d}"


def rounded_to_bf16(model):
    """Copy of the model with every weight rounded to bf16, i.e. what a 2-bytes-per-weight file holds."""
    m = copy.deepcopy(model)
    with torch.no_grad():
        for p in m.parameters():
            p.copy_(p.to(torch.bfloat16).float())
    return m


def save(path, model, meta, fixes, dtype=None, qbits=0, qgroup="row"):
    """Write a package (weights + settings + fixes). Returns (weight bytes, bytes on disk)."""
    ck = {"config": asdict(model.cfg), "meta": meta, "fixes": pack_fixes(fixes, meta["chunk_len"])}
    if qbits:
        packed, weights_bytes = quant.pack(model, qbits, qgroup)
        ck.update(packed)
    else:
        ck["state_dict"] = {k: v.detach().to("cpu", dtype) for k, v in model.state_dict().items()}
        weights_bytes = model.n_params() * torch.empty((), dtype=dtype).element_size()
    ck["weights_bytes"] = weights_bytes
    torch.save(ck, path)
    return weights_bytes, os.path.getsize(path)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--text", default="data/alice.txt")
    ap.add_argument("--book-id", type=int, default=0)
    ap.add_argument("--chunk-len", type=int, default=252, help="bytes of text behind each key")
    ap.add_argument("--n-layer", type=int, default=4)
    ap.add_argument("--d-model", type=int, default=128)
    ap.add_argument("--n-head", type=int, default=4)
    ap.add_argument("--d-ff", type=int, default=384)
    ap.add_argument("--init", help="start from this saved package instead of random weights (uses its model shape)")
    ap.add_argument("--quant-bits", type=int, default=0, choices=[0, 4, 8], help="train for 8- or 4-bit weights")
    ap.add_argument("--quant-group", default="row", choices=["row", "tensor"],
                    help="one rounding scale per matrix row, or one per matrix")
    ap.add_argument("--track", default="wrong", choices=["wrong", "bits"],
                    help="progress = fewer wrong bytes (exact recall) or fewer bits (arithmetic coding)")
    ap.add_argument("--no-fixes", action="store_true",
                    help="skip plain fixes (they need a full real decode); report the arithmetic-coded size only")
    ap.add_argument("--batch-size", type=int, default=32, help="chunks per training step")
    ap.add_argument("--lr", type=float, default=3e-3)
    ap.add_argument("--max-epochs", type=int, default=4000)
    ap.add_argument("--max-minutes", type=float, default=0, help="stop after this much training time (0 = no limit)")
    ap.add_argument("--check-every", type=int, default=20, help="epochs between checks")
    ap.add_argument("--patience", type=int, default=5,
                    help="halve the learning rate after this many checks without progress")
    ap.add_argument("--min-lr-scale", type=float, default=1 / 64,
                    help="stop when the learning rate falls below lr x this (the model has stopped improving)")
    ap.add_argument("--threads", type=int, default=0, help="CPU threads for torch (0 = default)")
    ap.add_argument("--preview-chunk", type=int, default=100, help="chunk shown at every check")
    ap.add_argument("--device", default=pick_device())
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", help="run folder (default: runs/<text>-L<layers>-d<width>-c<chunk>[-q<bits>])")
    args = ap.parse_args()
    torch.manual_seed(args.seed)
    if args.threads:
        torch.set_num_threads(args.threads)
    dev = args.device

    # ---- data and model -------------------------------------------------------
    text = Path(args.text).read_bytes()
    inputs, targets = build_sequences(text, args.book_id, args.chunk_len)
    meta = {"book_id": args.book_id, "chunk_len": args.chunk_len, "total_len": len(text),
            "n_chunks": len(inputs), "text": args.text, "sha256": hashlib.sha256(text).hexdigest()}
    if args.init:
        init_model, init_meta, _ = load(args.init, "cpu")
        assert init_meta["chunk_len"] == args.chunk_len, "--chunk-len must match the --init package"
        cfg = init_model.cfg
        model = Model(cfg)
        model.load_state_dict(init_model.state_dict())
    else:
        cfg = Config(n_layer=args.n_layer, d_model=args.d_model, n_head=args.n_head, d_ff=args.d_ff,
                     max_len=KEY_LEN + args.chunk_len)
        model = Model(cfg)
    if args.quant_bits:
        quant.add_fake_quant(model, args.quant_bits, args.quant_group)
    model = model.to(dev)
    P = model.n_params()
    settings_bytes = 4 * (3 + len(asdict(cfg)))  # book length, chunk length, book id + model shape
    tag = f"-q{args.quant_bits}" if args.quant_bits else ""
    default_run = (f"runs/{Path(args.init).parent.name}{tag}" if args.init else
                   f"runs/{Path(args.text).stem}-L{cfg.n_layer}-d{cfg.d_model}-c{args.chunk_len}{tag}")
    run = Path(args.out or default_run)
    run.mkdir(parents=True, exist_ok=True)

    steps_per_epoch = math.ceil(meta["n_chunks"] / args.batch_size)
    total_steps = args.max_epochs * steps_per_epoch
    print(f"book      {args.text}: {len(text):,} bytes, sha256 {meta['sha256'][:16]}...")
    print(f"chunks    {meta['n_chunks']} chunks of {args.chunk_len} bytes, each behind a 4-token key "
          f"(keys are just 0..{meta['n_chunks'] - 1}, so 0 bytes to store)")
    print(f"model     {cfg.n_layer} layers x {cfg.d_model} wide, {cfg.n_head} heads, SwiGLU {cfg.d_ff}, "
          f"vocab {VOCAB_SIZE}: {P:,} parameters" + (f", starting from {args.init}" if args.init else ""))
    if args.quant_bits:
        qbytes = quant.pack(quant.bake(model), args.quant_bits, args.quant_group)[1]
        print(f"size      int{args.quant_bits} weights + bf16 scale per {args.quant_group} = {qbytes:,} bytes"
              f"  ->  book/weights = {len(text) / qbytes:.3f}x")
    else:
        print(f"size      {P * 4:,} bytes as fp32, {P * 2:,} as bf16  ->  book/model = "
              f"{len(text) / (P * 4):.3f}x (fp32), {len(text) / (P * 2):.3f}x (bf16)")
    print(f"training  device {dev}, batch {args.batch_size}, up to {args.max_epochs} epochs x {steps_per_epoch} steps, "
          f"check every {args.check_every} epochs, progress = fewer {args.track}")
    print(f"lr        {args.lr}, halved after {args.patience} checks without progress, "
          f"stop once below {args.lr * args.min_lr_scale:.1e}")
    print(f"run dir   {run}\n")

    # ---- training -------------------------------------------------------------
    warmup = min(200, total_steps // 10)
    lr_scale = 1.0  # halved each time progress stalls

    def lr_at(step):  # linear warmup, then constant (times lr_scale)
        return args.lr * lr_scale * min(1.0, (step + 1) / warmup)

    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, betas=(0.9, 0.95), weight_decay=0.0)
    x, y = inputs.to(dev), targets.to(dev)
    preview = min(args.preview_chunk, meta["n_chunks"] - 1)
    log = open(run / "log.jsonl", "w")
    step, t0, exact_epoch, stop_reason = 0, time.time(), None, "max epochs"
    best = {"metric": float("inf"), "wrong": None, "bpb": None, "epoch": 0, "state": None}
    stall_ref, stall = float("inf"), 0  # progress = beating stall_ref (by 0.1% when tracking bits)

    for epoch in range(1, args.max_epochs + 1):
        loss_sum = torch.zeros((), device=dev)
        for idx in torch.randperm(meta["n_chunks"], device=dev).split(args.batch_size):
            for group in opt.param_groups:
                group["lr"] = lr_at(step)
            logits = model(x[idx])
            loss = F.cross_entropy(logits.reshape(-1, VOCAB_SIZE), y[idx].reshape(-1), ignore_index=IGNORE)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            loss_sum += loss.detach()
            step += 1

        if epoch % args.check_every and epoch != args.max_epochs:
            continue
        r = check(model, x, y)
        metric = r["bits"] if args.track == "bits" else r["wrong"]
        if metric < best["metric"]:  # remember the best weights seen so far
            best = {"metric": metric, "wrong": r["wrong"], "bpb": r["bpb"], "epoch": epoch,
                    "state": {k: v.detach().clone() for k, v in model.state_dict().items()}}
        if metric < stall_ref * (0.999 if args.track == "bits" else 1):
            stall_ref, stall = metric, 0
        else:
            stall += 1
        train_bpb = loss_sum.item() / steps_per_epoch / math.log(2)
        print(f"epoch {epoch:5d} | {mmss(time.time() - t0)} | lr {lr_at(step):.1e} | {r['bpb']:.3f} bits/byte"
              f" (train {train_bpb:.3f}) | wrong {r['wrong']:,} of {r['bytes']:,} | exact chunks "
              f"{r['exact_chunks']}/{r['chunks']} | margin {r['min_margin']:+.2f}")
        print("\n".join(compare_chunk(model, meta, text, preview)))
        log.write(json.dumps({"epoch": epoch, "step": step, "seconds": round(time.time() - t0, 1),
                              "lr": lr_at(step), "train_bpb": train_bpb,
                              **{k: v for k, v in r.items() if k != "wrong_at"}}) + "\n")
        log.flush()
        if r["wrong"] == 0:
            if decode_book(model, meta) == text:
                exact_epoch, stop_reason = epoch, "exact"
                print(f"\nEXACT at epoch {epoch}: the real decode of all {meta['n_chunks']} chunks matches the book")
                break
            print("    fast check says 0 wrong, but the real decode differs (floating point near-tie); training on")
        if args.max_minutes and time.time() - t0 > 60 * args.max_minutes:
            stop_reason = "time budget"
            print(f"\ntime budget of {args.max_minutes:g} minutes used: best was {best['bpb']:.3f} bits/byte "
                  f"at epoch {best['epoch']}")
            break
        if stall >= args.patience:
            lr_scale, stall = lr_scale / 2, 0
            if lr_scale < args.min_lr_scale:
                stop_reason = "stopped improving"
                print(f"\nstopped improving: best was {best['wrong']:,} wrong bytes, {best['bpb']:.3f} bits/byte "
                      f"at epoch {best['epoch']}")
                break
            print(f"    no progress for {args.patience} checks: learning rate halved to {lr_at(step):.1e}")

    # ---- lossless package and size accounting -----------------------------------
    seconds = time.time() - t0
    print(f"\n=== result after {mmss(seconds)} ({stop_reason}) ===")
    if exact_epoch is None:
        model.load_state_dict(best["state"])
        print(f"not exact: using the best weights (epoch {best['epoch']}, {best['wrong']:,} wrong bytes, "
              f"{best['bpb']:.3f} bits/byte); fixes cover the rest")
    summary = {"args": vars(args), "params": P, "book_bytes": len(text), "exact_epoch": exact_epoch,
               "epochs_run": epoch, "seconds": round(seconds), "stop_reason": stop_reason,
               "best_wrong": best["wrong"], "best_bpb": best["bpb"], "best_epoch": best["epoch"], "packages": {}}
    if args.quant_bits:
        candidates = [(f"q{args.quant_bits}", quant.bake(model), None)]
    else:
        candidates = [("fp32", model, torch.float32), ("bf16", rounded_to_bf16(model), torch.bfloat16)]
    for label, m, dtype in candidates:
        fixes = [] if args.no_fixes else make_lossless(m, meta, text, x, y)  # verified by a real decode
        path = run / f"model_{label}.pt"
        weights, on_disk = save(path, m, meta, fixes, dtype, args.quant_bits, args.quant_group)
        per_fix = fix_size(args.chunk_len)
        total = weights + per_fix * len(fixes) + settings_bytes
        bits = check(m, x, y)["bits"]  # what arithmetic coding with this exact model will cost
        ac_total = weights + math.ceil(bits / 8) + 4 * 16 + settings_bytes  # + 16 stream lengths
        summary["packages"][label] = {
            "weights_bytes": weights, "fixes": None if args.no_fixes else len(fixes),
            "fix_bytes": per_fix * len(fixes), "settings_bytes": settings_bytes,
            "total_bytes": None if args.no_fixes else total, "ratio": None if args.no_fixes else len(text) / total,
            "ac_estimate_bytes": ac_total, "file": str(path), "file_bytes": on_disk}
        if not args.no_fixes:
            print(f"{label}: weights {weights:,} B + {len(fixes):,} fixes x {per_fix} B + settings {settings_bytes} B"
                  f" = {total:,} B  ->  book/package = {len(text) / total:.3f}x   ({path}, {on_disk:,} B on disk)")
        print(f"{label}: with arithmetic coding (estimated from {bits / len(text):.3f} bits/byte): weights {weights:,} B"
              f" + stream ~{math.ceil(bits / 8):,} B = ~{ac_total:,} B  ->  book/package ~ {len(text) / ac_total:.3f}x")
    summary["main"] = candidates[-1][0]
    (run / "summary.json").write_text(json.dumps(summary, indent=2))
    print(f"\nrebuild the book yourself, in a fresh process:\n"
          f"  uv run python decode.py {run}/model_{summary['main']}.pt --compare {args.text} --show {preview}")


if __name__ == "__main__":
    main()
