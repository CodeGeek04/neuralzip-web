"""Will this package decode to exactly the same book on another computer?

Greedy decoding only needs every device to agree on the TOP byte at every step.
Different hardware computes the scores with tiny rounding differences ("noise").
A device can only pick a different byte where the winner's lead over the
runner-up ("margin") is smaller than that noise.

This script scores every byte of the book on each device available here (CPU,
Apple GPU, NVIDIA GPU), then reports the smallest margin, the largest noise
between devices, and whether the top byte is the same everywhere.

Usage:  python check_determinism.py runs/alice-L4-d48-c252/model_bf16.pt
"""
import sys

import torch

from chunks import IGNORE, build_sequences
from decode import N_BYTES, load


def main():
    path = sys.argv[1]
    devices = ["cpu"] + [d for d, ok in (("mps", torch.backends.mps.is_available()),
                                          ("cuda", torch.cuda.is_available())) if ok]
    models = {d: load(path, d)[0] for d in devices}
    meta = load(path, "cpu")[1]
    text = open(meta["text"], "rb").read()
    x, y = build_sequences(text, meta["book_id"], meta["chunk_len"])

    min_margin, noise, disagree, n = float("inf"), {d: 0.0 for d in devices[1:]}, 0, 0
    with torch.no_grad():
        for s in range(0, len(x), 100):
            xb, yb = x[s:s + 100], y[s:s + 100]
            mask = yb != IGNORE
            scores = {d: models[d](xb.to(d))[..., :N_BYTES].float().cpu() for d in devices}
            ref = scores["cpu"]
            t = yb.clamp(min=0).unsqueeze(-1)
            margin = ref.gather(-1, t).squeeze(-1) - ref.scatter(-1, t, float("-inf")).amax(-1)
            min_margin = min(min_margin, float(margin[mask].min()))
            top = ref.argmax(-1)
            for d in devices[1:]:
                noise[d] = max(noise[d], float((scores[d] - ref).abs()[mask].max()))
                disagree += int(((scores[d].argmax(-1) != top) & mask).sum())
            n += int(mask.sum())

    print(f"package: {path}")
    print(f"devices: {', '.join(devices)}   bytes checked per device: {n:,}")
    print(f"smallest margin (winner's lead over the runner-up, anywhere in the book): {min_margin:.4f}")
    for d, v in noise.items():
        print(f"largest score difference, {d} vs cpu: {v:.2e}   -> safety factor {min_margin / (2 * v):,.0f}x"
              if v else f"largest score difference, {d} vs cpu: 0 (bit-identical)")
    print(f"positions where devices pick a different top byte: {disagree}")
    if min_margin <= 0:
        print("note: margin <= 0 means the model itself is wrong somewhere; the package's fixes cover those bytes")


if __name__ == "__main__":
    main()
