"""Print everything inside a saved package: settings, fixes, and every weight tensor.

Usage:
    python inspect_package.py runs/alice-L4-d128-c252/model_bf16.pt
"""
import sys

import torch

from decode import fix_size, unpack_fixes


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "runs/alice-L4-d128-c252/model_bf16.pt"
    ck = torch.load(path, map_location="cpu", weights_only=True)
    meta, cfg = ck["meta"], ck["config"]

    print(f"package: {path}\n")
    print("1. settings (the decoder needs these to rebuild the model and the keys)")
    for k, v in cfg.items():
        print(f"   model.{k:<11} {v}")
    for k in ("book_id", "chunk_len", "total_len", "n_chunks"):
        print(f"   book.{k:<12} {meta[k]}")
    print(f"   book.sha256       {meta['sha256']}   (only used to check the result)")

    fixes = unpack_fixes(ck["fixes"], meta["chunk_len"])
    print(f"\n2. fixes: {len(fixes)} x {fix_size(meta['chunk_len'])} bytes")
    for c, o, b in fixes[:10]:
        print(f"   chunk {c}, byte {o}: write {b!r} ({chr(b)!r}) instead of the model's guess")

    print("\n3. weights")
    total, bytes_total = 0, 0
    for name, t in ck["state_dict"].items():
        sample = ", ".join(f"{x:+.3f}" for x in t.flatten()[:4].float().tolist())
        print(f"   {name:<28} {str(tuple(t.shape)):<11} {t.numel():>8,} numbers   first: {sample} ...")
        total += t.numel()
        bytes_total += t.numel() * t.element_size()
    dtype = next(iter(ck["state_dict"].values())).dtype
    print(f"   total {total:,} numbers stored as {dtype} = {bytes_total:,} bytes")

    e = ck["state_dict"]["embed.weight"].float()
    print("\n4. a peek at the embedding table (one learned row of 128 numbers per token)")
    for tok, label in ((ord("A"), "'A'"), (ord("e"), "'e'"), (ord(" "), "space"), (256, "KEY")):
        print(f"   token {tok:>3} {label:<6} {', '.join(f'{x:+.2f}' for x in e[tok, :6].tolist())}, ...")

    print("\nThe book's text is not in this file. decode.py rebuilds it by running the model on keys 0.."
          f"{meta['n_chunks'] - 1}.")


if __name__ == "__main__":
    main()
