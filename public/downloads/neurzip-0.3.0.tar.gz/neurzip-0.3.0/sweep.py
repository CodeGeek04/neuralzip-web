"""Run one experiment's list of training runs in parallel, then print the results table.

Usage:
    python sweep.py e2          # E2: shrink sweep on Alice
    python sweep.py e3 6        # E3: 8- and 4-bit weights, 6 runs at a time
    python sweep.py e4 4        # E4: five books in one model
Each run writes runs/<name>.log (watch with tail -f). results.py prints the table any time.
"""
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from results import print_table

A = "data/alice.txt"
E2_INIT = "runs/alice-L4-d{}-c252/model_fp32.pt"


def size(layers, width, heads, ff):
    return ["--n-layer", str(layers), "--d-model", str(width), "--n-head", str(heads), "--d-ff", str(ff)]


def qat(width, bits, track, device, lr):
    """Retrain an E2 model so it works with 8- or 4-bit weights."""
    args = ["--init", E2_INIT.format(width), "--quant-bits", str(bits), "--track", track, "--lr", str(lr),
            "--max-epochs", "3000", "--device", device]
    return args + (["--threads", "2"] if device == "cpu" else [])


def bits_run(text, layers, width, heads, ff, epochs=300):
    """Train from scratch for the smallest arithmetic-coded package (no plain fixes)."""
    return ["--text", text, *size(layers, width, heads, ff), "--track", "bits", "--no-fixes",
            "--batch-size", "64", "--max-epochs", str(epochs), "--check-every", "5"]


LIB = "data/library.txt"
W1, W3, W10 = "data/wiki-1M.txt", "data/wiki-3M.txt", "data/wiki-10M.txt"


def qat_from(init, text, bits, lr, epochs=100):
    """Retrain a saved model for 8- or 4-bit weights, aiming at the smallest arithmetic-coded package."""
    return ["--init", init, "--text", text, "--quant-bits", str(bits), "--track", "bits", "--no-fixes",
            "--batch-size", "64", "--lr", str(lr), "--max-epochs", str(epochs), "--check-every", "5"]


def online(text, layers, width, heads, ff, lr=1e-3, batch=8, steps=8):
    """Learn while decoding (no stored weights): run online.py instead of train.py."""
    return ["online.py", "--text", text, *size(layers, width, heads, ff), "--lr", str(lr),
            "--batch", str(batch), "--steps", str(steps)]

EXPERIMENTS = {
    "e2": [  # (run name, train.py arguments)
        ("alice-L4-d24-c252", ["--text", A, *size(4, 24, 1, 72), "--device", "cpu", "--threads", "3"]),
        ("alice-L4-d32-c252", ["--text", A, *size(4, 32, 1, 96), "--device", "cpu", "--threads", "3"]),
        ("alice-L4-d48-c252", ["--text", A, *size(4, 48, 2, 144), "--device", "mps"]),
        ("alice-L4-d64-c252", ["--text", A, *size(4, 64, 2, 192), "--device", "mps"]),
        ("alice-L4-d96-c252", ["--text", A, *size(4, 96, 3, 288), "--device", "mps"]),
    ],
    "e3": [
        ("alice-L4-d48-c252-q8", qat(48, 8, "wrong", "mps", 1e-3)),   # aim: exact with 1-byte weights
        ("alice-L4-d48-c252-q4", qat(48, 4, "wrong", "mps", 2e-3)),   # aim: exact with half-byte weights
        ("alice-L4-d24-c252-q8", qat(24, 8, "bits", "cpu", 1e-3)),    # aim: smallest arithmetic-coded package
        ("alice-L4-d24-c252-q4", qat(24, 4, "bits", "cpu", 2e-3)),
        ("alice-L4-d32-c252-q8", qat(32, 8, "bits", "cpu", 1e-3)),
        ("alice-L4-d32-c252-q4", qat(32, 4, "bits", "cpu", 2e-3)),
    ],
    "e4": [  # five books in one model (3.1 MB), on a CUDA GPU
        ("library-L4-d48-c252", bits_run(LIB, 4, 48, 2, 144)),
        ("library-L4-d64-c252", bits_run(LIB, 4, 64, 2, 192)),
        ("library-L4-d96-c252", bits_run(LIB, 4, 96, 3, 288)),
        ("library-L4-d128-c252", bits_run(LIB, 4, 128, 4, 384)),
    ],
    "e4q": [  # the E4 library models, retrained for int8 and int4 weights
        *[(f"library-L4-d{w}-c252-q{b}", qat_from(f"runs/library-L4-d{w}-c252/model_fp32.pt", LIB, b, lr))
          for w in (48, 64, 96, 128) for b, lr in ((8, 1e-3), (4, 2e-3))],
    ],
    "e5e6": [  # Wikipedia slices with stored weights (E5), and learning while decoding everywhere (E6)
        ("wiki-1M-L4-d64-c252", bits_run(W1, 4, 64, 2, 192)),
        ("wiki-1M-L4-d96-c252", bits_run(W1, 4, 96, 3, 288)),
        ("wiki-3M-L4-d96-c252", bits_run(W3, 4, 96, 3, 288)),
        ("wiki-3M-L4-d128-c252", bits_run(W3, 4, 128, 4, 384)),
        ("wiki-10M-L4-d128-c252", bits_run(W10, 4, 128, 4, 384, epochs=100)),
        ("wiki-10M-L6-d192-c252", bits_run(W10, 6, 192, 6, 576, epochs=100)),
        ("online-alice-L4-d128", online(A, 4, 128, 4, 384)),
        ("online-library-L4-d128", online(LIB, 4, 128, 4, 384)),
        ("online-library-L6-d256", online(LIB, 6, 256, 8, 768, lr=5e-4)),
        ("online-wiki-1M-L4-d128", online(W1, 4, 128, 4, 384)),
        ("online-wiki-3M-L4-d128", online(W3, 4, 128, 4, 384)),
        ("online-wiki-10M-L4-d128", online(W10, 4, 128, 4, 384)),
        ("online-wiki-10M-L6-d256", online(W10, 6, 256, 8, 768, lr=5e-4)),
    ],
}


def run(job):
    name, args = job
    log = Path("runs") / f"{name}.log"
    if args[0].endswith(".py"):  # another script, e.g. online.py
        cmd = [sys.executable, "-u", *args, "--out", f"runs/{name}.json"]
    else:
        cmd = [sys.executable, "-u", "train.py", *args, "--out", f"runs/{name}"]
    print(f"started  {name}  (tail -f {log})", flush=True)
    t0 = time.time()
    with open(log, "w") as f:
        code = subprocess.call(cmd, stdout=f, stderr=subprocess.STDOUT)
    print(f"finished {name} in {(time.time() - t0) / 60:.1f} min (exit code {code})", flush=True)


def main():
    exp = sys.argv[1] if len(sys.argv) > 1 else "e2"
    jobs = int(sys.argv[2]) if len(sys.argv) > 2 else 3
    Path("runs").mkdir(exist_ok=True)
    print(f"{exp}: {len(EXPERIMENTS[exp])} runs, {jobs} at a time\n", flush=True)
    with ThreadPoolExecutor(jobs) as pool:
        list(pool.map(run, EXPERIMENTS[exp]))
    print()
    print_table()


if __name__ == "__main__":
    main()
