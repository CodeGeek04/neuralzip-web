"""Which kinds of characters are hard for the model?

Scores every byte of the book (teacher forcing) and groups the cost by kind of
byte: letters, spaces, newlines, punctuation, the 3-byte UTF-8 characters
(curly quotes, dashes), and the first few bytes after each key.
Cost = -log2(probability the model gave the true byte), in bits.

Usage:  python byte_costs.py runs/actest/model_bf16.pt
"""
import math
import sys
from collections import defaultdict

import torch
import torch.nn.functional as F

from chunks import IGNORE, KEY_LEN, build_sequences
from decode import N_BYTES, load
from model import pick_device


def kind(b, prev):
    if 0xC0 <= b <= 0xF7:
        return "UTF-8 byte 1 (curly quote or dash)"
    if 0x80 <= b <= 0xBF:
        return "UTF-8 byte 3 (which mark)" if 0x80 <= prev <= 0xBF else "UTF-8 byte 2"
    if chr(b).isalpha():
        return "letters"
    if b == 32:
        return "space"
    if b == 10:
        return "newline"
    if chr(b).isdigit():
        return "digits"
    return "ASCII punctuation"


def main():
    path = sys.argv[1]
    model, meta, _ = load(path, pick_device())
    text = open(meta["text"], "rb").read()
    x, y = build_sequences(text, meta["book_id"], meta["chunk_len"])
    dev = next(model.parameters()).device
    bits, wrong = [], []
    with torch.no_grad():
        for s in range(0, len(x), 200):
            logits = model(x[s:s + 200].to(dev))[..., :N_BYTES].float().cpu()
            yb = y[s:s + 200]
            t = yb.clamp(min=0)
            lp = F.log_softmax(logits, -1).gather(-1, t.unsqueeze(-1)).squeeze(-1)
            for row in range(len(yb)):
                keep = yb[row] != IGNORE
                bits += (-lp[row][keep] / math.log(2)).tolist()
                wrong += (logits[row].argmax(-1) != yb[row])[keep].tolist()

    groups = defaultdict(lambda: [0, 0.0, 0])
    L = meta["chunk_len"]
    for i, b in enumerate(text):
        g = groups[kind(b, text[i - 1] if i else 0)]
        g[0] += 1; g[1] += bits[i]; g[2] += wrong[i]
        if i % L < 8:
            h = groups["(first 8 bytes after each key)"]
            h[0] += 1; h[1] += bits[i]; h[2] += wrong[i]
    total_bits = sum(bits)

    print(f"model {path}: {model.n_params():,} params, {total_bits / len(text):.3f} bits per byte on average\n")
    print(f"{'kind of byte':<34} {'bytes':>8} {'of book':>8} {'bits/byte':>10} {'of all bits':>12} {'top guess wrong':>16}")
    for name, (cnt, b, w) in sorted(groups.items(), key=lambda kv: kv[0].startswith("(")):
        print(f"{name:<34} {cnt:>8,} {cnt / len(text):>7.1%} {b / cnt:>10.3f} {b / total_bits:>11.1%} {w / cnt:>15.1%}")
    specials = defaultdict(int)
    for ch in text.decode("utf-8"):
        if ord(ch) > 127:
            specials[ch] += 1
    print("\nnon-ASCII characters in the book: " + ", ".join(f"{c} x{n}" for c, n in sorted(specials.items(), key=lambda kv: -kv[1])))


if __name__ == "__main__":
    main()
