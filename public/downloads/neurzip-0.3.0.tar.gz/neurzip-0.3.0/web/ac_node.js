// Arithmetic-code a book with the deterministic JavaScript model, on all CPU cores, so any engine can decode it.
// Usage: node web/ac_node.js <package.json> <text file> [segments] [workers]
// Adds an "ac" section (one stream per segment) to the package JSON, then decodes it to verify.
const fs = require("fs");
const os = require("os");
const { Worker, isMainThread, parentPort, workerData } = require("worker_threads");
const D = require("./decoder.js");

if (!isMainThread) {
  // A worker: build the model once, then encode or decode the segments it is sent.
  const m = D.buildModel(workerData.pkg, workerData.blobs);
  parentPort.on("message", (task) => {
    if (task.job === "encode") {
      parentPort.postMessage({ first: task.first, bytes: D.encodeSegment(m, workerData.text, task.first, task.count) });
    } else {
      const parts = [];
      D.decodeSegment(m, task, task.bytes, (c, bytes) => parts.push(bytes));
      parentPort.postMessage({ first: task.first, data: Buffer.concat(parts) });
    }
  });
  return;
}

function runPool(tasks, nWorkers, data) {
  return new Promise((resolve, reject) => {
    const results = new Map(), workers = [];
    let next = 0, done = 0;
    const feed = (w) => { if (next < tasks.length) w.postMessage(tasks[next++]); };
    for (let i = 0; i < Math.min(nWorkers, tasks.length); i++) {
      const w = new Worker(__filename, { workerData: data });
      w.on("message", (r) => {
        results.set(r.first, r);
        if (++done === tasks.length) { workers.forEach((x) => x.terminate()); resolve(results); } else feed(w);
      });
      w.on("error", reject);
      workers.push(w);
      feed(w);
    }
  });
}

(async () => {
  const [pkgPath, textPath, segArg, workerArg] = process.argv.slice(2);
  const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8"));
  const text = fs.readFileSync(textPath);
  if (D.sha256Hex(text) !== pkg.meta.sha256) throw new Error("this text is not the book the package was made for");
  const nWorkers = Number(workerArg || Math.max(1, os.cpus().length - 1));
  const plan = D.segmentPlan(pkg.meta.n_chunks, Number(segArg || 64));
  const lite = Object.assign({}, pkg, { weights_b64: "", qdata_b64: "", scales_b64: "", ac: null });
  const data = { pkg: lite, blobs: D.decodeBlobs(pkg), text };
  const f = (n) => n.toLocaleString("en-US");

  let t0 = Date.now();
  const enc = await runPool(plan.map((s) => ({ job: "encode", ...s })), nWorkers, data);
  const segs = plan.map((s) => ({ ...s, bytes: enc.get(s.first).bytes }));
  const encodeSeconds = (Date.now() - t0) / 1000;

  t0 = Date.now();
  const dec = await runPool(segs.map((s) => ({ job: "decode", ...s })), nWorkers, { ...data, text: null });
  const out = Buffer.alloc(pkg.meta.total_len);
  for (const s of segs) out.set(dec.get(s.first).data, s.first * pkg.meta.chunk_len); // worker data arrives as Uint8Array
  const ok = Buffer.compare(out, text) === 0;

  const streamBytes = segs.reduce((a, s) => a + s.bytes.length, 0);
  const lengthsBytes = 4 * segs.length;
  const settingsBytes = 4 * (3 + Object.keys(pkg.config).length);
  const total = pkg.weights_bytes + streamBytes + lengthsBytes + settingsBytes;
  pkg.ac = {
    bits: D.AC_BITS, stream_bytes: streamBytes + lengthsBytes, total_bytes: total,
    segments: segs.map((s) => ({ first: s.first, count: s.count, stream_b64: Buffer.from(s.bytes).toString("base64") })),
  };
  fs.writeFileSync(pkgPath, JSON.stringify(pkg));
  console.log(`encoded ${f(text.length)} bytes in ${encodeSeconds.toFixed(0)}s on ${nWorkers} cores: ${segs.length} streams, ` +
    `${f(streamBytes)} bytes (${((8 * streamBytes) / text.length).toFixed(3)} bits per byte)`);
  console.log(`decoded in ${((Date.now() - t0) / 1000).toFixed(0)}s: ${ok ? "IDENTICAL to the book" : "DIFFERENT from the book"}`);
  console.log(`package: weights ${f(pkg.weights_bytes)} B + streams ${f(streamBytes)} B + lengths ${lengthsBytes} B + ` +
    `settings ${settingsBytes} B = ${f(total)} B  ->  book/package = ${(text.length / total).toFixed(3)}x`);
  process.exit(ok ? 0 : 1);
})();
