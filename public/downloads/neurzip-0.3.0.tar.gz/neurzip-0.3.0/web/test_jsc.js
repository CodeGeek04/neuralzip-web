// Rebuild a book from a package with Safari's JavaScript engine (JavaScriptCore), as a cross-engine check.
// Usage: /System/Library/Frameworks/JavaScriptCore.framework/Versions/Current/Helpers/jsc web/test_jsc.js -- <package.json>
load("web/decoder.js");
const D = BookDecoder;
const pkg = JSON.parse(readFile(arguments[0]));
const m = D.buildModel(pkg, D.decodeBlobs(pkg));
const out = new Uint8Array(pkg.meta.total_len);
const t0 = Date.now();
if (pkg.ac) {
  for (const seg of pkg.ac.segments) {
    D.decodeSegment(m, seg, D.base64ToBytes(seg.stream_b64), (c, bytes) => out.set(bytes, c * pkg.meta.chunk_len));
  }
} else {
  for (let c = 0; c < pkg.meta.n_chunks; c++) out.set(D.decodeChunk(m, c).bytes, c * pkg.meta.chunk_len);
}
const hash = D.sha256Hex(out);
print(`engine: JavaScriptCore (jsc), ${pkg.ac ? "arithmetic-coded streams" : "greedy decoding"}, ${((Date.now() - t0) / 1000).toFixed(1)}s`);
print(`sha256 rebuilt : ${hash}`);
print(`sha256 expected: ${pkg.meta.sha256}`);
print(hash === pkg.meta.sha256 ? "IDENTICAL" : "DIFFERENT");
