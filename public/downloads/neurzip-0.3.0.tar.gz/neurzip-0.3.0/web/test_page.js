// Open an exported page in headless Chrome, rebuild the whole book, and report the verdict.
// Usage: node web/test_page.js <page.html> [max seconds, default 300]
const { spawn } = require("child_process");
const fs = require("fs");
const os = require("os");
const path = require("path");

const CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome";
const PORT = 9333;
const page = "file://" + path.resolve(process.argv[2]) + "#selftest";
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), "chrome-test-"));
  const chrome = spawn(CHROME, ["--headless=new", `--remote-debugging-port=${PORT}`, `--user-data-dir=${profile}`,
    "--no-first-run", "about:blank"], { stdio: "ignore" });
  try {
    for (let i = 0; i < 50; i++) {
      try { await fetch(`http://127.0.0.1:${PORT}/json/version`); break; } catch { await sleep(200); }
    }
    const target = await (await fetch(`http://127.0.0.1:${PORT}/json/new?about:blank`, { method: "PUT" })).json();
    const ws = new WebSocket(target.webSocketDebuggerUrl);
    await new Promise((r) => (ws.onopen = r));
    let id = 0;
    const pending = new Map(), errors = [];
    ws.onmessage = (e) => {
      const msg = JSON.parse(e.data);
      if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg.result); pending.delete(msg.id); }
      if (msg.method === "Runtime.exceptionThrown") errors.push(msg.params.exceptionDetails.exception?.description || "error");
      if (msg.method === "Runtime.consoleAPICalled" && msg.params.type === "error") errors.push(JSON.stringify(msg.params.args));
    };
    const send = (method, params = {}) => new Promise((r) => { pending.set(++id, r); ws.send(JSON.stringify({ id, method, params })); });
    await send("Runtime.enable");
    await send("Page.navigate", { url: page }); // keeps the #selftest part of the address
    const read = `JSON.stringify({status: document.getElementById("rebuild-status")?.textContent,
      badge: document.getElementById("verdict-badge")?.textContent,
      rebuilt: document.getElementById("h-rebuilt")?.textContent,
      expected: document.getElementById("h-expected")?.textContent,
      start: document.getElementById("book")?.textContent.slice(0, 80)})`;
    const t0 = Date.now();
    let state = {};
    const limit = 1000 * Number(process.argv[3] || 300);
    while (Date.now() - t0 < limit) {
      const r = await send("Runtime.evaluate", { expression: read, returnByValue: true });
      state = JSON.parse(r.result.value || "{}");
      if (state.badge) break;
      await sleep(1000);
    }
    console.log("status  :", state.status);
    console.log("verdict :", state.badge || `(none after ${limit / 1000} s)`);
    console.log("rebuilt :", state.rebuilt);
    console.log("expected:", state.expected);
    console.log("book    :", JSON.stringify(state.start));
    console.log("page errors:", errors.length ? errors : "none");
    ws.close();
    process.exitCode = state.badge === "Identical" && !errors.length ? 0 : 1;
  } finally {
    chrome.kill();
  }
})();
