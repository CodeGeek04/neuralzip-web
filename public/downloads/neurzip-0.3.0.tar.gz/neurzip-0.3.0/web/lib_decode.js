#!/usr/bin/env node
// Rebuild books from this library with JavaScript, on all CPU cores. Needs Node.js 18+ and nothing else.
// Works for every book, and is the decoder for "compact" books (a model + an arithmetic-coded stream),
// because its math gives bit-identical results on every computer.
//
//   node decode.js --list
//   node decode.js <book>       # writes <book>.txt and checks its SHA-256
//   node decode.js --all        # rebuild and check every book
const fs = require("fs");
const os = require("os");
const path = require("path");
const crypto = require("crypto");
const { Worker, isMainThread, parentPort, workerData } = require("worker_threads");
const D = require("./decoder.js");

if (!isMainThread) {
  // A worker: build the model once, then rebuild the pieces of the book it is sent.
  const m = D.buildModel(workerData.pkg, workerData.blobs);
  parentPort.on("message", (task) => {
    const parts = [];
    if (task.stream) D.decodeSegment(m, task, task.stream, (c, bytes) => parts.push(Buffer.from(bytes)));
    else for (let c = task.first; c < task.first + task.count; c++) parts.push(Buffer.from(D.decodeChunk(m, c).bytes));
    parentPort.postMessage({ first: task.first, data: Buffer.concat(parts) });
  });
  return;
}

const ROOT = __dirname;
const copyU16 = (buf) => { const c = new Uint8Array(buf.length); c.set(buf); return new Uint16Array(c.buffer); };

function readSafetensors(file) {
  const buf = fs.readFileSync(file);
  const n = Number(buf.readBigUInt64LE(0));
  const header = JSON.parse(buf.subarray(8, 8 + n).toString("utf8"));
  const out = {};
  for (const [name, h] of Object.entries(header)) {
    if (name !== "__metadata__") out[name] = { shape: h.shape, data: buf.subarray(8 + n + h.data_offsets[0], 8 + n + h.data_offsets[1]) };
  }
  return out;
}

function loadBook(name) {
  const dir = path.join(ROOT, "books", name);
  const cfg = JSON.parse(fs.readFileSync(path.join(dir, "config.json"), "utf8"));
  const t = readSafetensors(path.join(dir, "model.safetensors"));
  const tensors = [], bf = [], qd = [], sc = [];
  let bfOff = 0, qOff = 0, sOff = 0;
  for (const [tname, x] of Object.entries(t)) {
    if (tname.endsWith(".scale")) continue;
    if (tname.endsWith(".q")) { // integer weights x one bf16 scale per row
      const base = tname.slice(0, -2), s = t[base + ".scale"];
      tensors.push({ name: base, kind: "q8", shape: x.shape, numel: x.shape[0] * x.shape[1], q_offset: qOff, scale_offset: sOff });
      qd.push(x.data); sc.push(s.data);
      qOff += x.data.length; sOff += s.data.length / 2;
    } else {
      tensors.push({ name: tname, kind: "bf16", shape: x.shape, numel: x.data.length / 2, offset: bfOff });
      bf.push(x.data);
      bfOff += x.data.length / 2;
    }
  }
  const blobs = { bf16: copyU16(Buffer.concat(bf)), qdata: new Uint8Array(Buffer.concat(qd)), scales: copyU16(Buffer.concat(sc)) };
  const text = cfg.texts[0];
  const pkg = { config: cfg.model, tensors, fixes: cfg.fixes || [],
    meta: { book_id: 0, chunk_len: cfg.chunk_len, total_len: cfg.total_len, n_chunks: cfg.n_chunks, sha256: text.sha256 } };
  return { dir, cfg, pkg, blobs, text };
}

function pool(tasks, nWorkers, data) {
  return new Promise((resolve, reject) => {
    const results = new Map(), workers = [];
    let next = 0, done = 0;
    const feed = (w) => { if (next < tasks.length) w.postMessage(tasks[next++]); };
    for (let i = 0; i < Math.min(nWorkers, tasks.length); i++) {
      const w = new Worker(__filename, { workerData: data });
      w.on("message", (r) => {
        results.set(r.first, r.data);
        if (++done === tasks.length) { workers.forEach((x) => x.terminate()); resolve(results); } else feed(w);
      });
      w.on("error", reject);
      workers.push(w);
      feed(w);
    }
  });
}

async function rebuild(name, nWorkers) {
  const { dir, cfg, pkg, blobs, text } = loadBook(name);
  let tasks;
  if (cfg.mode === "compact") {
    const stream = fs.readFileSync(path.join(dir, "stream.bin"));
    tasks = cfg.ac.segments.map((s) => ({ first: s.first, count: s.count,
      stream: new Uint8Array(stream.subarray(s.offset, s.offset + s.length)) }));
  } else {
    tasks = D.segmentPlan(cfg.n_chunks, Math.max(64, 4 * nWorkers));
  }
  const t0 = Date.now();
  const results = await pool(tasks, nWorkers, { pkg, blobs });
  const data = Buffer.concat(tasks.map((t) => results.get(t.first)));
  const ok = crypto.createHash("sha256").update(data).digest("hex") === text.sha256;
  console.log(`${name}: ${data.length.toLocaleString("en-US")} bytes in ${((Date.now() - t0) / 1000).toFixed(0)}s ` +
    `on ${nWorkers} cores (${cfg.mode === "compact" ? "model + stream" : "model alone"})  ${ok ? "OK, SHA-256 matches" : "MISMATCH"}`);
  return { data, ok };
}

(async () => {
  const args = process.argv.slice(2);
  const wi = args.indexOf("--workers");
  const nWorkers = wi >= 0 ? Number(args[wi + 1]) : Math.max(1, os.cpus().length - 1);
  const oi = args.indexOf("--out");
  const names = fs.readdirSync(path.join(ROOT, "books"))
    .filter((n) => fs.existsSync(path.join(ROOT, "books", n, "config.json"))).sort();
  const book = args.find((a, i) => !a.startsWith("--") && args[i - 1] !== "--workers" && args[i - 1] !== "--out");
  if (args.includes("--list") || (!book && !args.includes("--all"))) {
    for (const n of names) {
      const c = JSON.parse(fs.readFileSync(path.join(ROOT, "books", n, "config.json"), "utf8"));
      console.log(`${n.padEnd(34)} ${c.total_len.toLocaleString("en-US").padStart(12)} bytes  ` +
        `${(c.mode || "exact").padEnd(7)} ${c.package_bytes.toLocaleString("en-US").padStart(11)} B package`);
    }
    return;
  }
  let allOk = true;
  for (const n of args.includes("--all") ? names : [book]) {
    if (!names.includes(n)) { console.log(`no book called ${n}; see node decode.js --list`); process.exit(1); }
    const { data, ok } = await rebuild(n, nWorkers);
    allOk = allOk && ok;
    if (!args.includes("--all")) {
      const out = oi >= 0 ? args[oi + 1] : `${n}.txt`;
      fs.writeFileSync(out, data);
      console.log(`wrote ${out}`);
    }
  }
  process.exit(allOk ? 0 : 1);
})();
