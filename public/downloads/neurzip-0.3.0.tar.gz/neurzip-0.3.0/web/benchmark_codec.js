// Experimental benchmark container; not the published library format.
// node web/benchmark_codec.js pack input.package.json output.lcp
// node web/benchmark_codec.js decode input.lcp[.gz] output.txt [workers]
const fs = require("fs");
const path = require("path");
const zlib = require("zlib");
const crypto = require("crypto");
const { Worker, isMainThread, parentPort, workerData } = require("worker_threads");
const D = require("./decoder.js");
const MAGIC = Buffer.from("LLCPB001");

if (!isMainThread) {
  const m = D.buildModel(workerData.pkg, workerData.blobs);
  parentPort.on("message", (s) => {
    const parts = [];
    D.decodeSegment(m, s, D.base64ToBytes(s.stream_b64), (c, b) => parts.push(Buffer.from(b)));
    parentPort.postMessage({ first: s.first, bytes: Buffer.concat(parts) });
  });
} else {
  main().catch((e) => { console.error(e.stack); process.exitCode = 1; });
}

function pack(input, output) {
  const source = JSON.parse(fs.readFileSync(input, "utf8"));
  if (!source.ac || !source.ac.segments.length) throw new Error("Requires arithmetic-coded streams");
  // Store only the data needed by the decoder, including tensor shapes and offsets.
  const pkg = {
    format: "llm-compress-benchmark/1", config: source.config,
    meta: Object.fromEntries(["book_id", "chunk_len", "total_len", "n_chunks", "sha256"]
      .map((k) => [k, source.meta[k]])),
    quant: source.quant, tensors: source.tensors, fixes: [],
    ac: { bits: source.ac.bits, segments: [] }, blobs: {},
  };
  const parts = [];
  let offset = 0;
  const add = (data) => {
    const bytes = Buffer.from(data, "base64");
    const loc = { offset, length: bytes.length };
    parts.push(bytes); offset += bytes.length;
    return loc;
  };
  for (const key of ["weights_b64", "qdata_b64", "scales_b64"]) pkg.blobs[key] = add(source[key] || "");
  for (const s of source.ac.segments) {
    pkg.ac.segments.push({ first: s.first, count: s.count, ...add(s.stream_b64) });
  }
  const header = Buffer.from(JSON.stringify(pkg));
  const length = Buffer.alloc(4); length.writeUInt32LE(header.length);
  const archive = Buffer.concat([MAGIC, length, header, ...parts]);
  fs.writeFileSync(output, archive);
  const gzip = zlib.gzipSync(archive, { level: 9 });
  fs.writeFileSync(output + ".gz", gzip);
  console.log(JSON.stringify({ raw_bytes: archive.length, gzip_bytes: gzip.length,
    header_bytes: MAGIC.length + 4 + header.length, payload_bytes: offset,
    decoder_js_bytes: fs.statSync(path.join(__dirname, "decoder.js")).size,
    container_js_bytes: fs.statSync(__filename).size }));
}

function unpack(file) {
  let bytes = fs.readFileSync(file);
  if (bytes[0] === 0x1f && bytes[1] === 0x8b) bytes = zlib.gunzipSync(bytes);
  if (!bytes.subarray(0, 8).equals(MAGIC)) throw new Error("Invalid benchmark container");
  const end = 12 + bytes.readUInt32LE(8);
  if (end > bytes.length) throw new Error("Truncated header");
  const pkg = JSON.parse(bytes.subarray(12, end));
  const data = bytes.subarray(end);
  const read = (s) => {
    if (!Number.isSafeInteger(s.offset) || !Number.isSafeInteger(s.length) || s.offset < 0 || s.length < 0 ||
        s.offset + s.length > data.length) throw new Error("Invalid payload range");
    return data.subarray(s.offset, s.offset + s.length).toString("base64");
  };
  for (const [key, loc] of Object.entries(pkg.blobs)) pkg[key] = read(loc);
  pkg.ac.segments = pkg.ac.segments.map((s) => ({ ...s, stream_b64: read(s) }));
  return pkg;
}

async function decode(input, output, nWorkers) {
  if (!Number.isInteger(nWorkers) || nWorkers < 1) throw new Error("workers must be a positive integer");
  const t0 = performance.now(), pkg = unpack(input);
  const tasks = pkg.ac.segments;
  if (!tasks.length) throw new Error("No streams");
  const blobs = D.decodeBlobs(pkg);
  const lite = { ...pkg, ac: null, weights_b64: "", qdata_b64: "", scales_b64: "" };
  const out = Buffer.alloc(pkg.meta.total_len);
  const workers = [];
  try {
    await new Promise((resolve, reject) => {
      let next = 0, done = 0;
      const feed = (w) => { if (next < tasks.length) w.postMessage(tasks[next++]); };
      for (let i = 0; i < Math.min(nWorkers, tasks.length); i++) {
        const w = new Worker(__filename, { workerData: { pkg: lite, blobs } });
        workers.push(w);
        w.on("error", reject);
        w.on("exit", (code) => { if (code !== 0) reject(new Error(`Worker exited ${code}`)); });
        w.on("message", (r) => {
          out.set(r.bytes, r.first * pkg.meta.chunk_len);
          if (++done === tasks.length) resolve(); else feed(w);
        });
        feed(w);
      }
    });
  } finally {
    await Promise.all(workers.map((w) => w.terminate()));
  }
  const sha256 = crypto.createHash("sha256").update(out).digest("hex");
  if (sha256 !== pkg.meta.sha256) throw new Error("SHA-256 mismatch; output was not written");
  fs.writeFileSync(output, out);
  console.log(JSON.stringify({ bytes: out.length, sha256, verified: true,
    decode_seconds: (performance.now() - t0) / 1000, workers: nWorkers }));
}

async function main() {
  const [cmd, input, output, workers = "4"] = process.argv.slice(2);
  if (!input || !output) throw new Error("Usage: benchmark_codec.js pack|decode INPUT OUTPUT [WORKERS]");
  if (cmd === "pack") pack(input, output);
  else if (cmd === "decode") await decode(input, output, Number(workers));
  else throw new Error("Expected pack or decode");
}
