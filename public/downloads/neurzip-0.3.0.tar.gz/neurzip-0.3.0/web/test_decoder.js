// Rebuild the whole book with the JavaScript model (web/decoder.js) and check it.
// Usage: node web/test_decoder.js web/build/alice.package.json [data/alice.txt]
const fs = require("fs");
const crypto = require("crypto");
const D = require("./decoder.js");

const pkg = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
const original = process.argv[3] ? fs.readFileSync(process.argv[3]) : null;
const m = D.buildModel(pkg, D.decodeBlobs(pkg));
const { n_chunks, chunk_len, total_len, sha256 } = pkg.meta;
console.log(`model: ${m.n_params.toLocaleString("en-US")} params, ${n_chunks} chunks of ${chunk_len} bytes, ${pkg.fixes.length} fixes`);

const out = new Uint8Array(total_len);
const t0 = Date.now();
for (let i = 0; i < n_chunks; i++) {
  out.set(D.decodeChunk(m, i).bytes, i * chunk_len);
  if ((i + 1) % 100 === 0 || i === n_chunks - 1) console.log(`  ${i + 1}/${n_chunks} chunks, ${((Date.now() - t0) / 1000).toFixed(1)}s`);
}

const jsHash = D.sha256Hex(out);
const nodeHash = crypto.createHash("sha256").update(out).digest("hex");
console.log(`sha256 (our JS code): ${jsHash}`);
console.log(`sha256 (Node crypto): ${nodeHash}`);
console.log(`sha256 expected     : ${sha256}`);
let ok = jsHash === sha256 && nodeHash === sha256;
if (original) {
  const same = Buffer.compare(Buffer.from(out), original) === 0;
  console.log(same ? `IDENTICAL to ${process.argv[3]}` : `DIFFERENT from ${process.argv[3]}`);
  ok = ok && same;
}
process.exit(ok ? 0 : 1);
