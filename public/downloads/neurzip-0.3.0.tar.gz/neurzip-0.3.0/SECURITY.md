# Archive handling

The release decoder reads a bounded binary/JSON format and treats weights as
data. It does not load user-provided Python pickle or execute archive contents.
Output is saved only after its length and SHA-256 match the archive metadata.
An attacker can also alter the checksum; it is an integrity check, not a signature.

Malformed headers, tensor sizes, payload ranges and chunk coverage are rejected.
Neural workloads can be slow. The browser has cancellation, and Python has
per-call engine timeouts and a configurable worker count. Use published limits
when integrating the library into a service.

Before a public repository is configured, send security findings directly to
the maintainer through the channel where this release was shared. Once GitHub
hosting is established, use its private vulnerability reporting feature if
enabled. Avoid posting private documents or working exploit payloads publicly.
