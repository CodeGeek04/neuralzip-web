"""Get the book back out of a trained model.

Two ways, which must agree:

  check()        Fast. One batched pass over the real text ("teacher forcing").
                 Counts positions where the model's top guess is not the true byte.

  decode_book()  Real. Start from each chunk's key and let the model write the chunk
                 one byte at a time, always taking its top guess (greedy).

If check() finds 0 wrong bytes, decode_book() reproduces the book exactly: at every
step the model sees the same context it was checked on. We still run the real
decode and compare, because tiny floating point differences between the two code
paths can flip a near-tie.

Fixes: if the model gets some bytes wrong, we store (chunk, offset, correct byte)
for each one. While decoding, the fix replaces the model's guess, so the following
bytes still see the right context. Model + fixes is always lossless.

CLI (rebuild a book from a saved model, in a fresh process):
    python decode.py runs/<run>/model_bf16.pt --compare data/alice.txt
    python decode.py runs/<run>/model_bf16.pt --compare data/alice.txt --show 100 --device cpu
"""
import argparse
import hashlib
import math
import time

import torch
import torch.nn.functional as F

from chunks import IGNORE, KEY_LEN, build_sequences, make_key
from model import Config, Model, pick_device

N_BYTES = 256  # the model may only output byte tokens, never the KEY marker


@torch.no_grad()
def check(model, inputs, targets, batch_size=256):
    """Teacher-forced pass over every chunk. Returns counts and confidence numbers."""
    dev = next(model.parameters()).device
    wrong, n, nll = 0, 0, 0.0
    min_margin, min_p = float("inf"), 1.0
    wrong_per_chunk, wrong_at = [], []
    for start in range(0, len(inputs), batch_size):
        x = inputs[start:start + batch_size].to(dev)
        y = targets[start:start + batch_size].to(dev)
        logits = model(x)[..., :N_BYTES].float()
        has_target = y != IGNORE
        t = y.clamp(min=0).unsqueeze(-1)
        logp_true = F.log_softmax(logits, -1).gather(-1, t).squeeze(-1)
        # margin = score of the true byte minus the best score of any other byte (> 0: top guess is right)
        margin = logits.gather(-1, t).squeeze(-1) - logits.scatter(-1, t, float("-inf")).amax(-1)
        bad = (logits.argmax(-1) != y) & has_target  # exactly what greedy decoding would get wrong

        wrong += int(bad.sum())
        n += int(has_target.sum())
        nll += float(-logp_true[has_target].sum())
        min_margin = min(min_margin, float(margin[has_target].min()))
        min_p = min(min_p, float(logp_true[has_target].min().exp()))
        wrong_per_chunk += bad.sum(1).tolist()
        # Copy all wrong positions to the CPU in one go (reading them one by one stalls the GPU).
        for (row, pos), byte in zip(bad.nonzero().tolist(), y[bad].tolist()):
            wrong_at.append([start + row, pos - (KEY_LEN - 1), byte])
    bits = nll / math.log(2)
    return {
        "wrong": wrong, "bytes": n,
        "exact_chunks": sum(w == 0 for w in wrong_per_chunk), "chunks": len(wrong_per_chunk),
        "bits": bits, "bpb": bits / n, "min_margin": min_margin, "min_p": min_p,
        "wrong_at": wrong_at,  # [chunk, offset, true byte] for every wrong position
    }


@torch.no_grad()
def decode_chunks(model, book_id, chunk_ids, chunk_len, fixes=None):
    """Greedy-decode the given chunks in parallel, starting from their keys only.

    fixes: {(chunk, offset): byte} to force at those positions instead of the model's guess.
    """
    dev = next(model.parameters()).device
    chunk_ids = list(chunk_ids)
    row_of = {c: row for row, c in enumerate(chunk_ids)}
    forced = torch.full((len(chunk_ids), chunk_len), -1, dtype=torch.long)
    for (c, offset), byte in (fixes or {}).items():
        if c in row_of:
            forced[row_of[c], offset] = byte
    forced = forced.to(dev)

    seq = torch.tensor([make_key(book_id, c) for c in chunk_ids], device=dev)
    for j in range(chunk_len):
        guess = model(seq)[:, -1, :N_BYTES].argmax(-1)
        nxt = torch.where(forced[:, j] >= 0, forced[:, j], guess)
        seq = torch.cat([seq, nxt[:, None]], dim=1)
    return [bytes(row[KEY_LEN:].tolist()) for row in seq.cpu()]


@torch.no_grad()
def decode_book(model, meta, fixes=None, batch_size=200):
    """Rebuild the whole book from keys (+ optional fixes)."""
    fix_map = {(c, o): b for c, o, b in (fixes or [])}
    out = []
    for start in range(0, meta["n_chunks"], batch_size):
        ids = range(start, min(start + batch_size, meta["n_chunks"]))
        out += decode_chunks(model, meta["book_id"], ids, meta["chunk_len"], fix_map)
    return b"".join(out)[:meta["total_len"]]


def make_lossless(model, meta, text, inputs, targets, max_rounds=20):
    """Find the fixes that make decoding exact, and prove it with a real decode.

    Starts from the fast check's wrong positions. If the real decode still differs
    somewhere (a floating point near-tie), adds a fix at the first differing byte
    of each bad chunk and decodes again.
    """
    fixes = {(c, o): b for c, o, b in check(model, inputs, targets)["wrong_at"]}
    L = meta["chunk_len"]
    for _ in range(max_rounds):
        as_list = sorted([c, o, b] for (c, o), b in fixes.items())
        book = decode_book(model, meta, as_list)
        if book == text:
            return as_list
        for c in range(meta["n_chunks"]):
            want, got = text[c * L:(c + 1) * L], book[c * L:(c + 1) * L]
            if want != got:
                o = next(j for j in range(len(want)) if want[j] != got[j])
                fixes[(c, o)] = want[o]
    raise RuntimeError("could not make the decode exact")


def fix_size(chunk_len):
    """Bytes per fix: chunk number (2) + offset inside the chunk (1, or 2 for chunks over 256) + correct byte (1)."""
    return 2 + (1 if chunk_len <= 256 else 2) + 1


def pack_fixes(fixes, chunk_len):
    """[[chunk, offset, byte], ...] -> uint8 tensor of exactly fix_size(chunk_len) bytes per fix."""
    off_len = fix_size(chunk_len) - 3
    raw = b"".join(c.to_bytes(2, "big") + o.to_bytes(off_len, "big") + bytes([b]) for c, o, b in fixes)
    return torch.tensor(list(raw), dtype=torch.uint8)


def unpack_fixes(packed, chunk_len):
    size, raw = fix_size(chunk_len), bytes(packed.tolist())
    off_len = size - 3
    return [[int.from_bytes(raw[i:i + 2], "big"), int.from_bytes(raw[i + 2:i + 2 + off_len], "big"), raw[i + 2 + off_len]]
            for i in range(0, len(raw), size)]


def compare_chunk(model, meta, text, i):
    """Decode chunk i and return two display lines: the true text and the model's text."""
    L = meta["chunk_len"]
    truth = text[i * L:(i + 1) * L]
    got = decode_chunks(model, meta["book_id"], [i], L)[0][:len(truth)]
    first_bad = next((j for j, (a, b) in enumerate(zip(truth, got)) if a != b), None)
    at = 0 if first_bad is None else max(0, first_bad - 40)

    def show(b):
        return b[at:at + 90].decode("utf-8", "replace").replace("\n", "⏎")

    status = f"all {len(truth)} bytes right" if first_bad is None else f"first wrong byte at {first_bad} of {len(truth)}"
    where = "" if at == 0 else f" (from byte {at})"
    return [f"    chunk {i} truth: {show(truth)}",
            f"    chunk {i} model: {show(got)}   [model alone, no fixes: {status}]{where}"]


def load(path, device):
    """Load a saved model: weights (fp32 or bf16 on disk, computed in fp32) + settings + fixes."""
    ck = torch.load(path, map_location="cpu", weights_only=True)
    model = Model(Config(**ck["config"]))
    if "qweights" in ck:  # integer weights x per-row scales (see quant.py)
        import quant
        model.load_state_dict(quant.unpack(ck))
    else:
        model.load_state_dict({k: v.float() for k, v in ck["state_dict"].items()})
    return model.to(device).eval(), ck["meta"], unpack_fixes(ck["fixes"], ck["meta"]["chunk_len"])


def main():
    ap = argparse.ArgumentParser(description="Rebuild a book from a saved model and check it.")
    ap.add_argument("checkpoint")
    ap.add_argument("--compare", help="original text file to compare against")
    ap.add_argument("--out", help="where to write the decoded book (default: next to the checkpoint)")
    ap.add_argument("--device", default=pick_device())
    ap.add_argument("--show", type=int, help="also print this chunk next to the truth")
    args = ap.parse_args()

    model, meta, fixes = load(args.checkpoint, args.device)
    print(f"model: {model.n_params():,} params, {meta['n_chunks']} chunks of {meta['chunk_len']} bytes, "
          f"{len(fixes)} fixes, device {args.device}")
    t0 = time.time()
    book = decode_book(model, meta, fixes)
    print(f"decoded {len(book):,} bytes in {time.time() - t0:.1f}s")
    out = args.out or args.checkpoint.rsplit(".", 1)[0] + ".decoded.txt"
    open(out, "wb").write(book)
    print(f"wrote {out}")
    print(f"sha256 decoded : {hashlib.sha256(book).hexdigest()}")
    print(f"sha256 expected: {meta['sha256']}")
    if hashlib.sha256(book).hexdigest() == meta["sha256"]:
        print("OK: the decoded book matches the fingerprint stored in the package, byte for byte")
    else:
        print("MISMATCH: the decoded book does not match the fingerprint stored in the package")

    if args.compare:
        text = open(args.compare, "rb").read()
        if book == text:
            print(f"IDENTICAL to {args.compare}: every one of {len(text):,} bytes matches")
        else:
            first = next((i for i, (a, b) in enumerate(zip(book, text)) if a != b), min(len(book), len(text)))
            print(f"DIFFERENT from {args.compare}: first difference at byte {first:,}")
        if args.show is not None:
            print("\n".join(compare_chunk(model, meta, text, args.show)))


if __name__ == "__main__":
    main()
