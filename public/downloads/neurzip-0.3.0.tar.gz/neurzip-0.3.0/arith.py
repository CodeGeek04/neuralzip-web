"""Arithmetic coding: turn a sequence of symbols into bits, given probabilities.

Each symbol costs about -log2(p) bits, where p is the probability it was given.
The encoder and the decoder must use exactly the same frequency tables.

Frequencies are integers: `cum` is the running total over the 256 byte values
(cum[s] = freq[0] + ... + freq[s]), so byte s owns the slice [cum[s-1], cum[s])
out of a total of cum[255].

Integer coder after Project Nayuki's reference arithmetic coder (MIT license).
"""
import torch

STATE_BITS = 32
FULL = 1 << STATE_BITS
HALF = FULL >> 1
QUARTER = HALF >> 1
MASK = FULL - 1
MAX_TOTAL = QUARTER + 2  # frequency totals must not exceed this


class BitWriter:
    def __init__(self):
        self.out, self.cur, self.n = bytearray(), 0, 0

    def write(self, bit):
        self.cur = (self.cur << 1) | bit
        self.n += 1
        if self.n == 8:
            self.out.append(self.cur)
            self.cur, self.n = 0, 0

    def getvalue(self):
        if self.n:  # pad the last byte with zeros
            return bytes(self.out) + bytes([self.cur << (8 - self.n)])
        return bytes(self.out)


class BitReader:
    def __init__(self, data):
        self.data, self.pos = data, 0

    def read(self):  # past the end, read zeros
        byte, bit = divmod(self.pos, 8)
        self.pos += 1
        if byte >= len(self.data):
            return 0
        return (self.data[byte] >> (7 - bit)) & 1


class _Coder:
    def __init__(self):
        self.low, self.high = 0, MASK

    def _update(self, cum_low, cum_high, total):
        assert 0 <= cum_low < cum_high <= total <= MAX_TOTAL
        span = self.high - self.low + 1
        self.high = self.low + cum_high * span // total - 1
        self.low = self.low + cum_low * span // total
        while ((self.low ^ self.high) & HALF) == 0:  # top bits agree: that bit is settled
            self._shift()
            self.low = (self.low << 1) & MASK
            self.high = ((self.high << 1) & MASK) | 1
        while (self.low & ~self.high & QUARTER) != 0:  # straddling the middle: postpone a bit
            self._underflow()
            self.low = (self.low << 1) ^ HALF
            self.high = ((self.high ^ HALF) << 1) | HALF | 1


class Encoder(_Coder):
    def __init__(self, writer):
        super().__init__()
        self.w, self.pending = writer, 0

    def write(self, cum, symbol):
        """Code `symbol` using the cumulative frequency table `cum` (CPU LongTensor of 256)."""
        low = int(cum[symbol - 1]) if symbol else 0
        self._update(low, int(cum[symbol]), int(cum[-1]))

    def finish(self):
        self.w.write(1)

    def _shift(self):
        bit = self.low >> (STATE_BITS - 1)
        self.w.write(bit)
        for _ in range(self.pending):
            self.w.write(bit ^ 1)
        self.pending = 0

    def _underflow(self):
        self.pending += 1


class Decoder(_Coder):
    def __init__(self, reader):
        super().__init__()
        self.r, self.code = reader, 0
        for _ in range(STATE_BITS):
            self.code = (self.code << 1) | self.r.read()

    def read(self, cum):
        """Recover the next symbol, given the same cumulative frequency table the encoder used."""
        total = int(cum[-1])
        span = self.high - self.low + 1
        value = ((self.code - self.low + 1) * total - 1) // span
        symbol = int(torch.searchsorted(cum, torch.tensor(value), right=True))
        low = int(cum[symbol - 1]) if symbol else 0
        self._update(low, int(cum[symbol]), total)
        return symbol

    def _shift(self):
        self.code = ((self.code << 1) & MASK) | self.r.read()

    def _underflow(self):
        self.code = (self.code & HALF) | ((self.code << 1) & (MASK >> 1)) | self.r.read()
