"""Make a zip you can send to anyone: the web page, the Python package, and instructions.

Usage:
    python make_bundle.py runs/alice-L4-d48-c252/model_bf16.pt --name alice-in-265KB
Writes dist/<name>/ and dist/<name>.zip
"""
import argparse
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

import torch

from decode import unpack_fixes

README = """{title}
{underline}

This folder holds a small neural network ({params:,} learned numbers, {weights_kb} KB in total)
that was trained to write {book_title} back out, byte for byte.
The book's text is not stored anywhere in here. You get it back by running the model.


OPTION 1: IN YOUR BROWSER (nothing to install)

  1. Double-click  {html_name}  (Chrome, Safari, Firefox or Edge).
  2. Click "Rebuild all {n_chunks} chunks". It takes a few seconds.
  3. You should see IDENTICAL, and this fingerprint (SHA-256) twice:
       {sha}
     The rebuilt book appears below it. "Copy rebuilt text" copies it.

  Also on the page: "Watch one chunk being written" shows the model typing any of
  the {n_chunks} pieces from its key alone, shading the letters it was least sure of.


OPTION 2: IN A TERMINAL (Python)

  Needs Python 3.10 or newer.

    cd python
    pip install torch numpy
    python decode.py {pt_name}

  Or, with uv installed, without touching your Python setup:

    cd python
    uv run --no-project --with torch --with numpy python decode.py {pt_name}

  It takes about a minute, writes the book to {decoded_name}, and prints
  "OK: the decoded book matches the fingerprint stored in the package".


WHAT IS IN HERE

  {html_name}            the model and a JavaScript decoder in one page
                          (the weights are inside it as text; there is no book text)
  python/{pt_name}    the package: {params:,} weights ({weight_desc}), 10 settings, {n_fixes} fixes
  python/model.py         the network (about 150 lines of PyTorch)
  python/chunks.py        how the book is cut into keyed pieces
  python/decode.py        rebuilds the book from the package and checks the fingerprint
  python/quant.py         turns stored small integers back into weights


HOW IT WORKS

  The book ({book_bytes:,} bytes) was cut into {n_chunks} pieces of {chunk_len} bytes.
  To get piece i, the model is given only a 4-token key (a marker, book 0, i / 256,
  i % 256) and writes the {chunk_len} bytes that follow, one at a time, always taking
  its most likely next byte. It was trained from random numbers on this one book
  until every byte came out right.

  Package size: {package_bytes:,} bytes for a {book_bytes:,}-byte book ({ratio:.3f}x).


WILL I GET EXACTLY THE SAME BOOK?

  Yes. This package was rebuilt identically by PyTorch on an Apple GPU, PyTorch on a
  CPU, JavaScript in Node and the web page in Chrome. At every byte, the model's top
  choice leads the runner-up by at least {margin:.2f}, while different computers' rounding
  moves those scores by about 0.001, so no computer can pick a different byte. And both
  decoders check the result against the fingerprint above: if anything ever went wrong
  they would say so, never hand you a silently different book.

  The text is Project Gutenberg eBook #11 with Gutenberg's license header and footer
  removed and line endings as plain newlines.
"""


def main():
    ap = argparse.ArgumentParser(description="Bundle a package for sending.")
    ap.add_argument("checkpoint")
    ap.add_argument("--name", required=True, help="folder and zip name, e.g. alice-in-265KB")
    ap.add_argument("--title", default="Alice's Adventures in Wonderland, stored in a neural network")
    ap.add_argument("--margin", type=float, default=1.31, help="smallest margin, from check_determinism.py")
    args = ap.parse_args()

    ck_path = Path(args.checkpoint)
    run = ck_path.parent.name
    ck = torch.load(ck_path, map_location="cpu", weights_only=True)
    meta, cfg = ck["meta"], ck["config"]
    params = sum(t.numel() for t in ck["state_dict"].values()) + sum(
        t["shape"][0] * t["shape"][1] for t in ck.get("qweights", {}).values())
    weights = ck.get("weights_bytes", params * next(iter(ck["state_dict"].values())).element_size())
    bits = ck.get("quant", {}).get("bits")
    weight_desc = {8: "1 byte each, plus one scale per row", 4: "half a byte each, plus one scale per row"}.get(
        bits, "2 bytes each")
    n_fixes = len(unpack_fixes(ck["fixes"], meta["chunk_len"]))
    package = weights + 4 * n_fixes + 4 * (3 + len(cfg))

    html = Path("web/build") / f"{run}.html"
    subprocess.run([sys.executable, "export_web.py", str(ck_path), "--title", f"Wonderland in {round(weights / 1000)} KB",
                    "--eyebrow", f"llm-compress · {params:,} parameters"], check=True, stdout=subprocess.DEVNULL)

    out = Path("dist") / args.name
    if out.exists():
        shutil.rmtree(out)
    (out / "python").mkdir(parents=True)
    html_name = f"{Path(meta['text']).stem}.html"
    shutil.copy(html, out / html_name)
    shutil.copy(ck_path, out / "python" / ck_path.name)
    for f in ("model.py", "chunks.py", "decode.py", "quant.py"):
        shutil.copy(f, out / "python" / f)
    (out / "python" / "requirements.txt").write_text("torch>=2.4\nnumpy\n")
    (out / "README.txt").write_text(README.format(
        title=args.title, underline="=" * len(args.title), params=params, weights_kb=round(weights / 1000),
        book_title="Alice's Adventures in Wonderland", html_name=html_name, n_chunks=meta["n_chunks"],
        sha=meta["sha256"], n_fixes=n_fixes, book_bytes=meta["total_len"], chunk_len=meta["chunk_len"],
        package_bytes=package, ratio=meta["total_len"] / package, margin=args.margin, pt_name=ck_path.name,
        decoded_name=ck_path.stem + ".decoded.txt", weight_desc=weight_desc))

    zip_path = Path("dist") / f"{args.name}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(out.rglob("*")):
            z.write(f, f.relative_to(out.parent))
    for f in sorted(out.rglob("*")):
        if f.is_file():
            print(f"  {f.relative_to('dist')}  ({f.stat().st_size:,} bytes)")
    print(f"wrote {zip_path} ({zip_path.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
