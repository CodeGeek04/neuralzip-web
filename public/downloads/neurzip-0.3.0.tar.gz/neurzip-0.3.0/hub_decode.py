"""Rebuild the books stored in this repository's models, and check them.

Needs Python 3.10+ and:  pip install torch safetensors

    python decode.py --list              # every model and the texts it holds
    python decode.py alice               # rebuild one text, check its SHA-256, write alice.txt
    python decode.py alice --chunk 42    # print one chunk, written from its key alone
    python decode.py --all               # rebuild and check everything

How it works: each model was trained on its text cut into chunks of 252 bytes. Chunk i
is written by the model from a 4-token key (a marker, then i as three bytes), one byte
at a time, always taking the most likely next byte. The keys are just chunk numbers,
so the repository stores no text: only weights (small integers and one scale per row).
"""
import argparse
import hashlib
import json
import math
import os
import shutil
import subprocess
import time
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F
from safetensors.torch import load_file

KEY, KEY_LEN, N_BYTES = 256, 4, 256
ROOT = Path(__file__).resolve().parent


# ---- the network (identical to model.py in the llm-compress project) ---------------
class RMSNorm(nn.Module):
    def __init__(self, dim, eps=1e-6):
        super().__init__()
        self.eps, self.weight = eps, nn.Parameter(torch.ones(dim))

    def forward(self, x):
        return x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps) * self.weight


def rope(x, cos, sin):
    half = x.shape[-1] // 2
    x1, x2 = x[..., :half], x[..., half:]
    return torch.cat([x1 * cos - x2 * sin, x1 * sin + x2 * cos], dim=-1)


class Attention(nn.Module):
    def __init__(self, d, heads):
        super().__init__()
        self.n_head, self.head_dim = heads, d // heads
        self.q, self.k, self.v, self.o = (nn.Linear(d, d, bias=False) for _ in range(4))
        self.q_norm, self.k_norm = RMSNorm(self.head_dim), RMSNorm(self.head_dim)

    def forward(self, x, cos, sin):
        B, T, D = x.shape
        heads = lambda t: t.view(B, T, self.n_head, self.head_dim).transpose(1, 2)
        q = rope(self.q_norm(heads(self.q(x))), cos, sin)
        k = rope(self.k_norm(heads(self.k(x))), cos, sin)
        y = F.scaled_dot_product_attention(q, k, heads(self.v(x)), is_causal=True)
        return self.o(y.transpose(1, 2).reshape(B, T, D))


class MLP(nn.Module):
    def __init__(self, d, ff):
        super().__init__()
        self.gate, self.up, self.down = nn.Linear(d, ff, bias=False), nn.Linear(d, ff, bias=False), nn.Linear(ff, d, bias=False)

    def forward(self, x):
        return self.down(F.silu(self.gate(x)) * self.up(x))


class Block(nn.Module):
    def __init__(self, d, heads, ff):
        super().__init__()
        self.attn_norm, self.attn = RMSNorm(d), Attention(d, heads)
        self.mlp_norm, self.mlp = RMSNorm(d), MLP(d, ff)

    def forward(self, x, cos, sin):
        x = x + self.attn(self.attn_norm(x), cos, sin)
        return x + self.mlp(self.mlp_norm(x))


class Model(nn.Module):
    def __init__(self, vocab_size, n_layer, d_model, n_head, d_ff, max_len, rope_theta):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.blocks = nn.ModuleList(Block(d_model, n_head, d_ff) for _ in range(n_layer))
        self.norm = RMSNorm(d_model)
        hd = d_model // n_head
        inv_freq = 1.0 / rope_theta ** (torch.arange(0, hd, 2).float() / hd)
        angles = torch.outer(torch.arange(max_len).float(), inv_freq)
        self.register_buffer("cos", angles.cos(), persistent=False)
        self.register_buffer("sin", angles.sin(), persistent=False)

    def forward(self, idx):
        T = idx.shape[1]
        x = self.embed(idx)
        for block in self.blocks:
            x = block(x, self.cos[:T], self.sin[:T])
        return self.norm(x) @ self.embed.weight.T


# ---- loading and decoding -------------------------------------------------------------
def load_package(folder, device):
    cfg = json.loads((folder / "config.json").read_text())
    tensors = load_file(str(folder / "model.safetensors"))
    state = {}
    for name, t in tensors.items():
        if name.endswith(".scale"):
            continue
        if name.endswith(".q"):  # integer weights x one scale per row
            state[name[:-2]] = t.float() * tensors[name[:-2] + ".scale"].float()[:, None]
        else:
            state[name] = t.float()
    model = Model(**cfg["model"])
    model.load_state_dict(state)
    fixes = {(c, o): b for c, o, b in cfg.get("fixes", [])}
    return model.to(device).eval(), cfg, fixes


def chunk_key(i):
    return [KEY, i >> 16, (i >> 8) & 255, i & 255]


@torch.no_grad()
def write_chunks(model, ids, lengths, fixes, device):
    """Greedy-decode chunks in parallel from their keys; stored fixes (if any) override the model."""
    L = max(lengths)
    forced = torch.full((len(ids), L), -1, dtype=torch.long)
    for r, c in enumerate(ids):
        for j in range(lengths[r]):
            if (c, j) in fixes:
                forced[r, j] = fixes[(c, j)]
    forced = forced.to(device)
    seq = torch.tensor([chunk_key(c) for c in ids], device=device)
    for j in range(L):
        guess = model(seq)[:, -1, :N_BYTES].argmax(-1)
        seq = torch.cat([seq, torch.where(forced[:, j] >= 0, forced[:, j], guess)[:, None]], dim=1)
    return [bytes(row[KEY_LEN:KEY_LEN + n].tolist()) for row, n in zip(seq.cpu(), lengths)]


def rebuild(model, cfg, fixes, text, device, batch=200):
    """Rebuild one text: decode the chunks that cover it, then cut it out."""
    L, total = cfg["chunk_len"], cfg["total_len"]
    first, last = text["start"] // L, (text["start"] + text["length"] - 1) // L
    out = []
    for s in range(first, last + 1, batch):
        ids = list(range(s, min(s + batch, last + 1)))
        out += write_chunks(model, ids, [min(L, total - c * L) for c in ids], fixes, device)
    data = b"".join(out)
    off = text["start"] - first * L
    return data[off:off + text["length"]]


def packages():
    for cfg_path in sorted((ROOT / "books").glob("*/config.json")):
        yield cfg_path.parent, json.loads(cfg_path.read_text())


def find(slug):
    for folder, cfg in packages():
        for text in cfg["texts"]:
            if text["slug"] == slug:
                return folder, text
    raise SystemExit(f"no text called {slug!r}; see python decode.py --list")


def pick_device():
    if torch.cuda.is_available():
        return "cuda"
    return "mps" if torch.backends.mps.is_available() else "cpu"


def main():
    ap = argparse.ArgumentParser(description="Rebuild texts from the models in this repository.")
    ap.add_argument("slug", nargs="?", help="which text to rebuild (see --list)")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--all", action="store_true", help="rebuild and check every text")
    ap.add_argument("--chunk", type=int, help="print one chunk of the text, from its key")
    ap.add_argument("--out", help="where to write the text (default: <slug>.txt)")
    ap.add_argument("--device", default=pick_device())
    args = ap.parse_args()

    if args.list or not (args.slug or args.all):
        for folder, cfg in packages():
            for t in cfg["texts"]:
                print(f"{t['slug']:<34} {t['length']:>11,} bytes  {cfg.get('mode', 'exact'):<7} "
                      f"{cfg['package_bytes']:>11,} B package  {t.get('title', '')}")
        return

    targets = [(f, t) for f, cfg in packages() for t in cfg["texts"]] if args.all else [find(args.slug)]
    loaded = {}
    for folder, text in targets:
        if json.loads((folder / "config.json").read_text()).get("mode") == "compact":
            if args.chunk is not None:
                raise SystemExit("--chunk works for exact books; a compact book is decoded whole (its stream runs in order)")
            # compact books need bit-identical arithmetic on every computer: that is decode.js (Node.js 18+)
            node = shutil.which("node")
            if not node:
                raise SystemExit(f"{text['slug']} is a compact book: install Node.js 18+ and run  node decode.js {text['slug']}")
            out = os.devnull if args.all else (args.out or f"{text['slug']}.txt")
            code = subprocess.call([node, str(ROOT / "decode.js"), text["slug"], "--out", out])
            if code:
                raise SystemExit(code)
            continue
        if folder not in loaded:
            loaded[folder] = load_package(folder, args.device)
        model, cfg, fixes = loaded[folder]
        if args.chunk is not None:
            L = cfg["chunk_len"]
            c = text["start"] // L + args.chunk
            print(write_chunks(model, [c], [min(L, cfg["total_len"] - c * L)], fixes, args.device)[0]
                  .decode("utf-8", "replace"))
            return
        t0 = time.time()
        data = rebuild(model, cfg, fixes, text, args.device)
        ok = hashlib.sha256(data).hexdigest() == text["sha256"]
        print(f"{text['slug']}: {len(data):,} bytes in {time.time() - t0:.0f}s on {args.device}  "
              f"{'OK, SHA-256 matches' if ok else 'MISMATCH'}")
        if not args.all:
            out = Path(args.out or f"{text['slug'].replace('/', '--')}.txt")
            out.write_bytes(data)
            print(f"wrote {out}")
        if not ok:
            raise SystemExit(1)


if __name__ == "__main__":
    main()
