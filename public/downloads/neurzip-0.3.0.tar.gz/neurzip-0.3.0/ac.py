"""Arithmetic-coded corrections: store a book as model + a compact bit stream.

Plain fixes pay 32 bits for every byte the model's top guess gets wrong, and 0
for the rest. Here, at every byte the model gives probabilities for all 256
values, and the true byte is coded with them: about -log2(p) bits. A confident
correct guess costs almost nothing, a near miss a few bits, never a flat 32.

The decoder runs the same model, in the same order, on the same device, and
reads the bits to recover each byte. Encoder and decoder share one function
(`_walk`) so their probability tables match exactly.

Usage:
    python ac.py runs/alice-L4-d24-c252/model_bf16.pt              # encode, save, decode, verify
    python ac.py runs/alice-L4-d24-c252/model_bf16.pt --decode-only  # rebuild the book from the saved stream
"""
import argparse
import hashlib
import json
import time
from pathlib import Path

import torch

from arith import BitReader, BitWriter, Decoder, Encoder
from chunks import make_key
from decode import N_BYTES, load
from model import pick_device

SCALE = 1 << 24  # probabilities become integer frequencies out of about 2^24


@torch.no_grad()
def _walk(model, meta, pick, batch_size=200):
    """Visit every byte of every chunk in one fixed order. At each byte, compute the model's
    frequency table and call pick(chunk, j, cum), which returns the byte to feed back in."""
    dev = next(model.parameters()).device
    L, n = meta["chunk_len"], meta["n_chunks"]
    for start in range(0, n, batch_size):
        ids = list(range(start, min(start + batch_size, n)))
        lengths = [min(L, meta["total_len"] - c * L) for c in ids]
        seq = torch.tensor([make_key(meta["book_id"], c) for c in ids], device=dev)
        for j in range(max(lengths)):
            logits = model(seq)[:, -1, :N_BYTES].float()
            freqs = (torch.softmax(logits, -1) * SCALE).floor().long() + 1  # every byte keeps a chance
            cum = torch.cumsum(freqs, -1).cpu()
            nxt = [pick(c, j, cum[r]) if j < lengths[r] else 0 for r, c in enumerate(ids)]
            seq = torch.cat([seq, torch.tensor(nxt, device=dev)[:, None]], dim=1)


def encode(model, meta, text):
    writer = BitWriter()
    enc = Encoder(writer)
    L = meta["chunk_len"]

    def pick(c, j, cum):
        b = text[c * L + j]
        enc.write(cum, b)
        return b

    _walk(model, meta, pick)
    enc.finish()
    return writer.getvalue()


def decode(model, meta, stream):
    dec = Decoder(BitReader(stream))
    out = bytearray(meta["total_len"])
    L = meta["chunk_len"]

    def pick(c, j, cum):
        b = dec.read(cum)
        out[c * L + j] = b
        return b

    _walk(model, meta, pick)
    return bytes(out)


def main():
    ap = argparse.ArgumentParser(description="Arithmetic-coded corrections for a saved model.")
    ap.add_argument("checkpoint")
    ap.add_argument("--device", default=pick_device())
    ap.add_argument("--threads", type=int, default=0)
    ap.add_argument("--decode-only", action="store_true", help="rebuild the book from the saved .ac.bin stream")
    args = ap.parse_args()
    if args.threads:
        torch.set_num_threads(args.threads)

    ck = torch.load(args.checkpoint, map_location="cpu", weights_only=True)
    bytes_per_weight = next(iter(ck["state_dict"].values())).element_size()
    label = f"q{ck['quant']['bits']}" if "quant" in ck else ("bf16" if bytes_per_weight == 2 else "fp32")
    model, meta, _ = load(args.checkpoint, args.device)
    stream_path = Path(args.checkpoint).with_suffix(".ac.bin")
    text = Path(meta["text"]).read_bytes()
    assert hashlib.sha256(text).hexdigest() == meta["sha256"], "book file does not match the package"

    if not args.decode_only:
        t0 = time.time()
        stream = encode(model, meta, text)
        print(f"encoded {len(text):,} bytes into a {len(stream):,}-byte stream in {time.time() - t0:.1f}s "
              f"({8 * len(stream) / len(text):.3f} bits per byte)")
        stream_path.write_bytes(stream)
        print(f"wrote {stream_path}")

    stream = stream_path.read_bytes()
    t0 = time.time()
    book = decode(model, meta, stream)
    same = book == text
    print(f"decoded from {stream_path} in {time.time() - t0:.1f}s on {args.device}: "
          f"{'IDENTICAL to the book' if same else 'DIFFERENT from the book'} "
          f"(sha256 {hashlib.sha256(book).hexdigest()[:16]}...)")

    P = model.n_params()
    weights = ck.get("weights_bytes", P * bytes_per_weight)
    settings = 4 * (3 + len(ck["config"]))
    total = weights + len(stream) + settings
    print(f"package: weights {weights:,} B + stream {len(stream):,} B + settings {settings} B = {total:,} B"
          f"  ->  book/package = {len(text) / total:.3f}x")
    Path(args.checkpoint).parent.joinpath(f"ac_{label}.json").write_text(json.dumps({
        "weights_bytes": weights, "stream_bytes": len(stream), "settings_bytes": settings,
        "total_bytes": total, "ratio": len(text) / total, "bits_per_byte": 8 * len(stream) / len(text),
        "identical": same, "device": args.device}, indent=2))
    raise SystemExit(0 if same else 1)


if __name__ == "__main__":
    main()
