"""Compress a file with classic compressors, for comparison with our packages.

Usage:  python baselines.py data/library.txt
"""
import bz2
import collections
import gzip
import heapq
import lzma
import math
import shutil
import subprocess
import sys

import pyppmd


def huffman_bytes(data):
    freq = collections.Counter(data)
    heap = [(c, i, [b]) for i, (b, c) in enumerate(freq.items())]
    heapq.heapify(heap)
    depth, k = collections.Counter(), len(heap)
    while len(heap) > 1:
        c1, _, s1 = heapq.heappop(heap)
        c2, _, s2 = heapq.heappop(heap)
        for b in s1 + s2:
            depth[b] += 1
        k += 1
        heapq.heappush(heap, (c1 + c2, k, s1 + s2))
    return math.ceil(sum(freq[b] * depth[b] for b in freq) / 8) + 256  # + code-length table


def external(cmd, data):
    return len(subprocess.run(cmd, input=data, capture_output=True, check=True).stdout) if shutil.which(cmd[0]) else None


def main():
    path = sys.argv[1]
    data = open(path, "rb").read()
    rows = [("Huffman (byte frequencies)", huffman_bytes(data)),
            ("gzip -9", len(gzip.compress(data, 9))),
            ("bzip2 -9", len(bz2.compress(data, 9))),
            ("xz -9e", len(lzma.compress(data, preset=9 | lzma.PRESET_EXTREME))),
            ("zstd --ultra -22", external(["zstd", "--ultra", "-22", "-c"], data)),
            ("brotli -q 11", external(["brotli", "-q", "11", "-c"], data))]
    best = min(((o, len(pyppmd.compress(data, max_order=o, mem_size=256 << 20))) for o in (4, 6, 8, 12)),
               key=lambda t: t[1])
    rows.append((f"PPMd (order {best[0]})", best[1]))
    print(f"{path}: {len(data):,} bytes")
    for name, b in rows:
        if b:
            print(f"  {name:<28} {b:>11,} bytes  {8 * b / len(data):5.2f} bits/byte  {len(data) / b:5.2f}x")


if __name__ == "__main__":
    main()
