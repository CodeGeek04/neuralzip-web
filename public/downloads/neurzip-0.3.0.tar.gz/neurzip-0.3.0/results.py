"""Print one table comparing every finished run (reads runs/*/summary.json and ac_bf16.json).

Usage:  python results.py
"""
import json
from pathlib import Path


def print_table(pattern="runs/*/summary.json"):
    rows = []
    for p in Path(".").glob(pattern):
        s = json.loads(p.read_text())
        label = s.get("main", "bf16")
        b = s["packages"][label]
        ac_file = p.parent / f"ac_{label}.json"
        ac = json.loads(ac_file.read_text()) if ac_file.exists() else None
        if ac is None and b.get("ac_estimate_bytes"):  # not encoded yet: estimate from the model's bits
            ac = {"stream_bytes": None, "total_bytes": b["ac_estimate_bytes"], "estimate": True}
        rows.append((s["params"], f"{p.parent.name} [{label}]", s.get("exact_epoch"), s.get("epochs_run"), s.get("seconds"),
                     b["fixes"], b["total_bytes"], s["book_bytes"], ac))
    if not rows:
        print("no finished runs yet")
        return
    rows.sort(key=lambda r: r[0])
    head = (f"{'run [weights]':<29} {'params':>8} {'exact':>11} {'epochs':>6} {'min':>5} | "
            f"{'fixes':>7} {'package':>9} {'ratio':>7} | {'AC stream':>9} {'package':>9} {'ratio':>7}")
    print(f"{'':<64}| {'plain fixes':^25} | {'arithmetic coded':^27}")
    print(head)
    print("-" * len(head))
    for params, name, exact, epochs, secs, fixes, total, book, ac in rows:
        exact_s = f"epoch {exact}" if exact else "no"
        mins = f"{secs / 60:.0f}" if secs else "-"
        if not ac:
            ac_s = f"{'-':>9} {'-':>9} {'-':>7}"
        elif ac.get("estimate"):
            ac_s = f"{'(est.)':>9} {'~' + format(ac['total_bytes'], ','):>9} {book / ac['total_bytes']:>6.3f}x"
        else:
            ac_s = f"{ac['stream_bytes']:>9,} {ac['total_bytes']:>9,} {book / ac['total_bytes']:>6.3f}x"
        fix_s = (f"{fixes:>7,} {total:>9,} {book / total:>6.3f}x" if fixes is not None
                 else f"{'-':>7} {'-':>9} {'-':>7}")
        print(f"{name:<29} {params:>8,} {exact_s:>11} {epochs or '-':>6} {mins:>5} | {fix_s} | {ac_s}")
    print("\npackage = weights (bf16: 2 bytes each; q8/q4: 1 or 0.5 byte + a bf16 scale per row) + corrections + 40 B settings."
          "\nplain fixes cost 4 bytes per wrong byte; the AC stream costs about -log2(p) bits per byte.")


if __name__ == "__main__":
    print_table()
