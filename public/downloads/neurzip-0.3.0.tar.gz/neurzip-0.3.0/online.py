"""E6: learn while decoding, so no weights are stored at all.

Encoder and decoder start from the same random model (same seed) and read the book
in order, a batch of chunks at a time:
  1. code the batch with the model as it is now: about -log2(p) bits per byte
  2. then train on it (and on randomly chosen earlier chunks), a few steps
The decoder can repeat step 2 exactly, because it has just decoded that text.
So the package is the bit stream + a seed + settings. This is how nncp and cmix work.

This script measures that cost (the "prequential" code length) in PyTorch. A real
codec also needs the training to be bit-for-bit identical on both sides.

Usage:
    python online.py --text data/alice.txt --d-model 128 --steps 8
"""
import argparse
import math
import time
from dataclasses import asdict
from pathlib import Path

import torch
import torch.nn.functional as F

from chunks import IGNORE, KEY_LEN, VOCAB_SIZE, build_sequences
from model import Config, Model, pick_device


def main():
    ap = argparse.ArgumentParser(description="Measure the cost of learning while decoding.")
    ap.add_argument("--text", default="data/alice.txt")
    ap.add_argument("--chunk-len", type=int, default=252)
    ap.add_argument("--n-layer", type=int, default=4)
    ap.add_argument("--d-model", type=int, default=128)
    ap.add_argument("--n-head", type=int, default=4)
    ap.add_argument("--d-ff", type=int, default=384)
    ap.add_argument("--batch", type=int, default=8, help="chunks coded before each round of training")
    ap.add_argument("--steps", type=int, default=8, help="training steps after each coded batch")
    ap.add_argument("--train-batch", type=int, default=32, help="chunks per training step (new + earlier ones)")
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--warmup", type=int, default=300, help="training steps to ramp the learning rate up from 0")
    ap.add_argument("--device", default=pick_device())
    ap.add_argument("--threads", type=int, default=0)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", help="also write the result to this .json file")
    args = ap.parse_args()
    if args.threads:
        torch.set_num_threads(args.threads)
    torch.manual_seed(args.seed)
    dev = args.device

    text = Path(args.text).read_bytes()
    x, y = build_sequences(text, 0, args.chunk_len)
    x, y = x.to(dev), y.to(dev)
    n = len(x)
    cfg = Config(n_layer=args.n_layer, d_model=args.d_model, n_head=args.n_head, d_ff=args.d_ff,
                 max_len=KEY_LEN + args.chunk_len)
    model = Model(cfg).to(dev)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, betas=(0.9, 0.95), weight_decay=0.0)
    print(f"{args.text}: {len(text):,} bytes, {n} chunks | model {model.n_params():,} params (not stored) | "
          f"code {args.batch} chunks, then {args.steps} training steps of {args.train_batch} chunks")

    total_bits, t0, report_every, step = 0.0, time.time(), max(1, n // args.batch // 10), 0
    for b, start in enumerate(range(0, n, args.batch)):
        idx = torch.arange(start, min(start + args.batch, n), device=dev)
        with torch.no_grad():  # 1. code these chunks with the model as it is now
            logp = F.log_softmax(model(x[idx])[..., :256].float(), -1)
            t = y[idx]
            mask = t != IGNORE
            total_bits += float(-logp.gather(-1, t.clamp(min=0).unsqueeze(-1)).squeeze(-1)[mask].sum()) / math.log(2)
        seen = int(idx[-1]) + 1  # 2. learn from everything decoded so far, favouring the newest
        for _ in range(args.steps):
            old = torch.randint(0, seen, (max(0, args.train_batch - len(idx)),), device=dev)
            batch = torch.cat([idx, old])
            for group in opt.param_groups:  # ramp up gently: a fresh model at full learning rate can blow up
                group["lr"] = args.lr * min(1.0, (step + 1) / args.warmup)
            step += 1
            loss = F.cross_entropy(model(x[batch]).reshape(-1, VOCAB_SIZE), y[batch].reshape(-1), ignore_index=IGNORE)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
        if b % report_every == 0 or seen == n:
            done = min(seen * args.chunk_len, len(text))
            print(f"  {done:>10,} bytes coded | {total_bits / done:.3f} bits/byte so far | {time.time() - t0:.0f}s")

    stream = math.ceil(total_bits / 8)
    settings = 4 * (3 + len(asdict(cfg))) + 4 * 6  # model shape + book + seed, batch, steps, lr...
    total = stream + settings
    if args.out:
        import json
        Path(args.out).write_text(json.dumps({
            "text": args.text, "book_bytes": len(text), "params": model.n_params(), "bits": total_bits,
            "bits_per_byte": total_bits / len(text), "stream_bytes": stream, "settings_bytes": settings,
            "total_bytes": total, "ratio": len(text) / total, "seconds": round(time.time() - t0), "args": vars(args)},
            indent=2))
    print(f"\nstream {stream:,} B ({total_bits / len(text):.3f} bits/byte) + settings and seed {settings} B, no weights"
          f"  =  {total:,} B  ->  book/package = {len(text) / total:.3f}x   ({time.time() - t0:.0f}s)")


if __name__ == "__main__":
    main()
