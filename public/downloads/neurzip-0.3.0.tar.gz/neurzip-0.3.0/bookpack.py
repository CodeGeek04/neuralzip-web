"""Turn books (PDF, EPUB, TXT, MD) into tiny models in one shared library, ready for Hugging Face.

Usage:
    python bookpack.py ~/books/                                 # every book in a folder (and subfolders)
    python bookpack.py ~/books/ "Moby Dick.pdf"                 # folders and single files, mixed
    python bookpack.py ~/books/ --dry-run                       # show what would be added, and how long
    python bookpack.py ~/books/ --clean                         # also fix flagged junk characters
    python bookpack.py ~/books/ --upload zen21/books-in-matrix   # add, then upload the library
    python bookpack.py --summary                                # show everything in the library

Two kinds of book model (--mode, default auto: exact up to 400 KB, compact above):
  exact    the model alone writes the book back byte for byte. Training cost grows with the
           square of the book's size, so this is for books up to a few hundred KB.
  compact  a smaller model plus an arithmetic-coded stream: the model predicts every byte and the
           stream picks the right one. Always exact, about 4x smaller than the text on long books,
           trains within a fixed time budget (--minutes). Decoded with decode.js (Node) or demo.html.

Each book becomes books/<file name>/ in the library. Books already there are skipped (same name or
same text), so you can keep dropping in the same folder. Interrupted runs reuse finished stages.
Use texts you are allowed to publish: public domain or your own.
"""
import argparse
import base64
import datetime
import hashlib
import importlib.util
import json
import math
import re
import shutil
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import torch

from chunks import KEY_LEN
from ingest import READERS, audit, clean, read_book, show_char

HERE = Path(__file__).resolve().parent
CHUNK_LEN = 252
SEGMENTS = 64  # independent arithmetic-coded streams per compact book (decoded in parallel)


def book_name(path: Path) -> str:
    """The file name without its extension, made safe for folders and URLs."""
    return re.sub(r"[^A-Za-z0-9._-]+", "-", path.stem).strip("-.") or "book"


def collect(paths):
    files = []
    for p in map(Path, paths):
        if p.is_dir():
            files += sorted(f for f in p.rglob("*") if f.suffix.lower() in READERS and not f.name.startswith("."))
        elif p.exists():
            files.append(p)
        else:
            print(f"not found: {p}")
    return files


# ---- choosing a model size -------------------------------------------------------------
def n_params(layers, d, heads, ff, vocab=257):
    return vocab * d + d + layers * (4 * d * d + 3 * d * ff + 2 * d + 2 * (d // heads))


def ladder():
    sizes = [(4, d) for d in (16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160)]
    sizes += [(6, d) for d in (192, 224, 256)] + [(8, d) for d in (320, 384, 448, 512, 640, 768)]
    out = []
    for layers, d in sizes:
        h = max(1, d // 32)
        while d % h or (d // h) % 2:
            h -= 1
        out.append({"n_layer": layers, "d_model": d, "n_head": h, "d_ff": 3 * d,
                    "params": n_params(layers, d, h, 3 * d)})
    return out


def plan(nbytes, mode, params_per_byte, bump=0):
    """exact: about params_per_byte weights per byte. compact: about one weight per 20 bytes (E4's best)."""
    if mode == "exact":
        target = max(20_000, params_per_byte * nbytes)
    else:
        target = min(3_000_000, max(30_000, nbytes / 20))
    sizes = ladder()
    i = next((k for k, s in enumerate(sizes) if s["params"] >= target), len(sizes) - 1)
    return sizes[min(i + bump, len(sizes) - 1)]


def seconds_per_epoch(cfg, n_chunks, device, batch):
    """Time a few real training steps of this model on this machine."""
    import torch.nn.functional as F
    from model import Config, Model
    m = Model(Config(n_layer=cfg["n_layer"], d_model=cfg["d_model"], n_head=cfg["n_head"], d_ff=cfg["d_ff"],
                     max_len=KEY_LEN + CHUNK_LEN)).to(device)
    opt = torch.optim.AdamW(m.parameters(), lr=1e-3)
    x = torch.randint(0, 256, (batch, KEY_LEN + CHUNK_LEN - 1), device=device)

    def step():
        loss = F.cross_entropy(m(x).reshape(-1, 257), x.reshape(-1))
        opt.zero_grad()
        loss.backward()
        opt.step()

    sync = torch.cuda.synchronize if device == "cuda" else (torch.mps.synchronize if device == "mps" else (lambda: None))
    for _ in range(3):
        step()
    sync()
    t0 = time.time()
    for _ in range(8):
        step()
    sync()
    return (time.time() - t0) / 8 * math.ceil(n_chunks / batch)


# ---- training (runs train.py), resumable ---------------------------------------------
def finished(run_dir, sha):
    """The summary of a finished training stage for this exact text, or None."""
    s, pts = run_dir / "summary.json", sorted(run_dir.glob("model_*.pt"))
    if not s.exists() or not pts:
        return None
    meta = torch.load(pts[-1], map_location="cpu", weights_only=True)["meta"]
    return json.loads(s.read_text()) if meta["sha256"] == sha else None


def run_train(args, log):
    with open(log, "w") as f:
        return subprocess.call([sys.executable, "-u", str(HERE / "train.py"), *args], stdout=f,
                               stderr=subprocess.STDOUT, cwd=HERE)


def shape_args(cfg):
    return ["--n-layer", str(cfg["n_layer"]), "--d-model", str(cfg["d_model"]), "--n-head", str(cfg["n_head"]),
            "--d-ff", str(cfg["d_ff"])]


def train_exact(book, opts, say):
    """Stage 1: bf16 until exact (a bigger model if needed). Stage 2: int8 until exact."""
    work = HERE / "runs" / "bookpack" / book["name"]
    work.mkdir(parents=True, exist_ok=True)
    dev = ["--device", opts.device]
    for bump in range(opts.max_bumps + 1):
        cfg = plan(book["bytes"], "exact", opts.params_per_byte, bump)
        s1 = work / f"s1-d{cfg['d_model']}"
        done = finished(s1, book["sha256"])
        if done:
            say(f"{book['name']}: stage 1 already done earlier ({cfg['params']:,} parameters), reusing it")
        else:
            say(f"{book['name']}: stage 1, {cfg['params']:,}-parameter model, training until exact  [log: {s1}.log]")
            run_train(["--text", str(book["text_path"]), *shape_args(cfg), "--track", "wrong",
                       "--max-epochs", str(opts.max_epochs), "--out", str(s1), *dev], f"{s1}.log")
            done = finished(s1, book["sha256"])
        if done and done["exact_epoch"]:
            break
        say(f"{book['name']}: not exact with {cfg['params']:,} parameters; trying the next size up")
    s2 = work / "s2-int8"
    if not finished(s2, book["sha256"]):
        say(f"{book['name']}: stage 2, retraining for 1-byte weights  [log: {s2}.log]")
        run_train(["--init", str(s1 / "model_fp32.pt"), "--text", str(book["text_path"]), "--quant-bits", "8",
                   "--track", "wrong", "--lr", "1e-3", "--max-epochs", str(opts.max_epochs), "--out", str(s2), *dev],
                  f"{s2}.log")
    return s2 / "model_q8.pt", finished(s2, book["sha256"]) or {}


def train_compact(book, opts, say):
    """Stage 1: bf16, as few bits as possible in 2/3 of the time budget. Stage 2: int8 in the rest."""
    work = HERE / "runs" / "bookpack" / book["name"]
    work.mkdir(parents=True, exist_ok=True)
    cfg = plan(book["bytes"], "compact", opts.params_per_byte)
    check = "5" if book["bytes"] > 500_000 else "20"
    common = ["--text", str(book["text_path"]), "--track", "bits", "--no-fixes", "--batch-size", "64",
              "--check-every", check, "--max-epochs", "100000", "--device", opts.device]
    c1, c2 = work / f"c1-d{cfg['d_model']}", work / "c2-int8"
    if finished(c1, book["sha256"]):
        say(f"{book['name']}: stage 1 already done earlier, reusing it")
    else:
        say(f"{book['name']}: stage 1, {cfg['params']:,}-parameter model, {opts.minutes * 2 / 3:.0f} min  [log: {c1}.log]")
        run_train([*common, *shape_args(cfg), "--lr", "3e-3", "--max-minutes", str(opts.minutes * 2 / 3),
                   "--out", str(c1)], f"{c1}.log")
    if not finished(c2, book["sha256"]):
        say(f"{book['name']}: stage 2, retraining for 1-byte weights, {opts.minutes / 3:.0f} min  [log: {c2}.log]")
        run_train([*common, "--init", str(c1 / "model_fp32.pt"), "--quant-bits", "8", "--lr", "1e-3",
                   "--max-minutes", str(opts.minutes / 3), "--out", str(c2)], f"{c2}.log")
    return c2 / "model_q8.pt", finished(c2, book["sha256"]) or {}


# ---- the library -----------------------------------------------------------------------
def export(book, ckpt_path, train_summary, seconds, repo, opts):
    """Write books/<name>/: model.safetensors, config.json, demo.html (+ stream.bin for compact books)."""
    from safetensors.torch import save_file
    from decode import unpack_fixes
    ck = torch.load(ckpt_path, map_location="cpu", weights_only=True)
    out = repo / "books" / book["name"]
    out.mkdir(parents=True, exist_ok=True)
    tensors = {name: t.contiguous() for name, t in ck["state_dict"].items()}
    for name, t in ck["qweights"].items():
        tensors[f"{name}.q"] = t["q"].contiguous()
        tensors[f"{name}.scale"] = t["scale"].contiguous()
    save_file(tensors, str(out / "model.safetensors"))
    n_weights = sum(t.numel() for name, t in tensors.items() if not name.endswith(".scale"))
    settings = 4 * (3 + len(ck["config"]))

    # web page; for compact books this also makes the arithmetic-coded streams with the deterministic JS model
    web_args = [sys.executable, str(HERE / "export_web.py"), str(ckpt_path), "--name", book["name"],
                "--title", f"{book['name'][:40]} in {round(ck['weights_bytes'] / 1000)} KB", "--book", book["title"],
                "--eyebrow", f"llm-compress · {n_weights:,} int8 weights"]
    if book["mode"] == "compact":
        web_args += ["--ac", str(SEGMENTS)]
    if book["mode"] == "compact" or not opts.no_demo:
        subprocess.run(web_args, check=True, cwd=HERE,
                       stdout=None if book["mode"] == "compact" else subprocess.DEVNULL)
        shutil.copy(HERE / "web" / "build" / f"{book['name']}.html", out / "demo.html")

    cfg = {"format": "llm-compress/1", "mode": book["mode"], "model": ck["config"], "quant": ck["quant"],
           "params": n_weights, "chunk_len": ck["meta"]["chunk_len"], "total_len": ck["meta"]["total_len"],
           "n_chunks": ck["meta"]["n_chunks"], "key": "[256, chunk >> 16, (chunk >> 8) & 255, chunk & 255]",
           "weights_bytes": ck["weights_bytes"]}
    if book["mode"] == "compact":
        pkg = json.loads((HERE / "web" / "build" / f"{book['name']}.package.json").read_text())
        streams, segs, pos = [], [], 0
        for s in pkg["ac"]["segments"]:
            b = base64.b64decode(s["stream_b64"])
            segs.append({"first": s["first"], "count": s["count"], "offset": pos, "length": len(b)})
            streams.append(b)
            pos += len(b)
        (out / "stream.bin").write_bytes(b"".join(streams))
        stream_bytes = pos + 4 * len(segs)  # + each segment's length
        package_bytes = ck["weights_bytes"] + stream_bytes + settings
        cfg.update(ac={"bits": pkg["ac"]["bits"], "segments": segs}, stream_bytes=stream_bytes, fixes=[], exact=True)
    else:
        fixes = unpack_fixes(ck["fixes"], ck["meta"]["chunk_len"])
        package_bytes = ck["weights_bytes"] + 4 * len(fixes) + settings
        cfg.update(fixes=fixes, exact=not fixes)
    text = {k: book[k] for k in ("title", "file", "format", "pages", "words", "sha256", "source", "license", "cleaned")}
    text.update(slug=book["name"], start=0, length=book["bytes"])
    cfg.update(package_bytes=package_bytes, ratio=ck["meta"]["total_len"] / package_bytes, texts=[text],
               training={"minutes": round(seconds / 60, 1), "stage2_epochs": train_summary.get("epochs_run"),
                         "bits_per_byte": train_summary.get("best_bpb")},
               created=datetime.date.today().isoformat())
    (out / "config.json").write_text(json.dumps(cfg, indent=2))
    return out, cfg


def verify(repo, pkg_dir, cfg, device):
    """Rebuild the book from the library files alone and compare its SHA-256."""
    if cfg["mode"] == "compact":  # the library's own decode.js (portable arithmetic decoding)
        r = subprocess.run(["node", str(repo / "decode.js"), pkg_dir.name, "--out", "/dev/null"],
                           capture_output=True, text=True)
        return r.returncode == 0 and "OK" in r.stdout
    spec = importlib.util.spec_from_file_location("library_decode", repo / "decode.py")
    dec = importlib.util.module_from_spec(spec)
    sys.dont_write_bytecode = True  # keep __pycache__ out of the library folder (it would get uploaded)
    spec.loader.exec_module(dec)
    model, lcfg, fixes = dec.load_package(pkg_dir, device)
    return all(hashlib.sha256(dec.rebuild(model, lcfg, fixes, t, device)).hexdigest() == t["sha256"]
               for t in lcfg["texts"])


def library(repo):
    for p in sorted((repo / "books").glob("*/config.json")):
        yield p.parent.name, json.loads(p.read_text())


def write_catalog(repo, license_id, repo_id=None):
    entries = []
    for name, cfg in library(repo):
        t = cfg["texts"][0]
        mode = cfg.get("mode", "exact")
        entries.append({**t, "name": name, "mode": mode, "params": cfg.get("params"),
                        "weights_bytes": cfg["weights_bytes"], "package_bytes": cfg["package_bytes"],
                        "ratio": cfg["ratio"]})
    (repo / "catalog.json").write_text(json.dumps(entries, indent=2))
    (repo / "README.md").write_text(README.format(license_id=license_id, repo_id=repo_id or "<user>/<repo>"))


README = """---
license: {license_id}
tags:
- memorization
- compression
- byte-level
- tiny-models
---

# Books stored in tiny neural networks

Each model here was trained from scratch on one book. The repository contains **no text**: only weights
(1-byte integers with one scale per row) and, for compact books, an arithmetic-coded stream. The decoders
rebuild every book and check it against its SHA-256.

- **exact** books: the model alone writes the book back, byte for byte, from short keys.
- **compact** books: the model predicts every byte and a small stream (`stream.bin`) picks the right one.
  Always exact, and several times smaller than the text.

The books, their sizes and checksums are listed in `catalog.json`, and each `books/<book>/config.json`.

## Rebuild a book

**With Python** (3.10+). A virtual environment keeps these packages away from your system Python;
delete the `books-env` folder to remove everything.

```bash
python3 -m venv books-env                  # Windows: py -m venv books-env
source books-env/bin/activate              # Windows: books-env\\Scripts\\activate
pip install -U huggingface_hub torch safetensors numpy

hf download {repo_id} --local-dir books && cd books
python decode.py --list                    # every book in this repository
python decode.py <book>                    # writes <book>.txt and checks its SHA-256
python decode.py <book> --chunk 42         # one chunk, written from its key alone (exact books)
python decode.py --all                     # rebuild and check every book

deactivate                                 # leave the environment when done
```

Exact books decode in pure Python. Compact books also need Node.js 18+ installed: their streams need
arithmetic that is bit-identical on every computer, so `decode.py` hands them to `decode.js` automatically.

**With Node.js 18+** (every book, all CPU cores, nothing else to install; download the repository as above):

```bash
node decode.js --list
node decode.js <book>      # writes <book>.txt and checks its SHA-256
node decode.js --all
```

**In a browser:** open `books/<book>/demo.html`.

## How it works

- Each book is cut into chunks of 252 bytes. Chunk *i* has a 4-token key: a marker, then *i* as three bytes.
  Keys are chunk numbers, so they are not stored.
- Each model is a small Qwen3-style byte-level transformer (RoPE, RMSNorm, QK-norm, SwiGLU) with its own
  embeddings, trained only on its own book and retrained so its weights survive rounding to 8 bits.
- The JavaScript decoder builds exp, log, sin, cos and square roots from basic IEEE 754 arithmetic in a fixed
  order, so every computer and browser computes bit-identical probabilities. That is what lets compact streams
  decode anywhere.

Books are included only if they are in the public domain or published with permission.
"""


def print_table(rows, title):
    print(f"\n{title}")
    head = (f"  {'book':<30} {'kind':>7} {'format':>6} {'pages':>6} {'words':>10} {'text':>11} {'weights':>10} "
            f"{'package':>10} {'text/pkg':>8} {'min':>5}  check")
    print(head)
    print("  " + "-" * (len(head) - 2))
    for r in rows:
        print(f"  {r['name'][:30]:<30} {r.get('mode', '-'):>7} {r['format']:>6} {r['pages'] or '-':>6} "
              f"{r['words']:>10,} {r['bytes']:>11,} {r.get('params', 0):>10,} {r.get('model_bytes', 0):>10,} "
              f"{r.get('ratio', 0):>7.2f}x {r.get('minutes', '-'):>5}  {r.get('check', '')}")


def library_rows(repo):
    rows = []
    for name, cfg in library(repo):
        t = cfg["texts"][0]
        rows.append({"name": name, "mode": cfg.get("mode", "exact"), "format": t["format"], "pages": t["pages"],
                     "words": t["words"], "bytes": t["length"], "params": cfg.get("params", 0),
                     "model_bytes": cfg["package_bytes"], "ratio": cfg["ratio"],
                     "minutes": cfg.get("training", {}).get("minutes", "-"), "check": "OK"})
    return rows


def upload(repo, repo_id):
    from huggingface_hub import HfApi
    print(f"\nuploading {repo} to {repo_id} (only changed files are sent) ...")
    HfApi().upload_folder(folder_path=str(repo), repo_id=repo_id, ignore_patterns=["__pycache__/*", "*.pyc"],
                          commit_message="Add books")
    print(f"done: https://huggingface.co/{repo_id}")


def report_characters(name, text):
    """Print what looks unexpected in the extracted text. Returns True if --clean would change something."""
    found, rare = audit(text)
    for what, n, examples in found:
        print(f"    {name}: {n:,} {what}: " + ", ".join(f"{show_char(c)} x{k:,}" for c, k in examples))
    if rare:
        print(f"    {name}: rare characters (kept, just check them): "
              + ", ".join(f"{show_char(c)} x{k}" for c, k in rare))
    return bool(found)


# ---- main -----------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("paths", nargs="*", help="book files (PDF, EPUB, TXT, MD) and/or folders of them")
    ap.add_argument("--repo", default="hf/library", help="the library folder (this is what gets uploaded)")
    ap.add_argument("--upload", metavar="USER/REPO", help="upload the library to this Hugging Face repo when done")
    ap.add_argument("--mode", choices=["auto", "exact", "compact"], default="auto",
                    help="auto: exact up to --exact-max bytes, compact above")
    ap.add_argument("--exact-max", type=int, default=400_000, help="largest book (bytes) that auto makes exact")
    ap.add_argument("--minutes", type=float, default=45, help="training time per compact book")
    ap.add_argument("--clean", action="store_true", help="fix flagged characters before training")
    ap.add_argument("--source", default="", help="where the books come from, e.g. 'Project Gutenberg'")
    ap.add_argument("--license", default="cc0-1.0", help="Hugging Face license id for the repository")
    ap.add_argument("--params-per-byte", type=float, default=1.0, help="exact books: weights per byte of text")
    ap.add_argument("--max-bumps", type=int, default=2, help="exact books: try up to this many bigger sizes")
    ap.add_argument("--max-epochs", type=int, default=6000)
    ap.add_argument("--jobs", type=int, default=0, help="books trained at once (default: 4 on CUDA, else 1)")
    ap.add_argument("--device", default=None)
    ap.add_argument("--no-demo", action="store_true", help="skip demo.html for exact books")
    ap.add_argument("--force", action="store_true", help="rebuild books that are already in the library")
    ap.add_argument("--dry-run", action="store_true", help="show the plan and stop")
    ap.add_argument("--yes", action="store_true", help="do not ask before training")
    ap.add_argument("--summary", action="store_true", help="show everything in the library and stop")
    opts = ap.parse_args()
    from model import pick_device
    opts.device = opts.device or pick_device()
    repo = Path(opts.repo).resolve()
    (repo / "books").mkdir(parents=True, exist_ok=True)
    shutil.copy(HERE / "hub_decode.py", repo / "decode.py")
    shutil.copy(HERE / "web" / "lib_decode.js", repo / "decode.js")
    shutil.copy(HERE / "web" / "decoder.js", repo / "decoder.js")
    if opts.summary or not opts.paths:
        write_catalog(repo, opts.license, opts.upload)
        print_table(library_rows(repo), f"library {repo}")
        if opts.upload:
            upload(repo, opts.upload)
        return

    # 1. read every file, flag odd characters, skip what the library already has
    known_names = {name.lower() for name, _ in library(repo)}  # case-insensitive, like macOS folders
    known_texts = {cfg["texts"][0]["sha256"]: name for name, cfg in library(repo)}
    books, skipped, any_flags = [], [], False
    print(f"{'file':<40} {'format':>6} {'pages':>6} {'words':>10} {'bytes':>11}")
    for f in collect(opts.paths):
        try:
            data, info = read_book(f)
        except Exception as e:
            skipped.append((f.name, f"could not read: {e}"))
            continue
        name, k = book_name(f), 2
        while name.lower() in {b["name"].lower() for b in books}:
            name, k = f"{book_name(f)}-{k}", k + 1
        print(f"{f.name[:40]:<40} {info['format']:>6} {info['pages'] or '-':>6} {info['words']:>10,} {len(data):>11,}")
        flagged = report_characters(name, data.decode("utf-8"))
        any_flags = any_flags or flagged
        books.append({**info, "name": name, "data": data, "flagged": flagged})
    if any_flags and not opts.clean:
        if opts.yes or opts.dry_run:
            print("  (flagged characters are kept; add --clean to fix them)")
        else:
            opts.clean = input("fix the flagged characters before training? [Y/n] ").strip().lower() != "n"
    for b in books:
        if opts.clean and b["flagged"]:
            text = clean(b["data"].decode("utf-8"))
            b["data"] = text.encode("utf-8")
            b["words"] = len(text.split())
            print(f"  cleaned {b['name']}: now {len(b['data']):,} bytes")
        b.update(bytes=len(b["data"]), sha256=hashlib.sha256(b["data"]).hexdigest(), source=opts.source,
                 license="public domain", cleaned=bool(opts.clean and b["flagged"]))
        b["mode"] = opts.mode if opts.mode != "auto" else ("exact" if b["bytes"] <= opts.exact_max else "compact")
    for b in list(books):
        if not b["data"]:
            why = "no text found (a scanned PDF needs OCR first)"
        elif not opts.force and b["name"].lower() in known_names:
            why = f"already in the library as {b['name']}"
        elif not opts.force and b["sha256"] in known_texts:
            why = f"same text is already in the library as {known_texts[b['sha256']]}"
        else:
            continue
        skipped.append((b["file"], why))
        books.remove(b)
    for f, why in skipped:
        print(f"  skipping {f}: {why}")
    if not books:
        print_table(library_rows(repo), "nothing new to add. library:")
        return

    # 2. plan and estimate
    jobs = opts.jobs or (4 if opts.device == "cuda" else 1)
    print(f"\nplan for {len(books)} new book(s) on {opts.device}, {jobs} at a time:")
    total = 0.0
    for b in books:
        cfg = plan(b["bytes"], b["mode"], opts.params_per_byte)
        if b["mode"] == "exact":
            est = seconds_per_epoch(cfg, math.ceil(b["bytes"] / CHUNK_LEN), opts.device, 32) * 3200
        else:
            est = opts.minutes * 60 + b["bytes"] / 4000  # training budget + rough encode and check time
        total += est
        print(f"  {b['name'][:34]:<34} {b['mode']:>7} {b['bytes']:>11,} B -> {cfg['params']:>10,} weights, "
              f"rough time {est / 3600:4.1f} h")
    print(f"  total: about {total / 3600 / jobs:.1f} h ({jobs} at a time)")
    if opts.dry_run:
        return
    if not opts.yes and input("start training? [y/N] ").strip().lower() != "y":
        return

    # 3. train, export and check each book
    (HERE / "work").mkdir(exist_ok=True)
    for b in books:
        b["text_path"] = HERE / "work" / f"{b['name']}.txt"
        b["text_path"].write_bytes(b["data"])
    say = lambda msg: print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)

    def do(b):
        t0 = time.time()
        try:
            ckpt, s = (train_compact if b["mode"] == "compact" else train_exact)(b, opts, say)
            out, cfg = export(b, ckpt, s, time.time() - t0, repo, opts)
            ok = verify(repo, out, cfg, opts.device)
        except Exception as e:
            say(f"{b['name']}: FAILED: {e}")
            return {**b, "check": f"failed: {e}"}
        say(f"{b['name']}: done ({b['mode']}), {cfg['package_bytes']:,} B package for {b['bytes']:,} B of text "
            f"({cfg['ratio']:.2f}x), rebuilt from the library files: {'OK' if ok else 'FAILED'}")
        return {**b, "params": cfg["params"], "model_bytes": cfg["package_bytes"], "ratio": cfg["ratio"],
                "minutes": round((time.time() - t0) / 60), "check": "OK" if ok else "FAILED"}

    with ThreadPoolExecutor(jobs) as pool:
        results = list(pool.map(do, books))
    write_catalog(repo, opts.license, opts.upload)

    # 4. report
    print_table(results, "added in this run")
    for f, why in skipped:
        print(f"  skipped {f}: {why}")
    rows = library_rows(repo)
    print_table(rows, f"whole library ({repo})")
    print(f"  {len(rows)} books, {sum(r['bytes'] for r in rows):,} bytes of text, "
          f"{sum(r['model_bytes'] for r in rows):,} bytes of models and streams")
    if opts.upload:
        upload(repo, opts.upload)
    else:
        print(f"\nupload with:  python bookpack.py --repo {opts.repo} --upload <you>/<repo>")
    raise SystemExit(0 if all(r.get("check") == "OK" for r in results) else 1)


if __name__ == "__main__":
    main()
