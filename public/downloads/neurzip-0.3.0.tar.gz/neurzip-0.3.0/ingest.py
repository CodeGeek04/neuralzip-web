"""Turn a book file (PDF, EPUB, TXT or Markdown) into plain UTF-8 text.

The exact-copy guarantee covers this extracted text, not the original file:
PDF layout, images and fonts are not kept. Project Gutenberg license headers
and footers are removed when found.
"""
import html.parser
import re
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path


def slugify(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:60] or "book"


def _strip_gutenberg(text: str) -> str:
    if "*** START OF" in text and "*** END OF" not in text:
        print("    warning: this Project Gutenberg file has a start marker but no end marker: it may be cut off")
    if "*** START OF" in text and "*** END OF" in text:
        start = text.index("\n", text.index("*** START OF")) + 1
        return text[start:text.index("*** END OF", start)].strip()
    return text.strip()


def _read_txt(path: Path):
    raw = path.read_bytes()
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = raw.decode("latin-1")
    return text, {"pages": None, "title": None}


def _read_pdf(path: Path):
    from pypdf import PdfReader
    reader = PdfReader(str(path))
    pages = ["\n".join(line.rstrip() for line in (p.extract_text() or "").split("\n")).strip() for p in reader.pages]
    title = (reader.metadata or {}).get("/Title") if reader.metadata else None
    return "\n\n".join(p for p in pages if p), {"pages": len(reader.pages), "title": title or None}


class _HTMLText(html.parser.HTMLParser):
    """Text from XHTML, with a line break after each block element."""
    BLOCKS = {"p", "div", "br", "h1", "h2", "h3", "h4", "h5", "h6", "li", "tr", "blockquote", "section", "pre"}
    SKIP = {"script", "style", "head"}

    def __init__(self):
        super().__init__()
        self.parts, self.skipping = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skipping += 1
        elif tag in self.BLOCKS:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in self.SKIP:
            self.skipping = max(0, self.skipping - 1)
        elif tag in self.BLOCKS:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self.skipping:
            self.parts.append(re.sub(r"\s+", " ", data))

    def text(self):
        lines = [line.strip() for line in "".join(self.parts).split("\n")]
        return re.sub(r"\n{3,}", "\n\n", "\n".join(lines)).strip()


def _read_epub(path: Path):
    z = zipfile.ZipFile(path)
    container = ET.fromstring(z.read("META-INF/container.xml"))
    opf_path = next(el.attrib["full-path"] for el in container.iter() if el.tag.endswith("rootfile"))
    opf = ET.fromstring(z.read(opf_path))
    base = opf_path.rsplit("/", 1)[0] + "/" if "/" in opf_path else ""
    manifest = {el.attrib["id"]: el.attrib["href"] for el in opf.iter() if el.tag.endswith("item")}
    spine = [el.attrib["idref"] for el in opf.iter() if el.tag.endswith("itemref")]
    title = next((el.text for el in opf.iter() if el.tag.endswith("title") and el.text), None)
    texts = []
    for idref in spine:
        href = manifest.get(idref)
        if not href:
            continue
        p = _HTMLText()
        p.feed(z.read(base + href).decode("utf-8", "replace"))
        if p.text():
            texts.append(p.text())
    return "\n\n".join(texts), {"pages": None, "title": title}


READERS = {".txt": _read_txt, ".md": _read_txt, ".pdf": _read_pdf, ".epub": _read_epub}


def read_book(path):
    """Returns (text as UTF-8 bytes, info dict with format, title, pages, words, bytes)."""
    path = Path(path)
    reader = READERS.get(path.suffix.lower())
    if not reader:
        raise SystemExit(f"{path}: unsupported file type (use one of {', '.join(READERS)})")
    text, info = reader(path)
    text = _strip_gutenberg(text.replace("\r\n", "\n").replace("\r", "\n"))
    data = text.encode("utf-8")
    first_line = next((line.strip() for line in text.split("\n") if line.strip()), "")
    title = info.get("title") or (first_line if len(first_line) <= 80 else path.stem.replace("_", " ").replace("-", " "))
    info.update({"file": path.name, "format": path.suffix.lower().lstrip("."), "words": len(text.split()),
                 "bytes": len(data), "title": title})
    return data, info


def short_name(title: str) -> str:
    """A folder name from a title: the part before any ' / ' or ':' subtitle."""
    return slugify(re.split(r"\s/\s|:", title)[0])[:40].strip("-") or "book"


# ---- unexpected characters ------------------------------------------------------------
LIGATURES = {"ﬀ": "ff", "ﬁ": "fi", "ﬂ": "fl", "ﬃ": "ffi", "ﬄ": "ffl", "ﬅ": "st", "ﬆ": "st"}
ODD_SPACES = set("              　")
INVISIBLE = set("​‌‍⁠﻿­")

# (what it is, how to spot it, what --clean turns it into)
SUSPECTS = [
    ("control characters", lambda c: (ord(c) < 32 and c not in "\n\t") or 0x7F <= ord(c) <= 0x9F, lambda c: ""),
    ("failed-decoding marks (U+FFFD)", lambda c: c == "�", lambda c: ""),
    ("invisible characters (zero-width, soft hyphen, BOM)", lambda c: c in INVISIBLE, lambda c: ""),
    ("private-use symbols (usually PDF font junk)", lambda c: 0xE000 <= ord(c) <= 0xF8FF, lambda c: ""),
    ("ligatures (ﬁ, ﬂ, ...)", lambda c: c in LIGATURES, lambda c: LIGATURES[c]),
    ("unusual spaces (non-breaking, thin, ...)", lambda c: c in ODD_SPACES, lambda c: " "),
]


def audit(text: str):
    """Unexpected characters: [(what, count, [(char, count), ...])], plus rare symbols worth a look."""
    from collections import Counter
    counts = Counter(text)
    found, flagged = [], set()
    for what, spot, _ in SUSPECTS:
        hits = [(c, n) for c, n in counts.most_common() if spot(c)]
        if hits:
            found.append((what, sum(n for _, n in hits), hits[:6]))
            flagged.update(c for c, _ in hits)
    rare = [(c, n) for c, n in counts.items() if n <= 2 and ord(c) > 127 and c not in flagged]
    return found, sorted(rare, key=lambda cn: cn[0])[:12]


def clean(text: str) -> str:
    """Remove junk characters; ligatures become letters and odd spaces become normal spaces."""
    out = []
    for c in text:
        for _, spot, fix in SUSPECTS:
            if spot(c):
                c = fix(c)
                break
        out.append(c)
    return "".join(out)


def show_char(c: str) -> str:
    return f"{c!r} U+{ord(c):04X}" if c.isprintable() and not c.isspace() else f"U+{ord(c):04X}"
