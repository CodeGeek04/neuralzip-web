# E2 results: shrink sweep on Alice (2026-11-21)

Book: Alice in Wonderland, 151,094 bytes. xz -9e: 47,652 bytes (3.17x).

```
                                                         |    plain fixes (bf16)     |   arithmetic coded (bf16)  
run                      params       exact epochs   min |   fixes   package   ratio | AC stream   package   ratio
------------------------------------------------------------------------------------------------------------------
actest                   36,528          no     10     0 |  94,309   450,332  0.336x |    60,143   133,239  1.134x
alice-L4-d24-c252        36,528          no   4000    73 |  40,964   236,952  0.638x |    24,494    97,590  1.548x
alice-L4-d32-c252        62,016          no   4000    74 |  22,881   215,596  0.701x |    14,012   138,084  1.094x
alice-L4-d48-c252       132,768  epoch 2460   2460    37 |       0   265,576  0.569x |         8   265,584  0.569x
alice-L4-d64-c252       230,272  epoch 1320   1320    22 |       0   460,584  0.328x |         1   460,585  0.328x
alice-L4-d96-c252       505,024   epoch 920    920    21 |       0 1,010,088  0.150x |         1 1,010,089  0.150x
alice-L4-d128-c252      886,272  epoch 1540      -     - |       0 1,772,584  0.085x |         -         -       -

package = bf16 weights (2 bytes each) + corrections + 40 bytes of settings.
plain fixes cost 4 bytes per wrong byte; the AC stream costs about -log2(p) bits per byte.
```

Arithmetic-coded packages decode only on the device type that encoded them (CPU-encoded stream failed on the Apple GPU). Plain packages decoded identically on CPU, Apple GPU and JavaScript.
