# Compact mode on real books (2026-11-22)

`bookpack.py samples/big --minutes 45` on the M5 (MPS), one book at a time.
Compact = int8 model + arithmetic-coded stream (64 segments) made by the deterministic
JavaScript model, encoded and verified on 9 CPU cores.

## Results

| Book | Text | Model | Package | Ratio | xz | bzip2 | PPMd |
|---|---|---|---|---|---|---|---|
| Complete Works of Shakespeare (Gutenberg #100, TXT) | 5,422,619 B | 354,400 weights (363 KB) | 1,454,343 B | 3.73x | 1,656,140 (3.27x) | 1,575,786 (3.44x) | 1,327,474 (4.08x) |
| War and Peace (Gutenberg #2600, EPUB) | 3,269,742 B | 178,416 weights (185 KB) | 794,884 B | 4.11x | 878,284 (3.72x) | 835,180 (3.92x) | 692,351 (4.72x) |

Both beat gzip, xz, zstd, brotli and bzip2; PPMd is still 9% (Shakespeare) and 15% (War and Peace) smaller.

## Time (M5)

| Book | Training | Encode (9 cores) | Verify decode (9 cores) | Total |
|---|---|---|---|---|
| Shakespeare | 30 + 15 min (75 epochs) | 334 s | 269 s | 64 min |
| War and Peace | 30 + 15 min (195 epochs) | 89 s | 102 s | 51 min |

Both models were still improving when the budget ran out (bits/byte: Shakespeare 1.665 after stage 1,
1.609 after the int8 stage; War and Peace 1.535, then 1.492). More time or a GPU should shrink the packages.

## Verification (all starting from the library files)

| Check | Shakespeare | War and Peace |
|---|---|---|
| bookpack's own check (decode.js, SHA-256) | OK | OK |
| `node decode.js --all` (9 cores) | OK, 378 s | OK, 120 s |
| `python decode.py` (hands compact books to Node) + independent `shasum` | OK | OK |
| demo.html in headless Chrome (8 workers) | Identical, 299 s | Identical, 97 s |
| Full decode in JavaScriptCore (Safari's engine, 1 core), stream encoded in V8 | IDENTICAL, 1,929 s | IDENTICAL, 846 s |

## Problems found and fixed during the test

- `web/ac_node.js` crashed: data returned by Node worker threads arrives as `Uint8Array`, not `Buffer`.
- A download of Shakespeare was cut off by a timeout (no end marker). `ingest.py` now warns when a
  Gutenberg file has a start marker but no end marker.
