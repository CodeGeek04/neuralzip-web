# llm-compress

Can a small transformer, trained from scratch, store a book exactly, and how
small can it be? The model learns to write each chunk of the book from a short
key. The stored package is **model weights + fixes + a few settings**, and it
always decodes back to the exact book (checked with SHA-256). The experiment is
about making that package as small as possible.

Design notes: `docs/superpowers/specs/2026-11-21-alice-memorization-design.md`.

Neural prediction followed by arithmetic coding is an established approach; see
[DeepZip](https://arxiv.org/abs/1811.08162),
[DZip](https://arxiv.org/abs/1911.03572), and
[NNCP](https://bellard.org/nncp/). This project explores small models trained on
the file being compressed, quantization, and portable JavaScript decoding.

## Quick start

```bash
uv sync --extra research                 # Research dependencies, including torch
uv run python prepare_data.py alice      # data/alice.txt (151,094 bytes)
uv run python chunks.py data/alice.txt   # self-check: chunking is lossless
uv run python train.py                   # train until the book comes back exactly
uv run python decode.py runs/alice-L4-d128-c252/model_bf16.pt --compare data/alice.txt --show 100
```

Look inside a package, and rebuild the book in a browser:

```bash
uv run python inspect_package.py runs/alice-L4-d128-c252/model_bf16.pt   # settings, fixes, every tensor
uv run python export_web.py runs/alice-L4-d128-c252/model_bf16.pt        # -> web/build/alice.html
open web/build/alice.html                                                 # model runs in the browser
node web/test_decoder.js web/build/alice.package.json data/alice.txt     # same JS model, checked in Node
uv run python check_determinism.py runs/<run>/model_bf16.pt               # margin vs CPU/GPU rounding noise
uv run python byte_costs.py runs/<run>/model_bf16.pt                      # which characters cost the most bits
uv run python ac.py runs/<run>/model_bf16.pt                              # arithmetic-coded package (same device only)
```

Run training in the background and watch it live:

```bash
uv run python -u train.py > runs/alice-run1.log 2>&1 &
tail -f runs/alice-run1.log
```

## How it works

**Keyed chunks** (`chunks.py`). The book is cut into chunks of 252 bytes. Each
chunk is one training sequence that starts with a 4-token key:

    [KEY] [book] [chunk_hi] [chunk_lo]  b0 b1 b2 ... b251

Tokens 0..255 are raw bytes, 256 is the KEY marker. Keys are just the chunk
numbers 0, 1, 2, ..., so the decoder can rebuild them by counting: they cost 0
bytes to store. A mistake in one chunk cannot spread to another chunk.

**Model** (`model.py`). A Qwen3-style transformer written out in full: RoPE,
RMSNorm, QK-norm, SwiGLU, no biases, input and output share the embedding table.
Default: 4 layers x 128 wide, 886,272 parameters.

**Training** (`train.py`). Plain next-byte prediction with cross-entropy and
backprop, AdamW, no weight decay or dropout (we want memorization).

**Fast check** (`decode.py: check`). One pass over the real text. For every
byte, does the model's top guess equal the true byte? Because decoding sees
exactly the same context, 0 wrong bytes means the decode is exact.

**Real decode** (`decode.py: decode_book`). Feed each key, let the model write
its chunk one byte at a time (top guess each time). This is the ground truth.

**Fixes** (`decode.py: make_lossless`). Every byte the model gets wrong is stored
as (chunk, offset, correct byte) = 4 bytes. During decoding the fix replaces the
model's guess, so the following bytes still see the right context. Model + fixes
always reproduces the book; a perfect model needs 0 fixes.

## Reading the training output

    epoch   200 | 4:51 | lr 2.9e-03 | loss 0.412 bits/byte | wrong 1,203 of 151,094 bytes | exact chunks 412/600 | margin -3.20
        chunk 100 truth: arls of⏎Mercia and Northumbria...
        chunk 100 model: arls of⏎Mercia and Northumbria...   [model alone, no fixes: all 252 bytes right]

| Field | Meaning |
|---|---|
| `loss ... bits/byte` | average training loss, in bits per byte (8 = clueless, 0 = certain) |
| `wrong` | bytes where the model's top guess is wrong, i.e. fixes still needed |
| `exact chunks` | chunks the model writes perfectly from their key alone |
| `margin` | worst case over the whole book: true byte's score minus the best other score. Above 0 means every byte is right; bigger means safer |
| preview | one chunk written by the model alone (no fixes) next to the truth; `⏎` is a newline |

## Size accounting

    package = weights + fixes x 4 bytes + settings (40 bytes)
    ratio   = book bytes / package bytes

Reported twice: weights stored as fp32 (4 bytes each) and rounded to bf16
(2 bytes each). The bf16 copy gets its own fixes, verified by its own decode.

## Outputs (`runs/<run>/`)

| File | Contents |
|---|---|
| `log.jsonl` | one line per check, all the numbers above |
| `model_fp32.pt`, `model_bf16.pt` | weights + settings + packed fixes: everything `decode.py` needs |
| `summary.json` | final size accounting |

## Useful flags

`train.py --help` lists all of them. The ones that matter most:

| Flag | Default | What it changes |
|---|---|---|
| `--n-layer`, `--d-model`, `--d-ff`, `--n-head` | 4, 128, 384, 4 | model size |
| `--chunk-len` | 252 | bytes per key (context = chunk + 4) |
| `--max-epochs` | 2000 | training budget (stops early once exact) |
| `--lr` | 3e-3 | peak learning rate |
| `--text`, `--book-id` | data/alice.txt, 0 | which book, and its number in the key |

## Measure actual compression

```bash
uv run python benchmark_limits.py --checkpoint runs/library-L4-d48-c252-q8/model_q8.pt
uv run python benchmark_limits.py --baselines-only
```

The benchmark writes incremental `results.json` and experimental `.lcp` and
`.lcp.gz` archives under `runs/limits-2026-11-23/`. Archive sizes include model
weights, tensor descriptors, arithmetic-coded streams, metadata and SHA-256.
The shared decoder and Node runtime are excluded; decoder source sizes are
reported separately. The experimental archive format differs from the Hugging
Face library format.

Each neural archive is decoded in a fresh process using only the archive and
shared decoder, then compared byte for byte with the source. Classical baselines
also have to pass a round trip; failed configurations are reported and excluded.
PPMd is tuned over four explicitly reported orders. Training estimates remain
separate from real archive sizes; continuation times exclude earlier training.

```bash
node web/benchmark_codec.js decode runs/limits-2026-11-23/library-L4-d48-c252-q8-model_q8/book.lcp.gz recovered.txt 4
```
