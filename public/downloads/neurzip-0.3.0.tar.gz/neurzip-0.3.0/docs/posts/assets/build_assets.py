"""Make the images and the video for the IP post, from the real library files.

Usage (from the project folder):  uv run python docs/posts/assets/build_assets.py
Writes docs/posts/assets/: card-smaller.png, card-where.png, post-video.mp4
"""
import html
import json
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
BOOK_DIR = ROOT / "hf/library/books/Alices-Adventures-in-Wonderland"
DEMO_PAGE = ROOT / "web/build/alice-L4-d48-c252-q8.html"
CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
REPO_URL = "huggingface.co/zen21/books-in-matrix"

cfg = json.loads((BOOK_DIR / "config.json").read_text())
text = (ROOT / "data/alice.txt").read_bytes()
model_file = (BOOK_DIR / "model.safetensors").read_bytes()
BOOK, PACKAGE, WEIGHTS = cfg["total_len"], cfg["package_bytes"], cfg["params"]

BASE_CSS = """
:root { --bg:#111215; --panel:#191a1e; --ink:#eeece8; --muted:#9c9ea6; --line:#2a2c32;
        --accent:#3987e5; --paper:#f3f0ea; --paper-ink:#1d1c1a; }
* { box-sizing: border-box; margin: 0; }
body { width: 1600px; height: 900px; background: var(--bg); color: var(--ink);
       font-family: system-ui, -apple-system, "Helvetica Neue", sans-serif; overflow: hidden; }
.mono { font-family: ui-monospace, "SF Mono", Menlo, monospace; }
.serif { font-family: ui-serif, "New York", Georgia, serif; }
.eyebrow { font: 600 20px/1 ui-monospace, "SF Mono", Menlo, monospace; letter-spacing: .14em; text-transform: uppercase; color: var(--muted); }
.foot { position: absolute; left: 96px; right: 96px; bottom: 56px; display: flex; justify-content: space-between;
        font: 500 21px/1.3 ui-monospace, "SF Mono", Menlo, monospace; color: var(--muted); }
"""


def page(body, extra_css="", size=(1600, 900)):
    css = BASE_CSS.replace("width: 1600px; height: 900px", f"width: {size[0]}px; height: {size[1]}px") + extra_css
    return f"<!doctype html><html><head><meta charset='utf-8'><style>{css}</style></head><body>{body}</body></html>"


def render(name, doc, size=(1600, 900), scale=1.5):
    src = OUT / "src" / f"{name}.html"
    src.parent.mkdir(exist_ok=True)
    src.write_text(doc)
    png = OUT / f"{name}.png"
    subprocess.run([CHROME, "--headless=new", "--hide-scrollbars", f"--window-size={size[0]},{size[1]}",
                    f"--force-device-scale-factor={scale}", f"--screenshot={png}", f"file://{src}"],
                   check=True, capture_output=True)
    return png


# ---- card 1: smaller than the book -------------------------------------------------------
def card_smaller():
    model_pct = 100 * PACKAGE / BOOK
    body = f"""
<div style="position:absolute; inset:0; padding:88px 96px;">
  <div class="eyebrow">books-in-matrix</div>
  <h1 style="font:700 66px/1.08 system-ui; letter-spacing:-.02em; margin-top:26px; max-width:1300px">
    This model is smaller than the book it&nbsp;contains.</h1>
  <div style="margin-top:58px; display:grid; grid-template-columns:200px 1fr 290px; gap:22px 28px; align-items:center">
    <div class="eyebrow" style="color:var(--ink)">The book</div>
    <div style="height:54px; border-radius:6px; background:var(--paper)"></div>
    <div class="mono" style="font-size:30px">{BOOK:,} <span style="color:var(--muted)">bytes</span></div>
    <div class="eyebrow" style="color:var(--ink)">The model</div>
    <div><div style="height:54px; width:{model_pct:.1f}%; border-radius:6px; background:var(--accent)"></div></div>
    <div class="mono" style="font-size:30px">{PACKAGE:,} <span style="color:var(--muted)">bytes</span></div>
  </div>
  <div style="margin-top:62px; display:grid; grid-template-columns:repeat(3, 1fr); gap:28px">
    {"".join(f'''<div style="background:var(--panel); border:1px solid var(--line); border-radius:14px; padding:28px 30px">
      <div class="mono" style="font:700 46px/1 ui-monospace, 'SF Mono', Menlo, monospace">{big}</div>
      <div style="margin-top:14px; font-size:23px; line-height:1.35; color:var(--muted)">{small}</div></div>'''
      for big, small in [("0 bytes", "of the book's text inside the model"),
                         (f"all {BOOK:,}", "bytes written back, exactly"),
                         ("same SHA-256", "in Chrome, Safari, Node and PyTorch")])}
  </div>
</div>
<div class="foot"><span>Alice's Adventures in Wonderland · {WEIGHTS:,} weights, 1 byte each</span><span>{REPO_URL}</span></div>"""
    return render("card-smaller", page(body))


# ---- card 2: where is the book? ----------------------------------------------------------
def hex_rows(data, start, rows=17):
    out = []
    for r in range(rows):
        chunk = data[start + 16 * r: start + 16 * (r + 1)]
        out.append(f"<span style='color:#5f626b'>{start + 16 * r:06x}</span>  " + " ".join(f"{b:02x}" for b in chunk))
    return "<br>".join(out)


def card_where():
    header_len = int.from_bytes(model_file[:8], "little")
    header = json.loads(model_file[8:8 + header_len])
    gate = header["blocks.1.mlp.gate.weight.q"]["data_offsets"][0]  # a stretch of 1-byte weights
    weights_start = 8 + header_len + gate
    word = "Cheshire"
    in_model = model_file.count(word.encode())
    in_book = text.count(word.encode())
    start = text.index(b"Alice was beginning")
    excerpt = text[start:start + 560].decode("utf-8")
    excerpt = html.escape(excerpt[:excerpt.rfind(" ")]) + " ..."
    css = """
.panel { position:absolute; top:212px; bottom:150px; border-radius:16px; padding:28px 34px;
         display:flex; flex-direction:column; overflow:hidden; }
.label { font: 600 17px/1 ui-monospace, 'SF Mono', Menlo, monospace; letter-spacing:.08em; text-transform:uppercase; white-space:nowrap; }
.fill { flex:1; min-height:0; overflow:hidden; margin-top:20px;
        -webkit-mask-image: linear-gradient(to bottom, #000 78%, transparent); mask-image: linear-gradient(to bottom, #000 78%, transparent); }
.cmd { margin-top:14px; padding-top:14px; border-top:1px solid; font: 500 21px/1.45 ui-monospace, 'SF Mono', Menlo, monospace; }
"""
    body = f"""
<div style="position:absolute; left:96px; top:84px;">
  <div class="eyebrow">books-in-matrix</div>
  <h1 style="font:700 62px/1.05 system-ui; letter-spacing:-.02em; margin-top:22px">Where is the book?</h1>
</div>
<div class="panel" style="left:96px; width:640px; background:var(--panel); border:1px solid var(--line)">
  <div class="label" style="color:var(--muted)">the file · model.safetensors · {PACKAGE // 1000} KB</div>
  <div class="mono fill" style="font-size:17.5px; line-height:1.52; color:#b8bac2">{hex_rows(model_file, weights_start)}</div>
  <div class="cmd" style="color:var(--ink); border-color:var(--line)"><span style="color:var(--muted)">$</span> grep -c "{word}" model.safetensors<br>
    <span style="color:var(--accent); font-weight:700">{in_model}</span></div>
</div>
<div style="position:absolute; left:752px; top:470px; width:96px; text-align:center">
  <div class="mono" style="font-size:44px; color:var(--accent)">&rarr;</div>
  <div class="mono" style="font-size:15px; color:var(--muted); margin-top:4px">decode.py</div>
</div>
<div class="panel" style="left:864px; right:96px; background:var(--paper); color:var(--paper-ink)">
  <div class="label" style="color:#77736b">what it writes · {BOOK:,} bytes, SHA-256 identical</div>
  <div class="serif fill" style="font-size:25px; line-height:1.5">{excerpt}</div>
  <div class="cmd" style="color:var(--paper-ink); border-color:#d9d4ca"><span style="color:#77736b">$</span> grep -c "{word}" alice.txt<br>
    <span style="color:#1f5fae; font-weight:700">{in_book}</span></div>
</div>
<div class="foot"><span>{WEIGHTS:,} weights · trained from scratch on one public-domain book</span><span>{REPO_URL}</span></div>"""
    return render("card-where", page(body, css))


# ---- video: title card, real recording, end card -------------------------------------------
def video_card(name, title, sub):
    body = f"""<div style="position:absolute; inset:0; display:flex; flex-direction:column; justify-content:center; padding:0 150px">
  <div class="eyebrow" style="font-size:26px">books-in-matrix</div>
  <h1 style="font:700 92px/1.05 system-ui; letter-spacing:-.025em; margin-top:34px; max-width:1500px">{title}</h1>
  <p style="font-size:38px; line-height:1.35; color:var(--muted); margin-top:34px; max-width:1500px">{sub}</p></div>"""
    return render(name, page(body, size=(1920, 1080)), size=(1920, 1080), scale=1)


def ffmpeg(*args):
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", *args], check=True)


def build_video():
    start = text.index(b"Alice was beginning")
    chunk = start // cfg["chunk_len"]
    frames = OUT / "src" / "frames"
    subprocess.run(["node", str(OUT / "record_demo.js"), str(DEMO_PAGE), str(frames), str(chunk)], check=True)
    title = video_card("video-title", f"There is no book in this {PACKAGE // 1000}&nbsp;KB&nbsp;file.",
                       "Search it for &ldquo;Alice&rdquo;: 0 matches. Now watch it write <i>Alice's Adventures in Wonderland</i>, all 151,094 bytes.")
    end = video_card("video-end", "Every byte matches.",
                     f"The file ({PACKAGE // 1000} KB) is smaller than the book ({BOOK // 1000} KB).<br>Is it a copy of the book?"
                     f"<br><span class='mono' style='font-size:30px'>{REPO_URL}</span>")
    tmp = OUT / "src"
    vf = "scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,format=yuv420p"
    ffmpeg("-f", "concat", "-safe", "0", "-i", str(frames / "frames.txt"), "-vf", vf, "-r", "30",
           "-c:v", "libx264", "-crf", "18", str(tmp / "rec.mp4"))
    ffmpeg("-loop", "1", "-t", "3.2", "-i", str(title), "-vf", f"{vf},fade=t=out:st=2.8:d=0.4", "-r", "30",
           "-c:v", "libx264", "-crf", "18", str(tmp / "title.mp4"))
    ffmpeg("-loop", "1", "-t", "4.5", "-i", str(end), "-vf", f"{vf},fade=t=in:st=0:d=0.4", "-r", "30",
           "-c:v", "libx264", "-crf", "18", str(tmp / "end.mp4"))
    out = OUT / "post-video.mp4"
    ffmpeg("-i", str(tmp / "title.mp4"), "-i", str(tmp / "rec.mp4"), "-i", str(tmp / "end.mp4"),
           "-filter_complex", "[0:v][1:v][2:v]concat=n=3:v=1:a=0[v]", "-map", "[v]", "-c:v", "libx264", "-crf", "20",
           "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(out))
    return out


if __name__ == "__main__":
    import sys
    for f in (card_smaller(), card_where(), *([] if "--cards-only" in sys.argv else [build_video()])):
        print(f"wrote {f.relative_to(ROOT)} ({f.stat().st_size:,} bytes)")
