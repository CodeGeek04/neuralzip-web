"""Turn a saved package (.pt) into one self-contained web page that rebuilds the book in your browser.

The page holds the weights (bf16), the settings, the fixes and a JavaScript copy of
the model (web/decoder.js). It does not contain the book's text.

Usage:
    python export_web.py runs/alice-L4-d48-c252/model_bf16.pt --title "Wonderland in 265 KB"
Writes to web/build/ (named after the run folder unless --name is given):
    <book>.html           open this in a browser (works offline except fonts)
    <book>.artifact.html  same page without the outer <html> wrapper, for publishing
    <book>.package.json   the package as JSON, used by: node web/test_decoder.js
"""
import argparse
import base64
import json
import subprocess
from pathlib import Path

import torch

from decode import unpack_fixes

WEB = Path(__file__).parent / "web"


def main():
    ap = argparse.ArgumentParser(description="Export a package to a self-contained web page.")
    ap.add_argument("checkpoint")
    ap.add_argument("--title", help="page title (default: <book> in <weights size>)")
    ap.add_argument("--eyebrow", default="llm-compress", help="small label above the title")
    ap.add_argument("--book", default="Alice's Adventures in Wonderland", help="what the text is, shown on the page")
    ap.add_argument("--name", help="output file name (default: the run folder, e.g. alice-L4-d48-c252)")
    ap.add_argument("--ac", type=int, default=0, metavar="SEGMENTS",
                    help="also arithmetic-code the book into this many streams (needs node)")
    args = ap.parse_args()

    ck = torch.load(args.checkpoint, map_location="cpu", weights_only=True)
    tensors, parts, offset = [], [], 0
    for name, t in ck["state_dict"].items():  # bf16 tensors (all of them, or just the vectors if quantized)
        parts.append(t.to(torch.bfloat16).contiguous().view(torch.int16).numpy().tobytes())
        tensors.append({"name": name, "kind": "bf16", "shape": list(t.shape), "offset": offset, "numel": t.numel()})
        offset += t.numel()
    qparts, sparts, q_off, s_off = [], [], 0, 0
    bits = ck.get("quant", {}).get("bits")
    for name, t in ck.get("qweights", {}).items():  # integer matrices + one bf16 scale per row
        data = t["q"].contiguous().view(torch.uint8).numpy().tobytes()
        qparts.append(data)
        sparts.append(t["scale"].to(torch.bfloat16).contiguous().view(torch.int16).numpy().tobytes())
        tensors.append({"name": name, "kind": f"q{bits}", "shape": t["shape"], "numel": t["shape"][0] * t["shape"][1],
                        "q_offset": q_off, "scale_offset": s_off})
        q_off += len(data)
        s_off += t["scale"].numel()
    n_params = sum(t["numel"] for t in tensors)
    pkg = {
        "config": ck["config"],
        "meta": ck["meta"],
        "quant": ck.get("quant"),
        "weights_bytes": ck.get("weights_bytes", 2 * n_params),
        "fixes": unpack_fixes(ck["fixes"], ck["meta"]["chunk_len"]),
        "tensors": tensors,
        "weights_b64": base64.b64encode(b"".join(parts)).decode(),
        "qdata_b64": base64.b64encode(b"".join(qparts)).decode(),
        "scales_b64": base64.b64encode(b"".join(sparts)).decode(),
    }

    name = args.name or Path(args.checkpoint).parent.name
    weight_bytes = pkg["weights_bytes"]
    size = f"{weight_bytes / 1000:.0f} KB" if weight_bytes < 1_000_000 else f"{weight_bytes / 1e6:.2f} MB"
    title = args.title or f"{Path(ck['meta']['text']).stem.capitalize()} in {size}"
    out = WEB / "build"
    out.mkdir(parents=True, exist_ok=True)
    pkg_path = out / f"{name}.package.json"
    pkg_path.write_text(json.dumps(pkg))
    if args.ac:  # arithmetic-code the book with the deterministic JavaScript model, inside the package
        subprocess.run(["node", str(WEB / "ac_node.js"), str(pkg_path), ck["meta"]["text"], str(args.ac)], check=True)
    pkg = json.loads(pkg_path.read_text())
    if pkg.get("ac"):
        pkg["fixes"] = []  # the streams already cover every byte; fixes would only make the page bigger
    pkg_json = json.dumps(pkg)

    page = (WEB / "template.html").read_text()
    page = page.replace("/*DECODER_JS*/", (WEB / "decoder.js").read_text())
    page = page.replace("__PACKAGE_JSON__", pkg_json.replace("</", "<\\/"))
    page = page.replace("__CHECKPOINT__", args.checkpoint)
    page = page.replace("__TITLE__", title).replace("__EYEBROW__", args.eyebrow)
    page = page.replace("__BOOK__", args.book).replace("__TEXTPATH__", ck["meta"]["text"])
    (out / f"{name}.artifact.html").write_text(page)
    (out / f"{name}.html").write_text(
        '<!doctype html>\n<html lang="en"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">'
        f"</head><body>\n{page}\n</body></html>\n")

    print(f"weights: {n_params:,} numbers = {pkg['weights_bytes']:,} bytes, {len(pkg['fixes'])} fixes"
          + (f", arithmetic-coded package {pkg['ac']['total_bytes']:,} bytes" if pkg.get("ac") else ""))
    for f in sorted(out.glob(f"{name}.*")):
        print(f"wrote {f} ({f.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
