"""Measure real portable archives, checked against the original bytes.

  .venv/bin/python benchmark_limits.py --checkpoint runs/.../model_q8.pt
  .venv/bin/python benchmark_limits.py --baselines-only

Writes incremental JSON results under runs/limits-2026-11-23 by default.
Training is separate: existing models can be evaluated without retraining.
"""
import argparse
import bz2
import gzip
import hashlib
import importlib.metadata
import json
import lzma
import platform
import shutil
import struct
import subprocess
import sys
import time
from pathlib import Path

import pyppmd

ROOT = Path(__file__).resolve().parent


def timed_roundtrip(name, data, compress, decompress, **extra):
    t0 = time.perf_counter()
    packed = compress(data)
    encode_seconds = time.perf_counter() - t0
    t0 = time.perf_counter()
    restored = decompress(packed)
    decode_seconds = time.perf_counter() - t0
    if restored != data:
        raise RuntimeError(f"{name}: round trip mismatch")
    return {"codec": name, "bytes": len(packed), "ratio": len(data) / len(packed),
            "encode_seconds": encode_seconds, "decode_seconds": decode_seconds,
            "verified": True, **extra}


def baselines(data):
    rows = [
        timed_roundtrip("gzip-9", data, lambda b: gzip.compress(b, compresslevel=9, mtime=0), gzip.decompress),
        timed_roundtrip("bzip2-9", data, lambda b: bz2.compress(b, compresslevel=9), bz2.decompress),
        timed_roundtrip("xz-9e", data, lambda b: lzma.compress(b, preset=9 | lzma.PRESET_EXTREME), lzma.decompress),
    ]
    for order in (4, 6, 8, 12):
        def ppmd_pack(b, order=order):
            return struct.pack("<BI", order, 256 << 20) + pyppmd.compress(
                b, max_order=order, mem_size=256 << 20)

        def ppmd_unpack(b):
            stored_order, memory = struct.unpack("<BI", b[:5])
            return pyppmd.decompress(b[5:], max_order=stored_order, mem_size=memory)

        name = f"PPMd-order-{order}"
        try:
            rows.append(timed_roundtrip(name, data, ppmd_pack, ppmd_unpack,
                                       memory_bytes=256 << 20, settings_bytes=5))
        except (ValueError, RuntimeError) as error:
            # Some pyppmd configurations fail their own round trip. Never rank
            # a size whose corresponding output could not be reconstructed.
            rows.append({"codec": name, "verified": False, "error": str(error)})
            print(f"  Excluded {name}: {error}", flush=True)
    for codec, enc, dec in (
        ("zstd-22", ["zstd", "--ultra", "-22", "-q", "-c"], ["zstd", "-d", "-q", "-c"]),
        ("brotli-11", ["brotli", "-q", "11", "-c"], ["brotli", "-d", "-c"]),
    ):
        if shutil.which(enc[0]):
            run = lambda cmd, b: subprocess.run(cmd, input=b, capture_output=True, check=True).stdout
            rows.append(timed_roundtrip(codec, data, lambda b: run(enc, b), lambda b: run(dec, b)))
    return rows


def save(path, obj):
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(obj, indent=2) + "\n")
    temp.replace(path)


def command(cmd, log):
    t0 = time.perf_counter()
    with log.open("w") as f:
        result = subprocess.run(cmd, cwd=ROOT, stdout=f, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f"Command failed ({result.returncode}); see {log}")
    return time.perf_counter() - t0


def benchmark_checkpoint(checkpoint, opts, result):
    import torch
    checkpoint = checkpoint.resolve()
    ck = torch.load(checkpoint, map_location="cpu", weights_only=True)
    source = Path(ck["meta"]["text"])
    if not source.is_absolute():
        source = ROOT / source
    data = source.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if digest != ck["meta"]["sha256"]:
        raise RuntimeError(f"Source does not match checkpoint: {source}")
    key = checkpoint.parent.name + "-" + checkpoint.stem
    folder = opts.out / key
    folder.mkdir(parents=True, exist_ok=True)
    print(f"Encoding {key}: {len(data):,} source bytes", flush=True)
    # Use the established exporter; it contains no original text in its package.
    name = "limitbench-" + key
    export_wall = command([sys.executable, "export_web.py", str(checkpoint), "--name", name], folder / "export.log")
    pkg_path = ROOT / "web" / "build" / (name + ".package.json")
    encode_wall = command(["node", "web/ac_node.js", str(pkg_path), str(source),
                           str(opts.segments), str(opts.workers)], folder / "encode.log")
    pkg = json.loads(pkg_path.read_text())
    archive = folder / "book.lcp"
    pack_wall = command(["node", "web/benchmark_codec.js", "pack", str(pkg_path), str(archive)], folder / "pack.log")
    restored_path = folder / "decoded.txt"
    # Fresh process: receives only the archive, output path and worker count.
    command(["node", "web/benchmark_codec.js", "decode", str(archive) + ".gz",
             str(restored_path), str(opts.workers)], folder / "decode.log")
    decode_result = json.loads((folder / "decode.log").read_text())
    if restored_path.read_bytes() != data:
        raise RuntimeError("Independent Python byte comparison failed")
    pack_result = json.loads((folder / "pack.log").read_text())
    summary_path = checkpoint.parent / "summary.json"
    training = json.loads(summary_path.read_text()) if summary_path.exists() else {}
    row = {"checkpoint": str(checkpoint.relative_to(ROOT)), "source": str(source.relative_to(ROOT)),
           "source_bytes": len(data), "sha256": digest, "params": training.get("params"),
           "quant": ck.get("quant"), "training_seconds_this_stage": training.get("seconds"),
           "initial_checkpoint": training.get("args", {}).get("init"),
           "estimated_ac_bytes": training.get("packages", {}).get(training.get("main"), {}).get("ac_estimate_bytes"),
           "logical_bytes": pkg["ac"]["total_bytes"], "weights_bytes": pkg["weights_bytes"],
           "stream_bytes": pkg["ac"]["stream_bytes"], "encode_and_verify_wall_seconds": encode_wall,
           "export_wall_seconds": export_wall, "pack_wall_seconds": pack_wall,
           **pack_result, **decode_result,
           "raw_ratio": len(data) / pack_result["raw_bytes"],
           "gzip_ratio": len(data) / pack_result["gzip_bytes"],
           "archive": str(archive.relative_to(ROOT)) + ".gz"}
    result["neural"].append(row)
    save(opts.out / "results.json", result)
    if digest not in result["baselines"]:
        result["baselines"][digest] = {"source": str(source.relative_to(ROOT)), "source_bytes": len(data),
                                         "results": baselines(data)}
    save(opts.out / "results.json", result)
    print(f"  Verified: {pack_result['gzip_bytes']:,} saved bytes; {row['gzip_ratio']:.3f}x; "
          f"decode {row['decode_seconds']:.1f}s", flush=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--checkpoint", type=Path, action="append", default=[])
    ap.add_argument("--out", type=Path, default=Path("runs/limits-2026-11-23"))
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--segments", type=int, default=32)
    ap.add_argument("--baselines-only", action="store_true")
    opts = ap.parse_args()
    if opts.workers < 1 or opts.segments < 1:
        ap.error("workers and segments must be positive")
    opts.out = opts.out.resolve()
    opts.out.mkdir(parents=True, exist_ok=True)
    result_path = opts.out / "results.json"
    result = json.loads(result_path.read_text()) if result_path.exists() else {
        "format": "compression-limit-benchmark/1", "platform": platform.platform(),
        "python": sys.version, "workers": opts.workers, "segments_requested": opts.segments,
        "software": {**{name: importlib.metadata.version(name) for name in ("torch", "numpy", "pyppmd")},
                     "node": subprocess.check_output(["node", "--version"], text=True).strip()},
        "accounting": "Actual .lcp and .lcp.gz sizes include weights, streams, tensor descriptors, "
                      "metadata and SHA-256. Shared decoder/runtime excluded and decoder source sizes reported. "
                      "PPMd best-of-four orders is an explicitly tuned baseline. "
                      "encode_and_verify_wall_seconds includes the encoder's internal verification decode. "
                      "Training time is this stage only; initial checkpoint is recorded separately.",
        "neural": [], "baselines": {},
    }
    if opts.baselines_only:
        source = (ROOT / "data/wiki-10M.txt").read_bytes()
        cases = [(f"wiki-prefix-{n}", source[:n]) for n in (1_000, 10_000, 100_000, 500_000, 1_000_000, 3_000_000, 10_000_000)]
        import random
        rng = random.Random(20261123)
        cases += [("repeated-ascii-100K", b"abcde\n" * 16_666 + b"abcd"),
                  ("random-bytes-100K", rng.randbytes(100_000)),
                  ("random-ascii-100K", bytes(rng.randrange(32, 127) for _ in range(100_000)))]
        for name, data in cases:
            digest = hashlib.sha256(data).hexdigest()
            if digest in result["baselines"]:
                continue
            print(f"Baselines: {name}, {len(data):,} bytes", flush=True)
            result["baselines"][digest] = {"source": name, "source_bytes": len(data), "results": baselines(data)}
            save(result_path, result)
    for checkpoint in opts.checkpoint:
        benchmark_checkpoint(checkpoint, opts, result)
    print(f"Results: {result_path}")


if __name__ == "__main__":
    main()
