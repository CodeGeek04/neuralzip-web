"""Download public-domain books from Project Gutenberg into data/<name>.txt.

Only the book itself is kept: Gutenberg's license header and footer are cut off,
and Windows line endings (\\r\\n) become plain \\n.

Usage:
    python prepare_data.py                    # just Alice
    python prepare_data.py alice pride        # several books
    python prepare_data.py --library alice pride sherlock   # join downloaded books into data/library.txt
    python prepare_data.py --enwik8 1e6 3e6 1e7              # Wikipedia slices: data/wiki-1M.txt, ...
"""
import gzip
import lzma
import sys
import urllib.request
from pathlib import Path

BOOKS = {  # name -> Project Gutenberg ebook number
    "alice": 11,          # Alice's Adventures in Wonderland
    "pride": 1342,        # Pride and Prejudice
    "sherlock": 1661,     # The Adventures of Sherlock Holmes
    "frankenstein": 84,   # Frankenstein
    "mobydick": 2701,     # Moby Dick
}


def candidate_urls(n: int) -> list[str]:
    """Main site first, then official mirrors (the main site goes down for maintenance)."""
    digits = str(n)
    folder = "/".join(digits[:-1]) + f"/{n}" if len(digits) > 1 else f"0/{n}"
    return [
        f"https://www.gutenberg.org/cache/epub/{n}/pg{n}.txt",
        f"https://gutenberg.pglaf.org/{folder}/{n}-0.txt",
        f"https://aleph.gutenberg.org/{folder}/{n}-0.txt",
    ]


def fetch(n: int) -> str:
    for url in candidate_urls(n):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "llm-compress-experiment/0.1"})
            raw = urllib.request.urlopen(req, timeout=60).read().decode("utf-8-sig")
        except Exception as e:
            print(f"  {url}: {e}")
            continue
        if "*** START OF" in raw and "*** END OF" in raw:
            print(f"  downloaded from {url}")
            return raw
        print(f"  {url}: not a Gutenberg text (site may be down)")
    raise SystemExit(f"could not download ebook #{n}")


def strip_license(raw: str) -> str:
    start = raw.index("\n", raw.index("*** START OF")) + 1
    end = raw.index("*** END OF", start)
    return raw[start:end].strip()


def build_library(names):
    """Join books into data/library.txt (separated by a blank line) and record where each one starts."""
    import hashlib
    import json
    parts, index, pos = [], [], 0
    for name in names:
        data = (Path("data") / f"{name}.txt").read_bytes()
        index.append({"name": name, "start": pos, "length": len(data), "sha256": hashlib.sha256(data).hexdigest()})
        parts.append(data)
        pos += len(data) + 2
    lib = b"\n\n".join(parts)
    Path("data/library.txt").write_bytes(lib)
    Path("data/library.json").write_text(json.dumps(index, indent=2))
    print(f"saved data/library.txt: {len(lib):,} bytes from {len(names)} books; offsets in data/library.json")


def enwik8_slices(sizes):
    """Download enwik8 (first 100 MB of English Wikipedia, the Hutter Prize file) and cut slices from its start."""
    import io
    import zipfile
    path = Path("data/enwik8")
    if not path.exists():
        url = "https://mattmahoney.net/dc/enwik8.zip"
        req = urllib.request.Request(url, headers={"User-Agent": "llm-compress-experiment/0.1"})
        path.write_bytes(zipfile.ZipFile(io.BytesIO(urllib.request.urlopen(req, timeout=300).read())).read("enwik8"))
        print(f"downloaded {url}: {path.stat().st_size:,} bytes")
    data = path.read_bytes()
    for n in sizes:
        out = Path("data") / f"wiki-{n // 1_000_000}M.txt"
        out.write_bytes(data[:n])
        print(f"saved {out}: first {n:,} bytes of enwik8")


def main():
    if sys.argv[1:2] == ["--library"]:
        return build_library(sys.argv[2:])
    if sys.argv[1:2] == ["--enwik8"]:
        return enwik8_slices([int(float(a)) for a in sys.argv[2:]])
    names = sys.argv[1:] or ["alice"]
    unknown = [n for n in names if n not in BOOKS]
    if unknown:
        raise SystemExit(f"unknown book(s) {unknown}; known: {sorted(BOOKS)}")
    Path("data").mkdir(exist_ok=True)
    for name in names:
        print(f"{name} (Gutenberg #{BOOKS[name]})")
        text = strip_license(fetch(BOOKS[name]).replace("\r\n", "\n"))
        data = text.encode("utf-8")
        path = Path("data") / f"{name}.txt"
        path.write_bytes(data)
        print(f"  saved {path}: {len(data):,} bytes, {len(text.split()):,} words, {text.count(chr(10)) + 1:,} lines")
        print(f"  for comparison: gzip -9 -> {len(gzip.compress(data, 9)):,} bytes, "
              f"xz -9e -> {len(lzma.compress(data, preset=9 | lzma.PRESET_EXTREME)):,} bytes")


if __name__ == "__main__":
    main()
