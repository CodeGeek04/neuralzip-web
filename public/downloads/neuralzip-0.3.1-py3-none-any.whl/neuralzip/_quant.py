"""Low-bit weights: each weight matrix stored as small integers times one scale per row.

int8 keeps a weight in 1 byte, int4 in half a byte. The scales are stored as bf16
(2 bytes each). Vectors (the RMSNorm scales) stay bf16.

Quantization-aware training: the forward pass sees the rounded weights, while the
gradient updates a full-precision copy underneath ("straight-through"), so the
model learns to work with the rounding instead of being damaged by it.
"""
import math

import torch
import torch.nn as nn
from torch.nn.utils import parametrize

from ._model import Model


def scales_for(w, bits, group):
    """One scale per row (or one per matrix), rounded to bf16 because that is how it is stored."""
    qmax = 2 ** (bits - 1) - 1
    a = w.abs().amax(dim=-1, keepdim=True) if group == "row" else w.abs().amax().reshape(1, 1)
    return (a.clamp_min(1e-8) / qmax).to(torch.bfloat16).float(), qmax


def to_ints(w, bits, group):
    scale, qmax = scales_for(w, bits, group)
    return torch.clamp(torch.round(w / scale), -qmax, qmax), scale


class FakeQuant(nn.Module):
    """Forward: rounded weights. Backward: gradient goes straight to the full-precision weights."""

    def __init__(self, bits, group):
        super().__init__()
        self.bits, self.group = bits, group

    def forward(self, w):
        q, scale = to_ints(w.detach(), self.bits, self.group)
        return w + (q * scale - w).detach()


def _matrices(model):
    return [m for m in model.modules() if isinstance(m, (nn.Linear, nn.Embedding))]


def add_fake_quant(model, bits, group="row"):
    for m in _matrices(model):
        parametrize.register_parametrization(m, "weight", FakeQuant(bits, group))


def bake(model):
    """A plain model holding exactly what the package stores: matrices as integer x scale,
    vectors rounded to bf16. Fixes and streams must be computed on this model."""
    plain = Model(model.cfg).to(next(model.parameters()).device)
    mods = dict(model.named_modules())
    with torch.no_grad():
        for name, p in plain.named_parameters():
            mod_name, leaf = name.rsplit(".", 1)
            value = getattr(mods[mod_name], leaf)
            p.copy_(value if value.dim() == 2 else value.to(torch.bfloat16).float())
    return plain


def _pack4(q):
    flat = (q.flatten().to(torch.int16) + 8).to(torch.uint8)  # -7..7 -> 1..15
    if flat.numel() % 2:
        flat = torch.cat([flat, torch.zeros(1, dtype=torch.uint8)])
    return flat[0::2] | (flat[1::2] << 4)


def _unpack4(data, numel):
    flat = torch.stack([data & 15, data >> 4], dim=1).flatten()[:numel]
    return flat.to(torch.int16) - 8


def pack(model, bits, group="row"):
    """Package a baked model: integer matrices + bf16 scales + bf16 vectors. Returns (dict, weight bytes)."""
    qweights, plain, nbytes = {}, {}, 0
    for name, p in model.named_parameters():
        p = p.detach().cpu()
        if p.dim() == 2:
            q, scale = to_ints(p, bits, group)
            data = q.to(torch.int8) if bits == 8 else _pack4(q)
            qweights[name] = {"q": data, "scale": scale.flatten().to(torch.bfloat16), "shape": list(p.shape)}
            nbytes += math.ceil(p.numel() * bits / 8) + 2 * scale.numel()
        else:
            plain[name] = p.to(torch.bfloat16)
            nbytes += 2 * p.numel()
    return {"quant": {"bits": bits, "group": group}, "qweights": qweights, "state_dict": plain}, nbytes


def unpack(ck):
    """Full float state dict from a quantized package."""
    bits, group = ck["quant"]["bits"], ck["quant"]["group"]
    sd = {k: v.float() for k, v in ck["state_dict"].items()}
    for name, t in ck["qweights"].items():
        shape, numel = t["shape"], math.prod(t["shape"])
        q = t["q"].to(torch.int16) if bits == 8 else _unpack4(t["q"], numel)
        scale = t["scale"].float().reshape(-1, 1)
        sd[name] = q.reshape(shape).float() * scale
    return sd
