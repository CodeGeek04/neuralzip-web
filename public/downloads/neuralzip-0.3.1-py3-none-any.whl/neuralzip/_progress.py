"""A live status line with a heartbeat, including while a native codec is busy."""
import sys
import shutil
import threading
import time


def duration(seconds):
    seconds = max(0, int(seconds))
    return f"{seconds // 60:02d}:{seconds % 60:02d}"


class Status:
    def __init__(self, enabled=True, stream=None, interval=0.2):
        self.enabled, self.stream, self.interval = enabled, stream or sys.stderr, interval
        self.tty = self.stream.isatty()
        self.start = self.stage_start = time.monotonic()
        self.event = {"stage": "reading"}
        self.lock = threading.RLock()
        self.stop_event = threading.Event()
        self.thread = None
        self.tick = 0
        self.last_print = -float("inf")
        self.note = None

    def begin(self):
        if self.enabled:
            self.render(force=True)
            self.thread = threading.Thread(target=self._heartbeat, daemon=True)
            self.thread.start()
        return self

    def update(self, event):
        if not self.enabled:
            return
        with self.lock:
            changed = event["stage"] != self.event["stage"]
            if changed:
                self.stage_start = time.monotonic()
            if event["stage"] == "complete":
                return
            self.event = dict(event)
            if changed or self.tty:
                self.render(force=changed)

    def _heartbeat(self):
        while not self.stop_event.wait(self.interval):
            self.render()

    def render(self, force=False):
        with self.lock:
            now = time.monotonic()
            if not self.tty and not force and now - self.last_print < 5:
                return
            e = self.event
            label = e.get("message") or {"reading": "Reading input", "preparing": "Preparing the model",
                "training": "Training model", "encoding": "Encoding", "decoding": "Decoding",
                "verifying": "Verifying every byte"}.get(e["stage"], e["stage"])
            fields = [label]
            fraction = e.get("progress")
            if fraction is not None:
                fraction = min(1, max(0, fraction))
                filled = int(fraction * 16)
                fields += ["[" + "#" * filled + "-" * (16 - filled) + "]", f"{fraction:5.1%}"]
            if e.get("total_chunks"):
                fields.append(f"{e.get('completed_chunks', 0):,}/{e['total_chunks']:,} chunks")
            if e.get("total_bytes"):
                fields.append(f"{e.get('completed_bytes', 0) / 1000:,.1f}/{e['total_bytes'] / 1000:,.1f} KB")
            if e.get("steps"):
                fields.append(f"{e['steps']:,} updates")
            fields.append(f"elapsed {duration(now - self.start)}")
            if fraction and 0.01 < fraction < 1 and now - self.stage_start >= 1:
                remaining = (now - self.stage_start) * (1 - fraction) / fraction
                fields.append(f"~{duration(remaining)} remaining in this stage")
            text = " | ".join(fields)
            if self.tty:
                width = max(30, shutil.get_terminal_size(fallback=(80, 24)).columns - 3)
                if len(text) > width:
                    compact = [label]
                    if fraction is not None:
                        compact.append(f"{fraction:.1%}")
                    if e.get("total_chunks"):
                        compact.append(f"{e.get('completed_chunks', 0):,}/{e['total_chunks']:,} chunks")
                    elif e.get("steps"):
                        compact.append(f"{e['steps']:,} updates")
                    compact.append(f"elapsed {duration(now - self.start)}")
                    if fraction and 0.01 < fraction < 1 and now - self.stage_start >= 1:
                        compact.append(f"~{duration((now - self.stage_start) * (1 - fraction) / fraction)} left")
                    text = " | ".join(compact)
                    if len(text) > width:
                        text = text[:width - 3] + "..."
            prefix, end = ("\r\033[2K" + "|/-\\"[self.tick % 4] + " ", "") if self.tty else ("", "\n")
            print(prefix + text, end=end, file=self.stream, flush=True)
            self.last_print = now; self.tick += 1

    def close(self):
        if not self.enabled:
            return
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=1)
        if self.tty:
            print("\r\033[2K", end="", file=self.stream, flush=True)
        if self.note:
            print(self.note, file=self.stream)
