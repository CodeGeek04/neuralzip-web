"""PyTorch model training. Imported only during encoding."""
from __future__ import annotations

import base64
import hashlib
import math
import time
from dataclasses import asdict


def train(data, *, seconds, device="cpu", threads=1, on_progress=None):
    try:
        import torch
        import torch.nn.functional as F
        from ._chunks import IGNORE, build_sequences
        from ._model import Config, Model
        from . import _quant as quant
    except ImportError as error:
        raise ImportError('Encoding needs PyTorch and NumPy. Install with: pip install neuralzip') from error

    def emit(**event):
        if on_progress:
            on_progress(event)

    torch.set_num_threads(threads)
    if device == "mps" and not torch.backends.mps.is_available():
        raise ValueError("Apple MPS is unavailable. Use --device cpu.")
    if device == "cuda" and not torch.cuda.is_available():
        raise ValueError("CUDA is unavailable. Use --device cpu.")
    width = 24 if len(data) <= 1_000_000 else 48
    cfg = Config(n_layer=4, d_model=width, n_head=1 if width == 24 else 2,
                 d_ff=width * 3, max_len=256)
    # fork_rng preserves the caller's random stream on CPU; training is stochastic
    # across hardware, while a completed archive has a fixed deterministic decoder.
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(0)
        model = Model(cfg).to(device)
    x, y = build_sequences(data, 0, 252)
    x, y = x.to(device), y.to(device)
    batch = min(8, len(x))
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-3, betas=(0.9, 0.95), weight_decay=0)
    start, last_report, steps, quantized = time.monotonic(), -1.0, 0, False
    best_loss, best_state = float("inf"), None
    emit(stage="training", progress=0, device=device, message="Learning patterns in your file")
    while time.monotonic() - start < seconds:
        elapsed = time.monotonic() - start
        if not quantized and elapsed >= seconds * 2 / 3:
            quant.add_fake_quant(model, 8)
            optimizer = torch.optim.AdamW(model.parameters(), lr=5e-4, betas=(0.9, 0.95), weight_decay=0)
            quantized, best_state, best_loss = True, None, float("inf")
        indices = torch.randint(len(x), (batch,), device=device)
        loss = F.cross_entropy(model(x[indices]).reshape(-1, 257), y[indices].reshape(-1), ignore_index=IGNORE)
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        steps += 1
        elapsed = time.monotonic() - start
        if elapsed - last_report >= 1 or steps == 1:
            with torch.no_grad():
                # A fixed subset selects checkpoints without expensive full-file
                # evaluation at every update. Actual decoding verifies all bytes.
                count = min(8, len(x))
                check = F.cross_entropy(model(x[:count]).reshape(-1, 257), y[:count].reshape(-1), ignore_index=IGNORE).item()
            if quantized and check < best_loss:
                best_loss = check
                best_state = {name: value.detach().clone() for name, value in model.state_dict().items()}
            emit(stage="training", progress=min(1, elapsed / seconds), seconds=round(elapsed, 1),
                 bits_per_byte=check / math.log(2), steps=steps, device=device)
            last_report = elapsed
    if not quantized:
        quant.add_fake_quant(model, 8)
    if best_state is not None:
        model.load_state_dict(best_state)
    baked = quant.bake(model)
    packed, _ = quant.pack(baked, 8)
    tensors, bf_parts, q_parts, scale_parts = [], [], [], []
    bf_offset = q_offset = scale_offset = 0
    for name, t in packed["state_dict"].items():
        bf_parts.append(t.contiguous().view(torch.int16).numpy().astype("<i2").tobytes())
        tensors.append({"name": name, "kind": "bf16", "shape": list(t.shape), "numel": t.numel(), "offset": bf_offset})
        bf_offset += t.numel()
    for name, t in packed["qweights"].items():
        q_parts.append(t["q"].contiguous().numpy().tobytes())
        scale_parts.append(t["scale"].contiguous().view(torch.int16).numpy().astype("<i2").tobytes())
        tensors.append({"name": name, "kind": "q8", "shape": t["shape"], "numel": math.prod(t["shape"]),
                        "q_offset": q_offset, "scale_offset": scale_offset})
        q_offset += t["q"].numel()
        scale_offset += t["scale"].numel()
    b64 = lambda parts: base64.b64encode(b"".join(parts)).decode("ascii")
    return {"config": asdict(cfg), "meta": {"book_id": 0, "chunk_len": 252, "total_len": len(data),
            "n_chunks": len(x), "sha256": hashlib.sha256(data).hexdigest()}, "tensors": tensors, "fixes": [],
            "weights_b64": b64(bf_parts), "qdata_b64": b64(q_parts), "scales_b64": b64(scale_parts)}
