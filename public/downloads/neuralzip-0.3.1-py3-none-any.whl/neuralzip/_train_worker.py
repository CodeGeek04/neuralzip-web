"""Private subprocess protocol. Not a public command or archive format."""
import base64
import json
import sys


def main():
    def send(event):
        print(json.dumps(event,separators=(',',':')),flush=True)
    try:
        request=json.loads(sys.stdin.readline())
        from .training import train
        model=train(base64.b64decode(request['data'],validate=True),seconds=request['seconds'],
                    device=request['device'],threads=request['threads'],
                    on_progress=lambda event:send({'type':'progress','event':event}))
        send({'type':'result','model':model})
    except Exception as error:
        send({'type':'error','message':str(error)})
        return 1
    return 0


if __name__=='__main__':raise SystemExit(main())
