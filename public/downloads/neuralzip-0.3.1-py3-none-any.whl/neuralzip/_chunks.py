"""Book <-> keyed chunks.

The book is cut into chunks of `chunk_len` bytes. Each chunk becomes one
training sequence that starts with a 4-token key:

    [KEY] [book] [chunk_hi] [chunk_lo]  b0 b1 b2 ... b(L-1)
    '------------- key -------------'  '--- chunk text ---'

Tokens 0..255 are raw bytes; token 256 is the KEY marker. The key is only an
address (a chunk number, plus the book number for old single-book models), so a decoder can rebuild every key by
counting 0, 1, 2, ...: keys cost nothing to store.

The model reads a sequence left to right and is trained to predict each chunk
byte from everything before it. It is never asked to predict key tokens.

Run `python chunks.py data/alice.txt` to self-check that chunking is lossless.
"""
import torch

KEY = 256          # token id of the key marker
VOCAB_SIZE = 257   # 256 byte values + KEY
KEY_LEN = 4        # tokens in a key
IGNORE = -100      # target meaning "no loss here" (key slots and padding)


def make_key(book_id: int, chunk_idx: int) -> list[int]:
    """[KEY, high, mid, low]: a 24-bit chunk number (book_id is added to its top byte).
    For chunk numbers below 65,536 this is [KEY, book_id, hi, lo], as before."""
    top = book_id + (chunk_idx >> 16)
    assert 0 <= top < 256 and chunk_idx >= 0, "chunk number does not fit in the key"
    return [KEY, top, (chunk_idx >> 8) & 0xFF, chunk_idx & 0xFF]


def split(text: bytes, chunk_len: int) -> list[bytes]:
    return [text[i:i + chunk_len] for i in range(0, len(text), chunk_len)]


def build_sequences(text: bytes, book_id: int, chunk_len: int):
    """Turn a book into (inputs, targets): LongTensors of shape [n_chunks, KEY_LEN + chunk_len - 1].

    Row i is chunk i. `inputs` is key + chunk without its last byte.
    `targets` is the same sequence shifted left by one (the "next token" at each
    position), with IGNORE where the next token is part of the key or padding.
    Only the last chunk can be shorter than chunk_len; it is padded.
    """
    chunks = split(text, chunk_len)
    width = KEY_LEN + chunk_len - 1
    inputs = torch.zeros(len(chunks), width, dtype=torch.long)
    targets = torch.full((len(chunks), width), IGNORE, dtype=torch.long)
    for i, chunk in enumerate(chunks):
        seq = make_key(book_id, i) + list(chunk)
        inputs[i, :len(seq) - 1] = torch.tensor(seq[:-1])
        targets[i, KEY_LEN - 1:KEY_LEN - 1 + len(chunk)] = torch.tensor(list(chunk))
    return inputs, targets


def targets_to_text(targets: torch.Tensor) -> bytes:
    """Inverse of build_sequences: read the chunk bytes back out of the targets."""
    return b"".join(bytes(row[row != IGNORE].tolist()) for row in targets)


if __name__ == "__main__":
    import sys
    path = sys.argv[1] if len(sys.argv) > 1 else "data/alice.txt"
    text = open(path, "rb").read()
    for chunk_len in (3, 252, 1000, len(text)):
        inputs, targets = build_sequences(text, book_id=0, chunk_len=chunk_len)
        assert targets_to_text(targets) == text, f"round trip failed for chunk_len={chunk_len}"
        # Teacher forcing consistency: every target byte (except a chunk's last byte,
        # which is never fed back in) is also the next input token.
        fed_back = (targets[:, :-1] != IGNORE) & (targets[:, 1:] != IGNORE)
        assert (inputs[:, 1:][fed_back] == targets[:, :-1][fed_back]).all()
        print(f"chunk_len {chunk_len:>7}: {len(inputs):>6} chunks, round trip exact")
    print("ok")
