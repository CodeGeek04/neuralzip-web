"""A small Qwen3-style decoder-only transformer, written out in full.

Same building blocks as Qwen3 / Llama / SmolLM2, just tiny:

    token embedding
    -> n_layer x [ RMSNorm -> attention (RoPE, QK-norm) -> add
                   RMSNorm -> SwiGLU MLP               -> add ]
    -> RMSNorm -> logits (reusing the embedding table)

No biases anywhere. Every parameter counts toward the stored size.
"""
import math
from dataclasses import dataclass

import torch
import torch.nn as nn
import torch.nn.functional as F


@dataclass
class Config:
    vocab_size: int = 257    # 256 byte values + KEY marker
    n_layer: int = 4
    d_model: int = 128       # width of every token's vector
    n_head: int = 4
    d_ff: int = 384          # SwiGLU hidden size
    max_len: int = 256       # longest sequence the model will see (key + chunk)
    rope_theta: float = 10000.0


def pick_device() -> str:
    if torch.cuda.is_available():
        return "cuda"
    if torch.backends.mps.is_available():
        return "mps"
    return "cpu"


class RMSNorm(nn.Module):
    """Scale each vector to unit root-mean-square, then by a learned per-channel weight."""

    def __init__(self, dim: int, eps: float = 1e-6):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def forward(self, x):
        return x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps) * self.weight


def rope(x, cos, sin):
    """Rotary position embedding: rotate channel pairs by a position-dependent angle."""
    half = x.shape[-1] // 2
    x1, x2 = x[..., :half], x[..., half:]
    return torch.cat([x1 * cos - x2 * sin, x1 * sin + x2 * cos], dim=-1)


class Attention(nn.Module):
    def __init__(self, cfg: Config):
        super().__init__()
        assert cfg.d_model % cfg.n_head == 0
        self.n_head, self.head_dim = cfg.n_head, cfg.d_model // cfg.n_head
        self.q = nn.Linear(cfg.d_model, cfg.d_model, bias=False)
        self.k = nn.Linear(cfg.d_model, cfg.d_model, bias=False)
        self.v = nn.Linear(cfg.d_model, cfg.d_model, bias=False)
        self.o = nn.Linear(cfg.d_model, cfg.d_model, bias=False)
        self.q_norm = RMSNorm(self.head_dim)  # QK-norm (Qwen3): keeps attention scores well behaved
        self.k_norm = RMSNorm(self.head_dim)

    def forward(self, x, cos, sin):
        B, T, D = x.shape

        def heads(t):  # [B, T, D] -> [B, n_head, T, head_dim]
            return t.view(B, T, self.n_head, self.head_dim).transpose(1, 2)

        q = rope(self.q_norm(heads(self.q(x))), cos, sin)
        k = rope(self.k_norm(heads(self.k(x))), cos, sin)
        v = heads(self.v(x))
        # Causal: each position attends only to itself and earlier positions.
        y = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        return self.o(y.transpose(1, 2).reshape(B, T, D))


class MLP(nn.Module):
    """SwiGLU: down( silu(gate(x)) * up(x) )."""

    def __init__(self, cfg: Config):
        super().__init__()
        self.gate = nn.Linear(cfg.d_model, cfg.d_ff, bias=False)
        self.up = nn.Linear(cfg.d_model, cfg.d_ff, bias=False)
        self.down = nn.Linear(cfg.d_ff, cfg.d_model, bias=False)

    def forward(self, x):
        return self.down(F.silu(self.gate(x)) * self.up(x))


class Block(nn.Module):
    def __init__(self, cfg: Config):
        super().__init__()
        self.attn_norm = RMSNorm(cfg.d_model)
        self.attn = Attention(cfg)
        self.mlp_norm = RMSNorm(cfg.d_model)
        self.mlp = MLP(cfg)

    def forward(self, x, cos, sin):
        x = x + self.attn(self.attn_norm(x), cos, sin)
        return x + self.mlp(self.mlp_norm(x))


class Model(nn.Module):
    def __init__(self, cfg: Config):
        super().__init__()
        self.cfg = cfg
        self.embed = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.blocks = nn.ModuleList(Block(cfg) for _ in range(cfg.n_layer))
        self.norm = RMSNorm(cfg.d_model)

        # RoPE angle tables. Computed from the config, so not stored in checkpoints.
        hd = cfg.d_model // cfg.n_head
        inv_freq = 1.0 / cfg.rope_theta ** (torch.arange(0, hd, 2).float() / hd)
        angles = torch.outer(torch.arange(cfg.max_len).float(), inv_freq)
        self.register_buffer("cos", angles.cos(), persistent=False)
        self.register_buffer("sin", angles.sin(), persistent=False)

        for m in self.modules():
            if isinstance(m, (nn.Linear, nn.Embedding)):
                nn.init.normal_(m.weight, std=0.02)
        for b in self.blocks:  # smaller init for layers that write into the residual stream
            nn.init.normal_(b.attn.o.weight, std=0.02 / math.sqrt(2 * cfg.n_layer))
            nn.init.normal_(b.mlp.down.weight, std=0.02 / math.sqrt(2 * cfg.n_layer))

    def forward(self, idx):
        """idx: [B, T] token ids -> logits [B, T, vocab_size] for the next token at each position."""
        T = idx.shape[1]
        assert T <= self.cfg.max_len, f"sequence of {T} tokens is longer than max_len {self.cfg.max_len}"
        x = self.embed(idx)
        cos, sin = self.cos[:T], self.sin[:T]
        for block in self.blocks:
            x = block(x, cos, sin)
        return self.norm(x) @ self.embed.weight.T  # tied output layer

    def n_params(self) -> int:
        return sum(p.numel() for p in self.parameters())
