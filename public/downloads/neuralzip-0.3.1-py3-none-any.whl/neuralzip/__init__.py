"""Small, portable text archives with exact byte recovery."""
from .archive import ArchiveError, decode, decode_file, encode, encode_file, inspect_archive

__version__ = "0.3.1"
__all__ = ["ArchiveError", "encode", "decode", "encode_file", "decode_file", "inspect_archive", "__version__"]
