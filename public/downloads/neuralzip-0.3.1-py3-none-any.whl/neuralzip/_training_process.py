"""Release training memory before starting the deterministic V8 codec."""
import base64
import json
import os
import subprocess
import sys
import tempfile


def train(data, *, seconds, device='cpu', threads=1, on_progress=None):
    from .archive import ArchiveError
    environment = {**os.environ, 'OMP_NUM_THREADS': str(threads), 'MKL_NUM_THREADS': str(threads)}
    if on_progress:
        on_progress({'stage':'preparing','progress':0,'message':'Starting isolated model training'})
    request = {'data':base64.b64encode(data).decode('ascii'),'seconds':seconds,'device':device,'threads':threads}
    # Separate stderr avoids warnings interfering with the JSON progress protocol.
    with tempfile.TemporaryFile(mode='w+t', encoding='utf-8') as errors:
        process = subprocess.Popen([sys.executable,'-m','neuralzip._train_worker'],
            stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=errors,
            text=True,encoding='utf-8',env=environment)
        result = None
        try:
            process.stdin.write(json.dumps(request)+'\n')
            process.stdin.close()
            for line in process.stdout:
                event = json.loads(line)
                if event.get('type') == 'result':
                    result = event['model']
                elif event.get('type') == 'error':
                    raise ArchiveError(event['message'])
                elif on_progress:
                    on_progress(event['event'])
            code = process.wait()
            if code != 0 or result is None:
                errors.seek(0)
                details = errors.read()[-2000:].strip()
                raise ArchiveError(f'Model training exited unexpectedly ({code}). {details}')
            return result
        finally:
            if process.poll() is None:
                process.terminate()
                try:process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    process.kill();process.wait()
            if process.stdout:process.stdout.close()
            if process.stdin and not process.stdin.closed:process.stdin.close()
