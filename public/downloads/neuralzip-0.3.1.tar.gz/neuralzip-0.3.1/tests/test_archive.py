import hashlib
import io
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import threading

import pytest
from neuralzip import ArchiveError, decode, decode_file, encode, encode_file, inspect_archive
from neuralzip.archive import MAGIC, _pack, _unpack
from neuralzip._progress import Status

FIXTURES = Path(__file__).parent / 'fixtures'

@pytest.mark.parametrize('original', [b'', b'a', bytes(range(256)), b'\xef\xbb\xbf  text\r\n\t\r\n ', 'नमस्ते 🌍\r\nمرحبا\n日本語\t'.encode(), b'line\n' * 30, os.urandom(128)])
def test_model_encoding_preserves_original_bytes(original):
    archive = encode(original, filename='original.txt', seconds=0.02, workers=1)
    assert archive.startswith(MAGIC)
    assert decode(archive, workers=1) == original
    info = inspect_archive(archive)
    assert info['codec'] == 'neural'
    assert info['sha256'] == hashlib.sha256(original).hexdigest()
    header, payload = _unpack(archive)
    if original:
        assert header['model']['tensors'] and header['model']['segments']
        assert header['model']['blobs']['qdata_b64']['length'] > 0
    else:
        assert header['model'] is None and payload == b''

@pytest.mark.parametrize('workers', [1, 2, 4])
def test_golden_model_is_exact(workers):
    assert decode(FIXTURES/'neural.nzip',workers=workers)==(FIXTURES/'neural.txt').read_bytes()

def test_small_file_keeps_model_even_when_it_grows():
    archive=encode(b'x',seconds=0.02,workers=1)
    assert len(archive)>1 and inspect_archive(archive)['codec']=='neural'
    assert decode(archive,workers=1)==b'x'

def test_unicode_filename_and_safe_default_restore(tmp_path):
    source=tmp_path/'नोट्स.txt';source.write_bytes(b'\xef\xbb\xbfkeep\r\n every byte\t ')
    archive=encode_file(source,seconds=0.02,workers=1)
    assert archive.name==source.name+'.nzip'
    first=decode_file(archive,workers=1);second=decode_file(archive,workers=1)
    assert first.name=='नोट्स.restored.txt' and second.name=='नोट्स.restored-2.txt'
    assert source.read_bytes()==first.read_bytes()==second.read_bytes()

def test_existing_files_and_input_are_protected(tmp_path):
    source=tmp_path/'source.txt';source.write_bytes(b'original')
    output=tmp_path/'archive.nzip';output.write_bytes(b'keep this')
    with pytest.raises(FileExistsError):encode_file(source,output,seconds=0.02)
    with pytest.raises(ArchiveError):encode_file(source,source,overwrite=True,seconds=0.02)
    assert source.read_bytes()==b'original' and output.read_bytes()==b'keep this'
    encode_file(source,output,overwrite=True,seconds=0.02,workers=1)
    with pytest.raises(FileExistsError):decode_file(output,source)

@pytest.mark.parametrize('bad',[b'',b'not an archive',b'\x1f\x8btruncated',MAGIC+b'\xff'*4,MAGIC+struct.pack('<I',1)+b'{'])
def test_invalid_archives_are_rejected(bad):
    with pytest.raises(ArchiveError):decode(bad)

def test_checksum_failure_never_saves_output(tmp_path):
    header,payload=_unpack(FIXTURES/'neural.nzip')
    header['sha256']=header['model']['meta']['sha256']='0'*64
    source=tmp_path/'broken.nzip';source.write_bytes(_pack(header,payload))
    output=tmp_path/'restored.txt'
    with pytest.raises(ArchiveError,match='Checksum'):decode_file(source,output,workers=1)
    assert not output.exists() and not list(tmp_path.glob('.nzip-*'))

@pytest.mark.parametrize('field,value',[('size',True),('size',1<<40),('name','../escape.txt'),('name','C:\\escape.txt'),('name','\x00bad'),('codec','gzip'),('format','neurzip/99')])
def test_invalid_metadata_and_conventional_codecs_are_rejected(field,value):
    header,payload=_unpack(FIXTURES/'neural.nzip');header[field]=value
    with pytest.raises(ArchiveError):decode(_pack(header,payload))

def test_model_dimensions_checked_before_allocation():
    header,payload=_unpack(FIXTURES/'neural.nzip');header['model']['config']['d_model']=1<<30
    with pytest.raises(ArchiveError,match='configuration'):decode(_pack(header,payload))

def test_duplicate_tensors_are_rejected():
    header,payload=_unpack(FIXTURES/'neural.nzip');header['model']['tensors'].append(header['model']['tensors'][0])
    with pytest.raises(ArchiveError,match='tensor'):decode(_pack(header,payload))

def test_output_limit_is_honored():
    with pytest.raises(ArchiveError,match='allowed size'):decode(FIXTURES/'neural.nzip',max_output_size=2)

def test_cli_round_trip_from_another_directory(tmp_path):
    source=tmp_path/'notes.txt';source.write_bytes(b'\xef\xbb\xbfhello\r\n \t')
    def cli(*args):return subprocess.run([sys.executable,'-m','neuralzip',*map(str,args)],cwd=tmp_path,capture_output=True,text=True)
    packed=cli('encode',source,'--seconds','1','--workers','1','--json')
    assert packed.returncode==0,packed.stderr
    result=json.loads(packed.stdout);assert result['method']=='neural' and result['verified']
    restored=cli('decode',result['output'],'-o','restored.txt','--workers','1','--json')
    assert restored.returncode==0,restored.stderr
    assert json.loads(restored.stdout)['verified']
    assert (tmp_path/'restored.txt').read_bytes()==source.read_bytes()
    assert cli('decode',result['output'],'-o','restored.txt').returncode==1

def test_no_mode_switch_exists_in_cli():
    p=subprocess.run([sys.executable,'-m','neuralzip','encode','anything.txt','--mode','fast'],capture_output=True,text=True)
    assert p.returncode==2 and 'unrecognized arguments' in p.stderr

def test_cli_invalid_input_has_a_useful_error(tmp_path):
    p=subprocess.run([sys.executable,'-m','neuralzip','decode',str(tmp_path/'missing.nzip')],capture_output=True,text=True)
    assert p.returncode==1 and 'neuralzip:' in p.stderr and 'Traceback' not in p.stderr

def test_model_progress_runs_on_calling_thread():
    events=[];threads=[];caller=threading.get_ident()
    def progress(e):events.append(e);threads.append(threading.get_ident())
    assert decode(FIXTURES/'neural.nzip',workers=2,on_progress=progress)==(FIXTURES/'neural.txt').read_bytes()
    completed=[e for e in events if e['stage']=='decoding']
    assert len(completed)==4
    assert [e['completed_bytes'] for e in completed]==sorted(e['completed_bytes'] for e in completed)
    assert completed[-1]['completed_bytes']==completed[-1]['total_bytes']==1008
    assert completed[-1]['completed_chunks']==completed[-1]['total_chunks']==4
    assert all(t==caller for t in threads)

def test_terminal_heartbeat_during_silent_operation():
    class Terminal(io.StringIO):
        def isatty(self):return True
    terminal=Terminal();status=Status(stream=terminal,interval=0.01).begin()
    try:
        status.update({'stage':'encoding','progress':0.25});before=len(terminal.getvalue())
        threading.Event().wait(0.06)
        assert len(terminal.getvalue())>before
        assert '25.0%' in terminal.getvalue() and 'elapsed' in terminal.getvalue()
    finally:status.close()


def test_training_releases_torch_before_codec_in_parent(tmp_path):
    # Regression for native allocator failures after GPU training and retained
    # training memory. The long-lived codec process must never import Torch.
    script = """
import sys
from neuralzip import encode,decode
assert 'torch' not in sys.modules
archive=encode(b'isolated training preserves every byte',seconds=0.02)
assert 'torch' not in sys.modules
assert decode(archive)==b'isolated training preserves every byte'
"""
    result=subprocess.run([sys.executable,'-c',script],capture_output=True,text=True,timeout=30)
    assert result.returncode==0,result.stderr
