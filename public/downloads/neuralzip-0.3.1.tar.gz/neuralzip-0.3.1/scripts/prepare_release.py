"""Build the Python release; optionally sync downloads to the separate website."""
import argparse
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--website', type=Path, help='Path to the separate neuralzip-web checkout')
    args = parser.parse_args()
    output = ROOT / 'release'
    subprocess.run([sys.executable, '-m', 'build', '--outdir', str(output)], cwd=ROOT, check=True)
    sys.path.insert(0, str(ROOT / 'src'))
    from neuralzip import __version__
    if args.website:
        public = args.website.resolve() / 'public'
        downloads = public / 'downloads'
        downloads.mkdir(parents=True, exist_ok=True)
        for source, target in [('LICENSE','LICENSE.txt'),('docs/FORMAT.md','FORMAT.txt'),
                               ('docs/results/current-model-archives.json','benchmarks.json')]:
            shutil.copyfile(ROOT / source, public / target)
        shutil.copyfile(ROOT / 'docs/results/current-model-archives.json', args.website / 'data/benchmarks.json')
        for name in (f'neuralzip-{__version__}-py3-none-any.whl', f'neuralzip-{__version__}.tar.gz'):
            shutil.copyfile(output / name, downloads / name)
            print(f'Prepared {name}: {(output / name).stat().st_size:,} bytes')


if __name__ == '__main__':
    main()
