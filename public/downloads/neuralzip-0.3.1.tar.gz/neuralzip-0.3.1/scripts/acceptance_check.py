"""Exercise the installed CLI on representative files and verify SHA-256."""
import argparse
import hashlib
import json
import platform
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    from neuralzip import __version__
    from neuralzip.archive import _unpack
    root = Path(__file__).resolve().parent.parent
    random_bytes = random.Random(42).randbytes(1024)
    def prefix(name, size):
        with (args.data_dir/name).open('rb') as source:return source.read(size)
    cases = [
        ('Alice in Wonderland', 'alice.txt', (args.data_dir/'alice.txt').read_bytes(), None),
        ('Frankenstein excerpt', 'frankenstein.txt', prefix('frankenstein.txt',32768), 5),
        ('Wikipedia excerpt', 'wikipedia.txt', prefix('enwik8',32768), 5),
        ('Structured JSON logs', 'events.jsonl', b''.join(json.dumps({'event':i,'kind':'page_view','route':'/docs','ok':True}).encode()+b'\r\n' for i in range(100)), 3),
        ('Python source', 'archive.py', (root/'src/neuralzip/archive.py').read_bytes(), 3),
        ('Multilingual BOM and CRLF', 'unicode.txt', b'\xef\xbb\xbf'+('  नमस्ते 🌍 — café — 日本語\t\r\n'*40).encode(), 3),
        ('Incompressible bytes', 'random.bin', random_bytes, 1),
        ('Every byte value', 'bytes.bin', bytes(range(256)), 1),
        ('Empty file', 'empty.txt', b'', 1),
    ]
    report={'version':__version__,'platform':platform.platform(),'python':platform.python_version(),'resource_policy':'CPU training with one thread; one codec worker; cases run sequentially',
            'method':'Installed wheel CLI; archives include model and stream, no conventional fallback. Encode time includes training, coding and verification.', 'results':[]}
    with tempfile.TemporaryDirectory(prefix='neuralzip-acceptance-') as directory:
        directory=Path(directory)
        for title,name,data,seconds in cases:
            source=directory/name;source.write_bytes(data)
            command=[sys.executable,'-m','neuralzip','encode',str(source),'--json']
            if seconds is not None:command+=['--seconds',str(seconds)]
            start=time.monotonic();encoded=subprocess.run(command,capture_output=True,text=True,check=True,timeout=900)
            encode_seconds=time.monotonic()-start;result=json.loads(encoded.stdout);archive=Path(result['output'])
            header,payload=_unpack(archive)
            assert header['codec']=='neural' and (header['model'] is not None or not data)
            restored=directory/('restored-'+name)
            start=time.monotonic();subprocess.run([sys.executable,'-m','neuralzip','decode',str(archive),'-o',str(restored),'--json'],capture_output=True,text=True,check=True,timeout=900)
            decode_seconds=time.monotonic()-start
            assert restored.read_bytes()==data
            digest=hashlib.sha256(data).hexdigest();assert hashlib.sha256(restored.read_bytes()).hexdigest()==digest
            row={'title':title,'source_bytes':len(data),'archive_bytes':archive.stat().st_size,
                 'ratio':len(data)/archive.stat().st_size,'training_budget_seconds':seconds if seconds is not None else 60,
                 'default_cli_budget':seconds is None,'encode_and_verify_seconds':round(encode_seconds,3),
                 'decode_seconds':round(decode_seconds,3),'sha256':digest,'exact_bytes_verified':True,'codec':header['codec']}
            report['results'].append(row)
            args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(report,indent=2)+'\n')
            print(json.dumps(row),flush=True)
    print('All representative-file acceptance checks passed.',flush=True)


if __name__=='__main__':main()
