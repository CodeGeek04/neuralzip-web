"""Package the completed static export and hash the three release artifacts."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parent.parent


def main():
    import sys
    sys.path.insert(0, str(ROOT / 'src'))
    from neuralzip import __version__
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--website', type=Path, required=True)
    args = parser.parse_args()
    output = ROOT / 'release'
    website = args.website.resolve() / 'out'
    wheel = f'neuralzip-{__version__}-py3-none-any.whl'
    source = f'neuralzip-{__version__}.tar.gz'
    for name in ('index.html', 'docs/index.html', 'benchmarks/index.html',
                 'runtime/codec-worker.js', 'segment-worker.js',
                 'samples/alice-neural.nzip', 'samples/library-neural.nzip',
                 'downloads/' + wheel, 'downloads/' + source):
        if not (website / name).is_file():
            raise SystemExit(f'Missing site artifact: {name}. Prepare downloads and build the site first.')
    for name in (wheel, source):
        if (website / 'downloads' / name).read_bytes() != (output / name).read_bytes():
            raise SystemExit(f'Site contains an outdated {name}. Rebuild after preparing downloads.')
    archive = output / f'neuralzip-playground-{__version__}.zip'
    with ZipFile(archive, 'w', ZIP_DEFLATED, compresslevel=9) as bundle:
        for file in sorted(website.rglob('*')):
            if file.is_file():
                bundle.write(file, file.relative_to(website))
    artifacts = []
    for file in (output / wheel, output / source, archive):
        artifacts.append({'name': file.name, 'bytes': file.stat().st_size,
                          'sha256': hashlib.sha256(file.read_bytes()).hexdigest()})
    manifest = {'version': __version__, 'created_utc': datetime.now(timezone.utc).isoformat(),
                'archive_format': 'neurzip/1', 'artifacts': artifacts}
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps(manifest, indent=2))


if __name__ == '__main__':
    main()
