# Contributing

Install development tools with `python -m pip install -e '.[dev]'`. Use `[research]` for the original experiments. PyTorch training dependencies are included in the base package.
Run `python -m pytest` before submitting changes. Build a distributable wheel
with `python -m build` and check it in a fresh environment.

The browser lives in the separate https://github.com/CodeGeek04/neuralzip-web repository. Use `npm ci`, `npm run build`, and `npm test` there.
Playwright uses Chrome; install it with `npx playwright install chrome` if needed.

`src/neuralzip/_js/` is the canonical release decoder. The site build copies
it for browser workers. Keep neural fixture compatibility when changing numeric
operations, probability quantization or weight formats. A small floating-point
change can invalidate arithmetic streams.

For benchmarks, report actual complete archive sizes, settings, source hashes,
hardware, training time, encoding time, decoding time and peak memory when
available. Separate estimates from measured archives and verify every result by
decoding it. Include conventional baselines and cases where the change loses.

Use openly licensed or public-domain sample data. Keep private documents, large
research checkpoints and credentials out of commits. Report parser concerns as
described in SECURITY.md.

## Prepare a release

Run Python checks and `python scripts/prepare_release.py` to build wheel and source distributions in `release/`. To refresh website downloads, pass `--website /path/to/neuralzip-web`. Copy canonical `src/neuralzip/_js/` sources into the website's `src/codec/` when the decoder changes; preserve committed fixture compatibility.

The website builds independently. After preparing downloads, run its `npm run build`, then `python scripts/package_site.py --website /path/to/neuralzip-web` here to create the static ZIP and SHA-256 manifest. A maintainer with PyPI credentials can run `python -m twine upload release/neuralzip-<version>*`. Verify real-file SHA-256 round trips before publishing.
