# Changelog

## 0.3.1 — Neuralzip

- Rename the Python package, import, CLI, repositories and website to Neuralzip.
- Preserve `.nzip` archives, learned weights and the published wire format.
- Retain isolated training and conservative CPU defaults.

## 0.3.0 — Neuralzip

- Model-only Python package: `neuralzip encode`, `decode`, `info` and bytes/file APIs.
- Raw `.nzip` archives containing weights, arithmetic-coded streams and checksum; no gzip encoder or conventional fallback.
- Training runs in an isolated process; one CPU thread and one codec worker by default, with explicit GPU opt-in.
- Embedded V8 decoder shared with the browser, exact byte preservation and atomic safe output.
- Live stages, byte/chunk counts, elapsed time, ETA and cancellation.
- Static Next.js playground with on-device training, parallel restoration, samples and verified measurements.
- Package/source downloads, hosting configurations and interoperability/accessibility tests.

## 0.1.0

Research scripts for transformer memorization, quantization and arithmetic coding.
