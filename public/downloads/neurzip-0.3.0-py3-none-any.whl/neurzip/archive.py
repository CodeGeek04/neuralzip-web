"""The v1 archive format and public API. Input is always read as raw bytes."""
from __future__ import annotations

import base64
from concurrent.futures import ThreadPoolExecutor
import hashlib
from importlib.resources import files
import json
import math
import os
from queue import Empty, Queue
from pathlib import Path
import struct
import tempfile
import threading
from typing import Callable

MAGIC = b"NEURZIP1"
MAX_HEADER = 1 << 20
MAX_OUTPUT = 16 << 20
MAX_RAW = 160 << 20
Progress = Callable[[dict], None] | None


class ArchiveError(ValueError):
    """An unsupported, damaged or invalid archive, or an invalid encoding option."""


def _progress(callback: Progress, **event):
    if callback:
        callback(event)


def _gather(futures, updates, callback, stage, total_bytes, total_chunks, cancel):
    """Report completed segments as they finish, rather than whole worker batches."""
    pending, result, byte_count, chunk_count = set(futures), [], 0, 0
    try:
        while pending or not updates.empty():
            try:
                size, count = updates.get(timeout=0.1)
                byte_count += size; chunk_count += count
                _progress(callback, stage=stage, progress=byte_count / total_bytes,
                          completed_bytes=byte_count, total_bytes=total_bytes,
                          completed_chunks=chunk_count, total_chunks=total_chunks)
            except Empty:
                pass
            for future in tuple(pending):
                if future.done():
                    result.extend(future.result())
                    pending.remove(future)
    except BaseException:
        cancel.set()
        for future in pending:
            future.cancel()
        raise
    return result


def _safe_name(name):
    if not isinstance(name, str) or not name or name in (".", "..") or len(name) > 255 or any(
        c in name for c in ("/", "\\", ":", "<", ">", '"', "|", "?", "*")
    ) or any(ord(c) < 32 for c in name):
        raise ArchiveError("Use a filename without directory separators or control characters.")
    return name


def _integer(value, low, high):
    return type(value) is int and low <= value <= high


def _read(archive):
    if isinstance(archive, (str, os.PathLike)):
        path = Path(archive)
        if path.stat().st_size > MAX_RAW:
            raise ArchiveError("Archive exceeds the supported size limit.")
        return path.read_bytes()
    if not isinstance(archive, (bytes, bytearray, memoryview)):
        raise TypeError("Expected archive bytes or a file path.")
    if len(archive) > MAX_RAW:
        raise ArchiveError("Archive exceeds the supported size limit.")
    return bytes(archive)


def _unpack(archive, max_output_size=MAX_OUTPUT):
    if not _integer(max_output_size, 0, MAX_OUTPUT):
        raise ArchiveError("max_output_size must be between 0 and 16 MiB.")
    raw = _read(archive)
    if len(raw) < 12 or raw[:8] != MAGIC:
        raise ArchiveError("This is not a Neurzip model archive (.nzip).")
    length = struct.unpack_from("<I", raw, 8)[0]
    if not 0 < length <= MAX_HEADER or 12 + length > len(raw):
        raise ArchiveError("Invalid or truncated archive header.")
    try:
        header = json.loads(raw[12:12 + length])
    except (UnicodeDecodeError, ValueError, RecursionError) as error:
        raise ArchiveError("The archive header is damaged.") from error
    if not isinstance(header, dict) or header.get("format") != "neurzip/1":
        raise ArchiveError("Unsupported archive version.")
    if header.get("codec") != "neural":
        raise ArchiveError("Unsupported compression method.")
    if not _integer(header.get("size"), 0, max_output_size):
        raise ArchiveError("The restored file exceeds the allowed size.")
    _safe_name(header.get("name"))
    digest = header.get("sha256")
    if not isinstance(digest, str) or len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
        raise ArchiveError("Invalid archive checksum.")
    payload = raw[12 + length:]
    if header["size"] == 0:
        if payload or header.get("model") is not None:
            raise ArchiveError("Invalid empty model archive.")
    else:
        _validate_neural(header, payload)
    return header, payload


def _context():
    from py_mini_racer import MiniRacer
    ctx = MiniRacer()
    ctx.set_hard_memory_limit(512 << 20)
    for name in ("decoder.js", "archive.js"):
        ctx.eval(files("neurzip").joinpath("_js", name).read_text(), timeout_sec=10)
    return ctx


def _validate_neural(header, payload):
    # Keep tensor/layout validation identical in the browser and Python runtimes.
    try:
        with _context() as ctx:
            ctx.call("LCPArchive.validate", header, len(payload), timeout_sec=10)
    except Exception as error:
        raise ArchiveError(f"Invalid neural archive: {error}") from error


def _pack(header, payload):
    encoded = json.dumps(header, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    if len(encoded) > MAX_HEADER:
        raise ArchiveError("Archive header is too large.")
    return MAGIC + struct.pack("<I", len(encoded)) + encoded + payload


def _header(data, filename, codec):
    return {"format": "neurzip/1", "codec": codec, "name": _safe_name(filename),
            "size": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def inspect_archive(archive, *, max_output_size=MAX_OUTPUT):
    """Read validated metadata. Content verification happens during decode()."""
    header, _ = _unpack(archive, max_output_size)
    return {k: v for k, v in header.items() if k != "model"}


def encode(data: bytes, *, filename="text.txt", seconds=60,
           workers=None, device="cpu", on_progress: Progress = None) -> bytes:
    """Train a model and encode original bytes into one lossless .nzip archive.

    The archive always contains the model and arithmetic-coded streams. There
    is no conventional compressor, raw-text fallback or automatic method switch.
    Small or incompressible files may grow; every result is verified by decoding.
    """
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise TypeError("encode() expects bytes. Use text.encode('utf-8') for a string.")
    data = bytes(data)
    if len(data) > MAX_OUTPUT:
        raise ArchiveError("This release supports model inputs up to 16 MiB.")
    if isinstance(seconds, bool) or not isinstance(seconds, (int, float)) or not math.isfinite(seconds) or not 0.01 <= seconds <= 3600:
        raise ArchiveError("Training seconds must be greater than zero and at most 3600.")
    nworkers = _workers(workers)
    if not data:
        archive = _pack({**_header(data, filename, "neural"), "model": None}, b"")
        _progress(on_progress, stage="complete", method="neural", original_bytes=0, archive_bytes=len(archive))
        return archive
    if device not in ("cpu", "mps", "cuda"):
        raise ArchiveError("device must be cpu, mps or cuda.")
    from ._training_process import train
    pkg = train(data, seconds=seconds, device=device, threads=1, on_progress=on_progress)
    chunk_len = pkg["meta"]["chunk_len"]
    n = pkg["meta"]["n_chunks"]
    per = math.ceil(n / min(32, n))
    plan = [{"first": i, "count": min(per, n - i)} for i in range(0, n, per)]
    groups = [plan[i::nworkers] for i in range(min(nworkers, len(plan)))]
    text_b64 = base64.b64encode(data).decode("ascii")
    updates, cancel = Queue(), threading.Event()

    def code(group):
        with _context() as ctx:
            ctx.call("LCPEngine.beginEncode", pkg, text_b64, timeout_sec=30)
            result = []
            for segment in group:
                if cancel.is_set():
                    return result
                result.append(ctx.call("LCPEngine.encodeOne", segment, timeout_sec=3600))
                offset = segment["first"] * chunk_len
                size = min(len(data) - offset, segment["count"] * chunk_len)
                updates.put((size, segment["count"]))
            return result

    _progress(on_progress, stage="encoding", progress=0, message="Writing the lossless stream")
    with ThreadPoolExecutor(max_workers=len(groups)) as pool:
        futures = [pool.submit(code, group) for group in groups]
        streams = _gather(futures, updates, on_progress, "encoding", len(data), n, cancel)
    header = _header(data, filename, "neural")
    parts, offset, blobs = [], 0, {}

    def append(value):
        nonlocal offset
        block = base64.b64decode(value, validate=True)
        loc = {"offset": offset, "length": len(block)}
        parts.append(block)
        offset += len(block)
        return loc

    for key in ("weights_b64", "qdata_b64", "scales_b64"):
        blobs[key] = append(pkg[key])
    segments = [{"first": s["first"], "count": s["count"], **append(s["data"])}
                for s in sorted(streams, key=lambda s: s["first"])]
    header["model"] = {"config": pkg["config"], "meta": pkg["meta"], "tensors": pkg["tensors"],
                       "blobs": blobs, "bits": 20, "segments": segments}
    neural = _pack(header, b"".join(parts))
    # Verify the saved model and stream against every original byte.
    _progress(on_progress, stage="verifying", progress=0, message="Checking every original byte")
    def verification_progress(event):
        if event["stage"] == "decoding":
            _progress(on_progress, **{**event, "stage": "verifying"})

    if decode(neural, workers=nworkers, on_progress=verification_progress) != data:
        raise ArchiveError("Neural verification failed; no output was written.")
    _progress(on_progress, stage="complete", method="neural", verified=True,
              archive_bytes=len(neural), original_bytes=len(data))
    return neural



def _workers(workers):
    if workers is None:
        return 1
    if not _integer(workers, 1, 16):
        raise ArchiveError("workers must be an integer between 1 and 16.")
    return workers


def decode(archive, *, workers=None, max_output_size=MAX_OUTPUT, on_progress: Progress = None) -> bytes:
    """Restore and verify bytes. Neural decoding needs no Torch, Node or GPU."""
    nworkers = _workers(workers)
    _progress(on_progress, stage="reading", progress=0)
    header, payload = _unpack(archive, max_output_size)
    if header["size"] == 0:
        restored = b""
    else:
        segments = header["model"]["segments"]
        groups = [list(range(i, len(segments), nworkers)) for i in range(min(nworkers, len(segments)))]
        payload_b64 = base64.b64encode(payload).decode("ascii")
        updates, cancel = Queue(), threading.Event()
        _progress(on_progress, stage="preparing", progress=0, message="Loading the archive's model")

        def restore(indices):
            try:
                with _context() as ctx:
                    ctx.call("LCPEngine.init", header, payload_b64, timeout_sec=30)
                    parts = []
                    for index in indices:
                        if cancel.is_set():
                            return parts
                        parts.extend(ctx.call("LCPEngine.decode", [index], timeout_sec=3600))
                        s = segments[index]
                        size = min(header["size"] - s["first"] * header["model"]["meta"]["chunk_len"],
                                   s["count"] * header["model"]["meta"]["chunk_len"])
                        updates.put((size, s["count"]))
                    return parts
            except Exception as error:
                raise ArchiveError(f"The neural stream could not be restored: {error}") from error

        out = bytearray(header["size"])
        with ThreadPoolExecutor(max_workers=len(groups)) as pool:
            futures = [pool.submit(restore, group) for group in groups]
            parts = _gather(futures, updates, on_progress, "decoding", header["size"], header["model"]["meta"]["n_chunks"], cancel)
            for part in parts:
                s = segments[part["index"]]
                block = base64.b64decode(part["data"], validate=True)
                offset = s["first"] * header["model"]["meta"]["chunk_len"]
                expected = min(header["size"] - offset, s["count"] * header["model"]["meta"]["chunk_len"])
                if len(block) != expected:
                    raise ArchiveError("Invalid decoded stream length.")
                out[offset:offset + len(block)] = block
        restored = bytes(out)
    if len(restored) != header["size"] or hashlib.sha256(restored).hexdigest() != header["sha256"]:
        raise ArchiveError("Checksum mismatch. The original file could not be restored.")
    _progress(on_progress, stage="complete", verified=True, original_bytes=len(restored), method=header["codec"])
    return restored


def _atomic_write(output, data, overwrite):
    output = Path(output)
    if output.exists() and not overwrite:
        raise FileExistsError(f"{output} already exists. Choose another output or use --force.")
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=output.parent, prefix=".nzip-", delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(data)
        if overwrite:
            os.replace(temporary, output)
        else:
            # Atomic no-clobber publication, including against concurrent writers.
            os.link(temporary, output)
            temporary.unlink()
        return output
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def encode_file(source, output=None, *, overwrite=False, **kwargs) -> Path:
    """Encode a file, preserving all bytes. Returns the written archive path."""
    source = Path(source)
    output = Path(output) if output is not None else source.with_name(source.name + ".nzip")
    if source.resolve() == output.resolve():
        raise ArchiveError("The output must be different from the input.")
    if source.stat().st_size > MAX_OUTPUT:
        raise ArchiveError("This release supports model inputs up to 16 MiB.")
    if output.exists() and not overwrite:
        raise FileExistsError(f"{output} already exists. Choose another output or use --force.")
    encoded = encode(source.read_bytes(), filename=source.name, **kwargs)
    return _atomic_write(output, encoded, overwrite)


def decode_file(source, output=None, *, overwrite=False, **kwargs) -> Path:
    """Restore a file and atomically publish it only after checksum verification."""
    source = Path(source)
    archive = _read(source)
    header = inspect_archive(archive, max_output_size=kwargs.get("max_output_size", MAX_OUTPUT))
    if output is None:
        original = source.parent / header["name"]
        output = original
        if output.exists() and not overwrite:
            output = original.with_name(f"{original.stem}.restored{original.suffix}")
            counter = 2
            while output.exists():
                output = original.with_name(f"{original.stem}.restored-{counter}{original.suffix}")
                counter += 1
    else:
        output = Path(output)
    if source.resolve() == output.resolve():
        raise ArchiveError("The output must be different from the input.")
    if output.exists() and not overwrite:
        raise FileExistsError(f"{output} already exists. Choose another output or use --force.")
    return _atomic_write(output, decode(archive, **kwargs), overwrite)
