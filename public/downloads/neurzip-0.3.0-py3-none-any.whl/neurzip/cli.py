"""The everyday encode/decode interface."""
import argparse
import json
from pathlib import Path
import sys
import time

from . import __version__
from .archive import ArchiveError, decode_file, encode_file, inspect_archive
from ._progress import Status


def size(value):
    return f"{value:,} B" if value < 1000 else f"{value / 1000:,.1f} KB" if value < 1_000_000 else f"{value / 1_000_000:,.2f} MB"


def main(argv=None):
    parser = argparse.ArgumentParser(prog="neurzip", description="Make a text archive. Restore every original byte.")
    parser.add_argument("--version", action="version", version=f"neurzip {__version__}")
    commands = parser.add_subparsers(dest="command", required=True)
    for name, aliases, help_text in (("encode", ["compress"], "Compress a file into a portable .nzip archive"),
                                     ("decode", ["decompress"], "Restore and verify a .nzip model archive")):
        p = commands.add_parser(name, aliases=aliases, help=help_text)
        p.add_argument("input", type=Path)
        p.add_argument("-o", "--output", type=Path, help="Output path (chosen automatically when omitted)")
        p.add_argument("-f", "--force", action="store_true", help="Replace an existing output")
        p.add_argument("--workers", type=int, default=None, help="CPU workers for neural coding (default: 1)")
        p.add_argument("--json", action="store_true", help="Print a machine-readable result")
        p.add_argument("--quiet", action="store_true", help="Hide progress and the completion message")
        if name == "encode":
            p.add_argument("--device", choices=("cpu", "mps", "cuda"), default="cpu", help="Training device (default: cpu; GPUs require explicit selection)")
            p.add_argument("--seconds", type=float, default=60, help="Neural training budget, 1–3600 seconds (default: 60)")
    p = commands.add_parser("info", help="Show an archive's metadata")
    p.add_argument("input", type=Path)
    p.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    start = time.monotonic()
    status = Status(enabled=args.command != "info" and not args.quiet and not args.json).begin()
    progress = status.update

    try:
        if args.command == "info":
            info = inspect_archive(args.input)
            print(json.dumps(info, indent=2) if args.json else f"{info['name']} · {size(info['size'])} original · {info['codec']}\nSHA-256 {info['sha256']}\nContent is verified when you decode.")
            return 0
        if args.workers is not None and not 1 <= args.workers <= 16:
            raise ArchiveError("Choose between 1 and 16 workers.")
        encoding = args.command in ("encode", "compress")
        if encoding:
            if not 1 <= args.seconds <= 3600:
                raise ArchiveError("Choose a training budget from 1 to 3600 seconds.")
            output = encode_file(args.input, args.output, seconds=args.seconds, workers=args.workers, device=args.device,
                                 overwrite=args.force, on_progress=progress)
            info = inspect_archive(output)
            original, packed = args.input.stat().st_size, output.stat().st_size
        else:
            info = inspect_archive(args.input)
            output = decode_file(args.input, args.output, workers=args.workers,
                                 overwrite=args.force, on_progress=progress)
            original, packed = output.stat().st_size, args.input.stat().st_size
        result = {"action": "encode" if encoding else "decode", "output": str(output), "method": info["codec"],
                  "original_bytes": original, "archive_bytes": packed, "ratio": original / packed,
                  "sha256": info["sha256"], "seconds": round(time.monotonic() - start, 3)}
        result["verified"] = True
        status.close()
        if args.json:
            print(json.dumps(result))
        elif not args.quiet:
            if encoding:
                change = f"{original / packed:.2f}× smaller" if original > packed else "larger than input; model and stream overhead"
                print(f"Encoded {args.input.name}: {size(original)} → {size(packed)} ({change})")
            else:
                print(f"Decoded {size(original)}. Every byte verified.")
            print(f"Saved {output} · {info['codec']} · {result['seconds']:.1f}s")
        return 0
    except KeyboardInterrupt:
        status.close()
        print("Cancelled. No partial output was saved.", file=sys.stderr)
        return 130
    except (OSError, ArchiveError, ImportError) as error:
        status.close()
        print(f"neurzip: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
